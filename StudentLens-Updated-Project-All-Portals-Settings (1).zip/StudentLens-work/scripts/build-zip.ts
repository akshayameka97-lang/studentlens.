import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';

async function generateZip() {
  const zip = new JSZip();
  const rootDir = process.cwd();

  function addDirToZip(folderPath: string, zipFolder: JSZip) {
    const items = fs.readdirSync(folderPath);
    for (const item of items) {
      if (
        item === 'node_modules' ||
        item === '.git' ||
        item === 'dist' ||
        item === '.DS_Store' ||
        item === '.aistudio' ||
        item.endsWith('.zip')
      ) {
        continue;
      }

      const fullPath = path.join(folderPath, item);
      const stat = fs.statSync(fullPath);

      if (stat.isDirectory()) {
        const subFolder = zipFolder.folder(item);
        if (subFolder) addDirToZip(fullPath, subFolder);
      } else {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(item, content);
      }
    }
  }

  console.log('📦 Bundling files into ZIP archive...');
  addDirToZip(rootDir, zip);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  // Save to root
  const outPathRoot = path.join(rootDir, 'StudentLens-Project.zip');
  fs.writeFileSync(outPathRoot, zipBuffer);
  console.log(`✅ Saved ZIP to root: ${outPathRoot} (${(zipBuffer.length / 1024).toFixed(1)} KB)`);

  // Also save to artifact directory if it exists or create it
  const artifactDir = path.resolve(rootDir, '.aistudio/artifacts/brain/938eafa3-43a1-43ad-8dda-09f671424ff9');
  if (!fs.existsSync(artifactDir)) {
    fs.mkdirSync(artifactDir, { recursive: true });
  }
  const outPathArtifact = path.join(artifactDir, 'StudentLens-Project.zip');
  fs.writeFileSync(outPathArtifact, zipBuffer);
  console.log(`✅ Saved ZIP to artifacts: ${outPathArtifact}`);
}

generateZip().catch((err) => {
  console.error('Error generating zip:', err);
  process.exit(1);
});
