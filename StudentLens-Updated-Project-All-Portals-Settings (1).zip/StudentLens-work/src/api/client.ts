export interface ApiResponse<T = any> {
  data?: T;
  error?: string;
  message?: string;
  [key: string]: any;
}

export async function apiFetch<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('studentlens_token');
  const headers = new Headers(options.headers || {});

  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!res.ok) {
    let errorMessage = `HTTP Error ${res.status}`;
    try {
      const errJson = await res.json();
      errorMessage = errJson.error || errJson.message || errorMessage;
    } catch {
      // not JSON
    }
    throw new Error(errorMessage);
  }

  // Handle binary downloads (e.g. CSV or ZIP)
  const contentType = res.headers.get('Content-Type');
  if (contentType?.includes('application/zip') || contentType?.includes('text/csv')) {
    return (await res.blob()) as unknown as T;
  }

  return await res.json();
}
