import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { StudentDashboard } from './pages/student/StudentDashboard';
import { FacultyDashboard } from './pages/faculty/FacultyDashboard';
import { AdminDashboard } from './pages/administrator/AdminDashboard';
import { Sidebar } from './components/common/Sidebar';
import { Header } from './components/common/Header';

const AppContent: React.FC = () => {
  const { isAuthenticated, isLoading, role } = useAuth();
  const [authView, setAuthView] = useState<'login' | 'register'>('login');
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#4F6257] flex flex-col items-center justify-center text-white">
        <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center animate-pulse mb-3">
          <span className="font-extrabold text-xl text-[#DCE5DC]">SL</span>
        </div>
        <p className="text-sm font-semibold tracking-wide text-[#DCE5DC]">Loading StudentLens...</p>
      </div>
    );
  }

  // Not logged in -> Show Login or Register page
  if (!isAuthenticated) {
    if (authView === 'register') {
      return <RegisterPage onNavigateToLogin={() => setAuthView('login')} />;
    }
    return <LoginPage onNavigateToRegister={() => setAuthView('register')} />;
  }

  // Determine current page title
  const getPageTitle = () => {
    switch (currentTab) {
      case 'overview':
        return role === 'student' ? 'Student Success Overview' : role === 'faculty' ? 'Faculty Mentoring Overview' : 'Institutional Intelligence';
      case 'journey':
        return 'Academic Trajectory & Grades';
      case 'attendance':
        return 'Attendance Analytics';
      case 'lms':
        return 'Assignments & LMS Coursework';
      case 'skills':
        return 'Skills & Competency Assessment';
      case 'placement':
        return 'Placement Readiness & Mock Tests';
      case 'insights':
        return 'Explainable Analytics Insights';
      case 'recommendations':
        return 'Personalized Action Recommendations';
      case 'students':
        return 'Student Directory';
      case 'academics':
        return 'Academic Performance';
      case 'at-risk':
        return 'At-Risk Student Diagnostic Roster';
      case 'segments':
        return 'Student Segmentation & Cohorts';
      case 'interventions':
        return 'Intervention & Outcome Tracker';
      case 'integration':
        return 'CSV Data Integration Portal';
      case 'reports':
        return 'Reports & Data Export';
      case 'users':
        return 'User Management';
      case 'settings':
        return 'System & Profile Settings';
      case 'profile':
        return 'Student Institutional Profile';
      default:
        return 'StudentLens Analytics';
    }
  };

  return (
    <div className="min-h-screen bg-[#4F6257] p-0 lg:p-4 transition-colors">
      {/* Outer Ivory Canvas mimicking FlowGrid.ai attached visual reference */}
      <div className="min-h-screen lg:min-h-[calc(100vh-2rem)] bg-[#F3F1EB] lg:rounded-[28px] shadow-2xl border border-[#DCE5DC]/30 flex overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={(tabId) => setCurrentTab(tabId)}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col lg:pl-64 min-w-0">
          {/* Top Header */}
          <Header
            onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
            title={getPageTitle()}
            subtitle="AI-Powered Student Analytics and Success Platform"
            onSearch={(term) => setSearchTerm(term)}
          />

          {/* Main Dashboard Workspace */}
          <main className="flex-1 p-4 lg:p-8 overflow-y-auto">
            {role === 'student' && <StudentDashboard currentTab={currentTab} />}
            {role === 'faculty' && <FacultyDashboard currentTab={currentTab} />}
            {role === 'administrator' && <AdminDashboard currentTab={currentTab} />}
          </main>
        </div>
      </div>
    </div>
  );
};

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
