import React, { useState } from 'react';
import { Bell, ShieldCheck, Palette, RotateCcw, CheckCircle, Settings2, Save } from 'lucide-react';

type Role = 'faculty' | 'administrator';
type Preferences = Record<string, boolean | string>;

const facultyDefaults: Preferences = {
  attendanceAlerts: true, pendingGradingAlerts: true, weeklyRiskSummary: true, placementAlerts: true,
  interventionUpdates: true, emailNotifications: true, securityAlerts: true, shareStudentNotes: false,
  language: 'English', compactView: false, reduceMotion: false, defaultStudentView: 'At-risk students',
};
const adminDefaults: Preferences = {
  newAccountAlerts: true, riskThresholdAlerts: true, dataImportAlerts: true, weeklyInstitutionReport: true,
  securityAlerts: true, emailNotifications: true, requireStrongPasswords: true, auditLogAlerts: true,
  language: 'English', compactView: false, reduceMotion: false, defaultLandingPage: 'Institutional Overview',
  defaultRiskThreshold: '75', dataRetention: '365',
};

const groups = {
  faculty: [
    { title: 'Notifications', description: 'Choose which academic events need your attention.', icon: Bell, fields: [
      ['attendanceAlerts', 'Low attendance alerts', 'Notify when a student falls below the attendance threshold.'],
      ['pendingGradingAlerts', 'Pending grading reminders', 'Remind me about assignments and labs awaiting evaluation.'],
      ['weeklyRiskSummary', 'Weekly academic risk summary', 'Show a weekly summary of students who may need support.'],
      ['placementAlerts', 'Placement readiness alerts', 'Notify me when placement readiness needs intervention.'],
      ['interventionUpdates', 'Intervention updates', 'Notify me about mentoring session status changes.'],
      ['emailNotifications', 'Email notifications', 'Preference for academic email notifications.'],
    ] },
    { title: 'Privacy & Security', description: 'Control account alerts and student information handling.', icon: ShieldCheck, fields: [
      ['securityAlerts', 'Security alerts', 'Show alerts for important account or sign-in activity.'],
      ['shareStudentNotes', 'Share mentoring notes with assigned team', 'Allow notes to be visible to authorized faculty collaborators.'],
    ] },
  ],
  administrator: [
    { title: 'System Notifications', description: 'Manage platform and institutional alerts.', icon: Bell, fields: [
      ['newAccountAlerts', 'New account notifications', 'Notify when student or faculty accounts are created.'],
      ['riskThresholdAlerts', 'High-risk cohort alerts', 'Notify when student risk indicators cross the configured threshold.'],
      ['dataImportAlerts', 'Data import status', 'Show results and failures from CSV imports.'],
      ['weeklyInstitutionReport', 'Weekly institutional summary', 'Enable a weekly overview of campus performance.'],
      ['emailNotifications', 'Email notifications', 'Preference for platform email notifications.'],
    ] },
    { title: 'Security & Governance', description: 'Configure administrative safety preferences.', icon: ShieldCheck, fields: [
      ['securityAlerts', 'Security alerts', 'Notify about important account and platform security activity.'],
      ['requireStrongPasswords', 'Require strong passwords (preference)', 'Record the preferred password policy for future enforcement.'],
      ['auditLogAlerts', 'Audit activity alerts', 'Notify about important administrative changes.'],
    ] },
  ],
};

export const PortalSettings: React.FC<{ role: Role }> = ({ role }) => {
  const defaults = role === 'faculty' ? facultyDefaults : adminDefaults;
  const storageKey = `studentlens-${role}-portal-settings`;
  const [values, setValues] = useState<Preferences>(() => {
    try { const saved = localStorage.getItem(storageKey); return saved ? { ...defaults, ...JSON.parse(saved) } : { ...defaults }; }
    catch { return { ...defaults }; }
  });
  const [saved, setSaved] = useState(false);
  const update = (key: string, value: boolean | string) => { setValues(prev => ({ ...prev, [key]: value })); setSaved(false); };
  const save = () => { localStorage.setItem(storageKey, JSON.stringify(values)); setSaved(true); };
  const reset = () => { setValues({ ...defaults }); localStorage.setItem(storageKey, JSON.stringify(defaults)); setSaved(true); };
  const sections = groups[role];
  const selectFields = role === 'faculty'
    ? [{ key: 'defaultStudentView', label: 'Default student view', options: ['At-risk students', 'All students', 'Placement readiness'] }]
    : [{ key: 'defaultLandingPage', label: 'Default landing page', options: ['Institutional Overview', 'Student Directory', 'Risk Analysis'] }, { key: 'defaultRiskThreshold', label: 'Risk alert threshold', options: ['60', '65', '70', '75', '80', '85'] }, { key: 'dataRetention', label: 'Preferred data retention period', options: ['90', '180', '365', '730'] }];
  return <div className="space-y-5 text-xs">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><h3 className="text-base font-bold text-[#292D29]">{role === 'faculty' ? 'Faculty Settings & Preferences' : 'Platform Settings & Preferences'}</h3><p className="text-[#777B74] mt-1">Personalize your {role === 'faculty' ? 'teaching and mentoring' : 'institutional administration'} workspace.</p></div><div className="flex gap-2"><button type="button" onClick={reset} className="inline-flex items-center gap-2 px-3 py-2.5 rounded-xl border border-[#E7E5DE] bg-white text-[#344D42] font-semibold hover:bg-[#F3F1EB]"><RotateCcw className="w-4 h-4"/> Restore defaults</button><button type="button" onClick={save} className="inline-flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#344D42] text-white font-semibold hover:bg-[#263B32]"><Save className="w-4 h-4"/> Save settings</button></div></div>
    {saved && <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-100"><CheckCircle className="w-4 h-4"/> Preferences saved in this browser on this device.</div>}
    {sections.map(section => { const Icon = section.icon; return <section key={section.title} className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><div className="flex items-start gap-3 mb-4"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><Icon className="w-5 h-5"/></div><div><h4 className="text-sm font-bold text-[#292D29]">{section.title}</h4><p className="text-[#777B74] mt-1">{section.description}</p></div></div><div className="divide-y divide-[#F0EEE8]">{section.fields.map(([key, label, description]) => <label key={key} className="flex items-start justify-between gap-4 py-3 cursor-pointer"><span><span className="block font-semibold text-[#292D29]">{label}</span><span className="block text-[#777B74] mt-1">{description}</span></span><input type="checkbox" checked={Boolean(values[key])} onChange={e => update(key, e.target.checked)} className="mt-1 w-4 h-4 accent-[#344D42] shrink-0"/></label>)}</div></section>; })}
    <section className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><div className="flex items-start gap-3 mb-4"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><Palette className="w-5 h-5"/></div><div><h4 className="text-sm font-bold text-[#292D29]">Appearance & Workspace</h4><p className="text-[#777B74] mt-1">Choose the layout and default views you prefer.</p></div></div><div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{selectFields.map(field => <label key={field.key} className="block"><span className="block font-semibold text-[#292D29] mb-2">{field.label}</span><select value={String(values[field.key])} onChange={e => update(field.key, e.target.value)} className="w-full p-3 rounded-xl border border-[#E7E5DE] bg-white text-[#292D29]">{field.options.map(option => <option key={option} value={option}>{field.key === 'defaultRiskThreshold' ? `${option}%` : field.key === 'dataRetention' ? `${option} days` : option}</option>)}</select></label>)}</div><div className="mt-4 divide-y divide-[#F0EEE8]">{([['compactView','Compact layout','Use a denser layout where supported.'],['reduceMotion','Reduce animations','Prefer fewer animated transitions where supported.']] as const).map(([key,label,desc])=><label key={key} className="flex items-start justify-between gap-4 py-3 cursor-pointer"><span><span className="block font-semibold text-[#292D29]">{label}</span><span className="block text-[#777B74] mt-1">{desc}</span></span><input type="checkbox" checked={Boolean(values[key])} onChange={e => update(key,e.target.checked)} className="mt-1 w-4 h-4 accent-[#344D42] shrink-0"/></label>)}</div></section>
    <div className="bg-[#F3F1EB] rounded-2xl p-4 flex items-start gap-3"><Settings2 className="w-5 h-5 text-[#344D42] mt-0.5 shrink-0"/><div><p className="font-semibold text-[#292D29]">Settings scope</p><p className="text-[#777B74] mt-1">These preferences are stored locally in this browser. Options such as password enforcement, data retention and email delivery are saved as preferences; applying them as system-wide policies requires backend enforcement.</p></div></div>
  </div>;
};
