import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  CalendarCheck,
  BookOpen,
  Sparkles,
  Briefcase,
  Lightbulb,
  Compass,
  User,
  Settings,
  LogOut,
  Users,
  AlertTriangle,
  FolderKanban,
  FileText,
  Activity,
  Layers,
  FileSpreadsheet,
  ShieldAlert,
  Brain,
  Sliders,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tabId: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
}) => {
  const { user, role, logout } = useAuth();

  const studentNavItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'journey', label: 'Academic Journey', icon: GraduationCap },
    { id: 'attendance', label: 'My Attendance', icon: CalendarCheck },
    { id: 'lms', label: 'Assignments & LMS', icon: BookOpen },
    { id: 'skills', label: 'My Skills', icon: Sparkles },
    { id: 'placement', label: 'Placement Readiness', icon: Briefcase },
    { id: 'recommendations', label: 'Recommendations', icon: Compass },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const facultyNavItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'students', label: 'Student Directory', icon: Users },
    { id: 'academics', label: 'Academic Analytics', icon: GraduationCap },
    { id: 'attendance', label: 'Attendance Analytics', icon: CalendarCheck },
    { id: 'lms', label: 'LMS & Assignments', icon: BookOpen },
    { id: 'at-risk', label: 'At-Risk Students', icon: AlertTriangle },
    { id: 'placement', label: 'Placement Readiness', icon: Briefcase },
    { id: 'segments', label: 'Student Segments', icon: Layers },
    { id: 'interventions', label: 'Intervention Tracker', icon: FolderKanban },
    { id: 'settings', label: 'Profile & Settings', icon: Settings },
  ];

  const adminNavItems = [
    { id: 'overview', label: 'Institutional Overview', icon: LayoutDashboard },
    { id: 'students', label: 'Student Directory', icon: Users },
    { id: 'academics', label: 'Academic Performance', icon: GraduationCap },
    { id: 'attendance', label: 'Attendance Analytics', icon: CalendarCheck },
    { id: 'placement', label: 'Placement Analytics', icon: Briefcase },
    { id: 'skills', label: 'Skills & Feedback', icon: Sparkles },
    { id: 'intelligence', label: 'Success Intelligence', icon: Brain },
    { id: 'risk', label: 'Risk Analysis', icon: ShieldAlert },
    { id: 'segments', label: 'Student Segmentation', icon: Layers },
    { id: 'interventions', label: 'Interventions & Outcomes', icon: FolderKanban },
    { id: 'integration', label: 'Data Integration (CSV)', icon: FileSpreadsheet },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'settings', label: 'Platform Settings', icon: Sliders },
  ];

  const navItems = role === 'student' ? studentNavItems : role === 'faculty' ? facultyNavItems : adminNavItems;

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#F3F1EB] border-r border-[#E7E5DE] flex flex-col transition-transform duration-200 lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 flex items-center justify-between border-b border-[#E7E5DE]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#344D42] flex items-center justify-center text-white shadow-sm">
              <Sparkles className="w-5 h-5 text-[#A5B8A8]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-lg text-[#292D29] tracking-tight">StudentLens</span>
                <span className="text-[10px] font-semibold bg-[#4F6257] text-[#DCE5DC] px-1.5 py-0.5 rounded uppercase tracking-wider">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-[#777B74] font-medium">Smart Campus Analytics</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#777B74] hover:bg-[#E7E5DE] lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Role Badge */}
        <div className="px-5 py-3 bg-[#E7E5DE]/40 border-b border-[#E7E5DE] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#43866A]"></span>
            <span className="text-xs font-semibold text-[#344D42] capitalize">{role} Portal</span>
          </div>
          <span className="text-[11px] text-[#777B74] font-medium truncate max-w-[100px]">
            {user?.department || 'Main Campus'}
          </span>
        </div>

        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 text-left ${
                  isActive
                    ? 'bg-[#344D42] text-white shadow-sm'
                    : 'text-[#52574F] hover:bg-[#E7E5DE]/60 hover:text-[#292D29]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-[#A5B8A8]' : 'text-[#777B74]'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* User Card & Logout */}
        <div className="p-4 border-t border-[#E7E5DE] bg-[#F3F1EB]">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-full bg-[#4F6257] text-white font-bold flex items-center justify-center text-xs shadow-inner">
              {user?.full_name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-[#292D29] truncate">{user?.full_name}</p>
              <p className="text-[11px] text-[#777B74] truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-[#C66F68] bg-white border border-[#E7E5DE] rounded-xl hover:bg-rose-50/50 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>
    </>
  );
};
