import React from 'react';
import { LucideIcon, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: LucideIcon;
  variant?: 'white' | 'ivory' | 'emerald' | 'sage';
  badge?: string;
  onClick?: () => void;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  change,
  changeType = 'positive',
  icon: Icon,
  variant = 'white',
  badge,
  onClick,
}) => {
  const isDark = variant === 'emerald' || variant === 'sage';
  
  const bgStyles = {
    white: 'bg-white text-[#292D29] border border-[#E7E5DE]/80 shadow-[0_4px_20px_-4px_rgba(41,45,41,0.06)]',
    ivory: 'bg-[#F3F1EB] text-[#292D29] border border-[#E7E5DE] shadow-sm',
    emerald: 'bg-[#344D42] text-white shadow-md',
    sage: 'bg-[#4F6257] text-white shadow-md',
  }[variant];

  return (
    <div
      onClick={onClick}
      className={`relative p-5 rounded-[20px] transition-all duration-200 ${bgStyles} ${
        onClick ? 'cursor-pointer hover:-translate-y-0.5 hover:shadow-lg' : ''
      }`}
    >
      <div className="flex items-center justify-between mb-3">
        <span className={`text-xs font-semibold tracking-wider uppercase ${isDark ? 'text-white/70' : 'text-[#777B74]'}`}>
          {title}
        </span>
        <div className="flex items-center gap-1.5">
          {badge && (
            <span
              className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                isDark ? 'bg-white/15 text-white' : 'bg-[#DCE5DC] text-[#344D42]'
              }`}
            >
              {badge}
            </span>
          )}
          {Icon && (
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                isDark ? 'bg-white/10 text-white' : 'bg-[#F3F1EB] text-[#344D42]'
              }`}
            >
              <Icon className="w-4 h-4" />
            </div>
          )}
        </div>
      </div>

      <div className="flex items-baseline gap-3">
        <span className="text-3xl font-bold tracking-tight">{value}</span>
        {change && (
          <span
            className={`inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded-full ${
              changeType === 'positive'
                ? isDark ? 'bg-emerald-500/20 text-emerald-200' : 'bg-emerald-50 text-[#43866A]'
                : changeType === 'negative'
                ? isDark ? 'bg-rose-500/20 text-rose-200' : 'bg-rose-50 text-[#C66F68]'
                : isDark ? 'bg-white/10 text-white/80' : 'bg-slate-100 text-slate-600'
            }`}
          >
            {changeType === 'positive' ? (
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
            ) : changeType === 'negative' ? (
              <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
            ) : (
              <Minus className="w-3.5 h-3.5 mr-0.5" />
            )}
            {change}
          </span>
        )}
      </div>

      {subtitle && (
        <p className={`mt-2 text-xs ${isDark ? 'text-white/60' : 'text-[#777B74]'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
};
