import React, { useState, useEffect } from 'react';
import {
  X,
  GraduationCap,
  CalendarCheck,
  Briefcase,
  BookOpen,
  Sparkles,
  AlertTriangle,
  FolderKanban,
  CheckCircle2,
  Clock,
  Plus
} from 'lucide-react';
import { apiFetch } from '../../api/client';
import { ExplainableInsightCard } from './ExplainableInsightCard';

interface StudentDetailModalProps {
  studentId: string | null;
  onClose: () => void;
  onOpenIntervention?: (studentId: string) => void;
}

export const StudentDetailModal: React.FC<StudentDetailModalProps> = ({
  studentId,
  onClose,
  onOpenIntervention,
}) => {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'academics' | 'placement' | 'interventions'>('overview');

  useEffect(() => {
    if (!studentId) return;
    async function loadData() {
      try {
        setLoading(true);
        const res = await apiFetch<any>(`/api/students/${studentId}`);
        setProfile(res);
      } catch (err) {
        console.error('Failed to load student detail:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [studentId]);

  if (!studentId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#F3F1EB] rounded-[24px] border border-[#E7E5DE] shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="p-6 bg-white border-b border-[#E7E5DE] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#344D42] text-white flex items-center justify-center font-bold text-lg shadow-sm">
              {profile?.student?.full_name?.charAt(0) || 'S'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-[#292D29]">
                  {profile?.student?.full_name || 'Loading Student...'}
                </h2>
                <span className="text-xs font-mono bg-[#DCE5DC] text-[#344D42] px-2 py-0.5 rounded-full font-semibold">
                  {profile?.student?.id}
                </span>
              </div>
              <p className="text-xs text-[#777B74] mt-0.5">
                {profile?.student?.department} · Year {profile?.student?.current_year} (Sem {profile?.student?.current_semester}) · Section {profile?.student?.section}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {onOpenIntervention && (
              <button
                onClick={() => {
                  onClose();
                  onOpenIntervention(studentId);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-[#43866A] hover:bg-[#344D42] text-white text-xs font-semibold rounded-full shadow-sm transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Schedule Intervention
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#777B74] hover:bg-[#E7E5DE] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-3 bg-white border-b border-[#E7E5DE] flex items-center gap-2">
          {[
            { id: 'overview', label: 'Overview & Success Score' },
            { id: 'academics', label: 'Academic & Attendance' },
            { id: 'placement', label: 'Placement & Skills' },
            { id: 'interventions', label: `Interventions (${profile?.interventions?.length || 0})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 text-xs font-semibold transition-all border-b-2 ${
                activeTab === tab.id
                  ? 'border-[#344D42] text-[#344D42]'
                  : 'border-transparent text-[#777B74] hover:text-[#292D29]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {loading ? (
            <div className="flex items-center justify-center py-16 text-[#777B74] text-sm">
              <Clock className="w-5 h-5 animate-spin mr-2" /> Loading student analytics...
            </div>
          ) : profile ? (
            <>
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* Top Success Score Card */}
                  <div className="bg-white p-6 rounded-2xl border border-[#E7E5DE] shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
                    <div>
                      <span className="text-xs font-semibold text-[#777B74] uppercase tracking-wider">
                        Overall Student Success Score
                      </span>
                      <div className="flex items-baseline gap-3 mt-1">
                        <span className="text-4xl font-extrabold text-[#292D29]">
                          {profile.scoreBreakdown?.totalScore}
                          <span className="text-xl font-normal text-[#777B74]"> / 100</span>
                        </span>
                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                            profile.scoreBreakdown?.status === 'On Track'
                              ? 'bg-emerald-50 text-[#43866A]'
                              : profile.scoreBreakdown?.status === 'Needs Attention'
                              ? 'bg-amber-50 text-[#D7A45A]'
                              : 'bg-rose-50 text-[#C66F68]'
                          }`}
                        >
                          {profile.scoreBreakdown?.status}
                        </span>
                      </div>
                      <p className="text-xs text-[#777B74] mt-2 max-w-md">
                        Calculated deterministically using weighted formula: Academic (30%), Attendance (20%), LMS (15%), Placement (20%), Skills (10%), Engagement (5%). Data completeness: {profile.scoreBreakdown?.completeness}%.
                      </p>
                    </div>

                    {/* Component breakdown bars */}
                    <div className="w-full md:w-64 space-y-2 text-xs">
                      <div className="flex justify-between font-medium">
                        <span className="text-[#52574F]">Academic (30%)</span>
                        <span className="font-bold text-[#292D29]">{profile.scoreBreakdown?.academicScore}%</span>
                      </div>
                      <div className="w-full bg-[#E7E5DE] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[#344D42] h-full" style={{ width: `${profile.scoreBreakdown?.academicScore}%` }}></div>
                      </div>

                      <div className="flex justify-between font-medium pt-1">
                        <span className="text-[#52574F]">Attendance (20%)</span>
                        <span className="font-bold text-[#292D29]">{profile.scoreBreakdown?.attendanceScore}%</span>
                      </div>
                      <div className="w-full bg-[#E7E5DE] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[#43866A] h-full" style={{ width: `${profile.scoreBreakdown?.attendanceScore}%` }}></div>
                      </div>

                      <div className="flex justify-between font-medium pt-1">
                        <span className="text-[#52574F]">Placement (20%)</span>
                        <span className="font-bold text-[#292D29]">{profile.scoreBreakdown?.placementScore}%</span>
                      </div>
                      <div className="w-full bg-[#E7E5DE] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[#668575] h-full" style={{ width: `${profile.scoreBreakdown?.placementScore}%` }}></div>
                      </div>

                      <div className="flex justify-between font-medium pt-1">
                        <span className="text-[#52574F]">LMS & Engagement (20%)</span>
                        <span className="font-bold text-[#292D29]">{profile.scoreBreakdown?.lmsScore}%</span>
                      </div>
                      <div className="w-full bg-[#E7E5DE] h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[#A5B8A8] h-full" style={{ width: `${profile.scoreBreakdown?.lmsScore}%` }}></div>
                      </div>
                    </div>
                  </div>

                  {/* Dual Risk Assessment Panel (Section 9) */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Academic Risk */}
                    <div className="bg-white p-5 rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-semibold text-[#777B74] uppercase tracking-wider">
                          Academic Risk Assessment
                        </span>
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            profile.academicRisk?.level === 'High'
                              ? 'bg-rose-100 text-[#C66F68]'
                              : profile.academicRisk?.level === 'Medium'
                              ? 'bg-amber-100 text-[#D7A45A]'
                              : 'bg-emerald-100 text-[#43866A]'
                          }`}
                        >
                          {profile.academicRisk?.level} Risk
                        </span>
                      </div>
                      <p className="text-xs text-[#52574F] mb-3">{profile.academicRisk?.recommendedAction}</p>
                      {profile.academicRisk?.factors?.length > 0 ? (
                        <div className="space-y-2">
                          {profile.academicRisk.factors.map((f: any, idx: number) => (
                            <div key={idx} className="bg-[#F3F1EB] p-2.5 rounded-xl text-xs">
                              <div className="flex justify-between font-semibold text-[#292D29]">
                                <span>{f.indicator}</span>
                                <span className="text-[#C66F68]">{f.currentValue}</span>
                              </div>
                              <p className="text-[11px] text-[#777B74] mt-0.5">{f.explanation}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-[#43866A] flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" /> All academic indicators within optimal limits.
                        </p>
                      )}
                    </div>

                    {/* Placement Risk */}
                    <div className="bg-white p-5 rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-semibold text-[#777B74] uppercase tracking-wider">
                          Placement Readiness Risk
                        </span>
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            profile.placementRisk?.level === 'High'
                              ? 'bg-rose-100 text-[#C66F68]'
                              : profile.placementRisk?.level === 'Medium'
                              ? 'bg-amber-100 text-[#D7A45A]'
                              : 'bg-emerald-100 text-[#43866A]'
                          }`}
                        >
                          {profile.placementRisk?.level} Risk
                        </span>
                      </div>
                      <p className="text-xs text-[#52574F] mb-3">{profile.placementRisk?.recommendedAction}</p>
                      {profile.placementRisk?.factors?.length > 0 ? (
                        <div className="space-y-2">
                          {profile.placementRisk.factors.map((f: any, idx: number) => (
                            <div key={idx} className="bg-[#F3F1EB] p-2.5 rounded-xl text-xs">
                              <div className="flex justify-between font-semibold text-[#292D29]">
                                <span>{f.indicator}</span>
                                <span className="text-[#D7A45A]">{f.currentValue}</span>
                              </div>
                              <p className="text-[11px] text-[#777B74] mt-0.5">{f.explanation}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-[#43866A] flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" /> Strong placement readiness across coding and aptitude.
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Explainable Insights Cards */}
                  <div>
                    <h3 className="text-sm font-bold text-[#292D29] mb-3 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-[#344D42]" /> Explainable Analytics & Signals
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {profile.insights?.map((ins: any, idx: number) => (
                        <ExplainableInsightCard
                          key={idx}
                          type={ins.type}
                          title={ins.title}
                          metric={ins.metric}
                          explanation={ins.explanation}
                          recommendation={ins.recommendation}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'academics' && (
                <div className="space-y-6">
                  {/* Subject grades table */}
                  <div className="bg-white rounded-2xl border border-[#E7E5DE] overflow-hidden shadow-sm">
                    <div className="p-4 bg-[#F3F1EB]/60 border-b border-[#E7E5DE] font-bold text-xs text-[#292D29] uppercase tracking-wider">
                      Subject Performance (Semester {profile.student.current_semester})
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-[#F3F1EB]/40 text-[#777B74] font-medium border-b border-[#E7E5DE]">
                          <tr>
                            <th className="p-3">Code</th>
                            <th className="p-3">Subject Name</th>
                            <th className="p-3">Marks</th>
                            <th className="p-3">Max</th>
                            <th className="p-3">Grade</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#E7E5DE]">
                          {profile.academicRecords?.map((r: any) => (
                            <tr key={r.id} className="hover:bg-slate-50/50">
                              <td className="p-3 font-mono font-semibold text-[#344D42]">{r.subject_code}</td>
                              <td className="p-3 font-medium text-[#292D29]">{r.subject_name}</td>
                              <td className="p-3 font-bold">{r.marks_obtained}</td>
                              <td className="p-3 text-[#777B74]">{r.max_marks}</td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded font-bold ${r.grade === 'F' ? 'bg-rose-100 text-[#C66F68]' : 'bg-emerald-50 text-[#43866A]'}`}>
                                  {r.grade}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Attendance records */}
                  <div className="bg-white p-5 rounded-2xl border border-[#E7E5DE] shadow-sm">
                    <h4 className="text-xs font-bold uppercase text-[#777B74] mb-3">Attendance History</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {profile.attendanceRecords?.map((att: any) => (
                        <div key={att.id} className="p-3 bg-[#F3F1EB] rounded-xl text-center">
                          <p className="text-xs font-semibold text-[#777B74]">{att.month}</p>
                          <p className="text-xl font-bold text-[#292D29] my-1">{att.percentage}%</p>
                          <p className="text-[11px] text-[#777B74]">{att.attended_classes}/{att.total_classes} classes</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'placement' && (
                <div className="space-y-6">
                  {/* Placement Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <p className="text-xs text-[#777B74] font-medium">Coding Benchmark</p>
                      <p className="text-2xl font-bold text-[#344D42] mt-1">{profile.student.coding_score}/100</p>
                    </div>
                    <div className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <p className="text-xs text-[#777B74] font-medium">Quantitative Aptitude</p>
                      <p className="text-2xl font-bold text-[#344D42] mt-1">{profile.student.aptitude_score}/100</p>
                    </div>
                    <div className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <p className="text-xs text-[#777B74] font-medium">Mock Interview</p>
                      <p className="text-2xl font-bold text-[#344D42] mt-1">{profile.student.mock_interview_score}/100</p>
                    </div>
                    <div className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm">
                      <p className="text-xs text-[#777B74] font-medium">Communication</p>
                      <p className="text-2xl font-bold text-[#344D42] mt-1">{profile.student.communication_score}/100</p>
                    </div>
                  </div>

                  {/* Skills Assessments */}
                  <div className="bg-white p-5 rounded-2xl border border-[#E7E5DE] shadow-sm">
                    <h4 className="text-xs font-bold uppercase text-[#777B74] mb-3">Skill Assessments Matrix</h4>
                    <div className="space-y-3">
                      {profile.skillRecords?.map((sk: any) => (
                        <div key={sk.id} className="text-xs">
                          <div className="flex justify-between font-medium mb-1">
                            <span className="text-[#292D29]">{sk.skill_name} <span className="text-[#777B74]">({sk.category})</span></span>
                            <span className="font-bold text-[#344D42]">{sk.score}/100</span>
                          </div>
                          <div className="w-full bg-[#E7E5DE] h-2 rounded-full overflow-hidden">
                            <div className="bg-[#668575] h-full" style={{ width: `${sk.score}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'interventions' && (
                <div className="space-y-4">
                  {profile.interventions?.length === 0 ? (
                    <div className="p-8 text-center text-xs text-[#777B74] bg-white rounded-2xl border border-[#E7E5DE]">
                      No recorded interventions for this student yet.
                    </div>
                  ) : (
                    profile.interventions?.map((inv: any) => (
                      <div key={inv.id} className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[#344D42]">{inv.intervention_type}</span>
                          <span className={`px-2 py-0.5 rounded-full font-semibold ${
                            inv.status === 'Completed' ? 'bg-emerald-50 text-[#43866A]' :
                            inv.status === 'In Progress' ? 'bg-amber-50 text-[#D7A45A]' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {inv.status}
                          </span>
                        </div>
                        <p className="text-[#52574F]">{inv.description}</p>
                        <div className="bg-[#F3F1EB] p-2.5 rounded-xl">
                          <span className="font-semibold text-[#292D29]">Action: </span>
                          <span className="text-[#52574F]">{inv.suggested_action}</span>
                        </div>
                        {inv.outcome_notes && (
                          <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-[#344D42]">
                            <span className="font-semibold">Outcome: </span> {inv.outcome_notes}
                            {inv.before_metric && inv.after_metric && (
                              <span className="ml-2 font-mono font-bold">({inv.before_metric} → {inv.after_metric})</span>
                            )}
                          </div>
                        )}
                        <div className="flex justify-between text-[11px] text-[#777B74] pt-1">
                          <span>Mentor: {inv.faculty_name}</span>
                          <span>Scheduled: {inv.scheduled_date}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
};
