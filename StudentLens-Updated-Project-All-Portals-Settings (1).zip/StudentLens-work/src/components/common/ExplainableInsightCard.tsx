import React from 'react';
import { CheckCircle2, AlertTriangle, AlertOctagon, Sparkles, ArrowRight } from 'lucide-react';

interface InsightProps {
  type: 'strength' | 'warning' | 'alert' | 'opportunity';
  title: string;
  metric?: string;
  explanation: string;
  recommendation: string;
  onActionClick?: () => void;
  actionText?: string;
}

export const ExplainableInsightCard: React.FC<InsightProps> = ({
  type,
  title,
  metric,
  explanation,
  recommendation,
  onActionClick,
  actionText,
}) => {
  const config = {
    strength: {
      border: 'border-l-4 border-l-[#43866A]',
      icon: CheckCircle2,
      iconColor: 'text-[#43866A]',
      bg: 'bg-white',
      badgeBg: 'bg-emerald-50 text-[#43866A]',
      label: 'Positive Contributor',
    },
    warning: {
      border: 'border-l-4 border-l-[#D7A45A]',
      icon: AlertTriangle,
      iconColor: 'text-[#D7A45A]',
      bg: 'bg-white',
      badgeBg: 'bg-amber-50 text-[#B27D26]',
      label: 'Needs Attention',
    },
    alert: {
      border: 'border-l-4 border-l-[#C66F68]',
      icon: AlertOctagon,
      iconColor: 'text-[#C66F68]',
      bg: 'bg-white',
      badgeBg: 'bg-rose-50 text-[#C66F68]',
      label: 'Critical Risk Driver',
    },
    opportunity: {
      border: 'border-l-4 border-l-[#668575]',
      icon: Sparkles,
      iconColor: 'text-[#668575]',
      bg: 'bg-white',
      badgeBg: 'bg-[#DCE5DC] text-[#344D42]',
      label: 'Growth Signal',
    },
  }[type];

  const Icon = config.icon;

  return (
    <div
      className={`p-4 rounded-xl border border-[#E7E5DE] shadow-sm ${config.bg} ${config.border} transition-all duration-200 hover:shadow-md`}
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 shrink-0 ${config.iconColor}`} />
          <h4 className="text-sm font-semibold text-[#292D29]">{title}</h4>
        </div>
        <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${config.badgeBg}`}>
          {config.label}
        </span>
      </div>

      {metric && (
        <div className="text-xs font-mono font-medium text-[#777B74] mb-2 bg-[#F3F1EB] px-2.5 py-1 rounded-md inline-block">
          Indicator: <span className="text-[#292D29] font-semibold">{metric}</span>
        </div>
      )}

      <p className="text-xs text-[#52574F] leading-relaxed mb-3">
        {explanation}
      </p>

      <div className="pt-2 border-t border-[#F3F1EB] flex items-start justify-between gap-2">
        <div className="text-xs text-[#292D29]">
          <span className="font-semibold text-[#344D42]">Suggested Action: </span>
          <span className="text-[#52574F]">{recommendation}</span>
        </div>
        {actionText && (
          <button
            onClick={onActionClick}
            className="text-xs font-semibold text-[#344D42] hover:text-[#668575] flex items-center gap-1 shrink-0 pt-0.5"
          >
            {actionText} <ArrowRight className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
  );
};
