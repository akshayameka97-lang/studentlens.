import React, { useState } from 'react';
import { Menu, Search } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface HeaderProps {
  onToggleSidebar: () => void;
  title: string;
  subtitle?: string;
  onSearch?: (term: string) => void;
  onSelectStudent?: (studentId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  title,
  subtitle,
  onSearch,
}) => {
  const { user, role } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);
    if (onSearch) onSearch(val);
  };



  return (
    <header className="sticky top-0 z-30 bg-[#F3F1EB]/90 backdrop-blur-md border-b border-[#E7E5DE] px-4 lg:px-8 py-3.5 flex items-center justify-between gap-4">
      {/* Left: Mobile hamburger & Page Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-[#292D29] hover:bg-[#E7E5DE] lg:hidden transition-colors"
          aria-label="Toggle Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xl lg:text-2xl font-bold tracking-tight text-[#292D29]">
            {title}
          </h1>
          {subtitle && (
            <p className="text-xs text-[#777B74] font-medium hidden sm:block">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {/* Center: Search pill inspired by FlowGrid.ai */}
      <div className="hidden md:flex flex-1 max-w-md mx-4">
        <div className="relative w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#777B74]" />
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            placeholder="Search students, subjects, IDs, risk indicators..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-[#E7E5DE] rounded-full text-xs text-[#292D29] placeholder:text-[#777B74] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20 focus:border-[#344D42] transition-all shadow-sm"
          />
        </div>
      </div>

      {/* Right: Academic session indicator */}
      <div className="flex items-center gap-2.5">
        {/* Academic Session indicator */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-full text-xs font-medium text-[#52574F] shadow-sm">
          <span className="w-2 h-2 rounded-full bg-[#43866A] animate-pulse"></span>
          <span>AY 2026-27 (Sem Odd)</span>
        </div>
      </div>
    </header>
  );
};
