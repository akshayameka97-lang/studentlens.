import React, { useState } from 'react';
import { X, Calendar, Plus, CheckCircle2 } from 'lucide-react';
import { apiFetch } from '../../api/client';

interface NewInterventionModalProps {
  initialStudentId?: string | null;
  onClose: () => void;
  onCreated: () => void;
}

export const NewInterventionModal: React.FC<NewInterventionModalProps> = ({
  initialStudentId,
  onClose,
  onCreated,
}) => {
  const [studentId, setStudentId] = useState(initialStudentId || '');
  const [type, setType] = useState('Academic Mentoring');
  const [priority, setPriority] = useState('Medium');
  const [description, setDescription] = useState('');
  const [suggestedAction, setSuggestedAction] = useState('');
  const [scheduledDate, setScheduledDate] = useState(new Date().toISOString().split('T')[0]);
  const [followUpDate, setFollowUpDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!studentId || !description || !suggestedAction) {
      setError('Please fill in student ID, description, and suggested action.');
      return;
    }

    try {
      setIsSubmitting(true);
      await apiFetch('/api/interventions', {
        method: 'POST',
        body: JSON.stringify({
          student_id: studentId.trim(),
          intervention_type: type,
          priority,
          description,
          suggested_action: suggestedAction,
          scheduled_date: scheduledDate,
          follow_up_date: followUpDate || null,
        }),
      });
      onCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to record intervention.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#F3F1EB] rounded-[24px] border border-[#E7E5DE] shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="p-5 bg-white border-b border-[#E7E5DE] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#344D42] text-white flex items-center justify-center">
              <Plus className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-[#292D29]">Schedule Student Intervention</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#777B74] hover:bg-[#E7E5DE]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-[#C66F68] rounded-xl font-medium">
              {error}
            </div>
          )}

          <div>
            <label className="block font-semibold text-[#292D29] mb-1">Student ID *</label>
            <input
              type="text"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              placeholder="e.g. STU-2024-001"
              required
              className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Intervention Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
              >
                <option value="Academic Mentoring">Academic Mentoring</option>
                <option value="Placement Coaching">Placement Coaching</option>
                <option value="Attendance Counseling">Attendance Counseling</option>
                <option value="Skill Workshop">Skill Workshop</option>
                <option value="Wellbeing & Guidance">Wellbeing & Guidance</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Priority Level</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
              >
                <option value="High">High (Immediate Action)</option>
                <option value="Medium">Medium (Scheduled)</option>
                <option value="Low">Low (Routine Check-in)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-[#292D29] mb-1">Observation / Diagnostic Reason *</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Student score dropped to 54 in Data Structures; attendance slipped to 68%."
              rows={2}
              required
              className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#292D29] mb-1">Suggested Remedial Action *</label>
            <textarea
              value={suggestedAction}
              onChange={(e) => setSuggestedAction(e.target.value)}
              placeholder="e.g. Assign to Tuesday remedial lab; pair with senior tutor for binary search practice."
              rows={2}
              required
              className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Scheduled Date</label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Follow-up Date</label>
              <input
                type="date"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#E7E5DE]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs font-semibold text-[#777B74] hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-xl text-xs font-semibold shadow-sm transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Recording...' : 'Save Intervention'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
