import React, { useState } from 'react';
import {
  Sparkles,
  GraduationCap,
  Users,
  ShieldCheck,
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useAuth, UserRole } from '../../context/AuthContext';

interface RegisterPageProps {
  onNavigateToLogin: () => void;
}

export const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigateToLogin }) => {
  const { register } = useAuth();
  const [role, setRole] = useState<UserRole>('student');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [department, setDepartment] = useState('Computer Science');

  // Role-specific fields
  const [studentId, setStudentId] = useState('');
  const [currentYear, setCurrentYear] = useState('3');
  const [currentSemester, setCurrentSemester] = useState('5');
  const [section, setSection] = useState('A');
  const [designation, setDesignation] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    try {
      setIsLoading(true);
      await register({
        full_name: fullName,
        email,
        password,
        confirm_password: confirmPassword,
        role,
        department,
        student_id: studentId || (role === 'student' ? `STU-${Date.now().toString().slice(-4)}` : undefined),
        faculty_id: designation || (role === 'faculty' ? `FAC-${Date.now().toString().slice(-4)}` : undefined),
        designation: designation || (role === 'faculty' ? 'Assistant Professor' : 'Administrator'),
        current_year: currentYear,
        current_semester: currentSemester,
        section,
      });

      setSuccessMessage('Account created successfully! Redirecting to dashboard...');
    } catch (err: any) {
      setErrorMessage(err.message || 'Registration failed. Please verify your details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#4F6257] flex items-center justify-center p-4 lg:p-8">
      <div className="w-full max-w-2xl bg-[#F3F1EB] rounded-[28px] shadow-2xl border border-[#DCE5DC]/40 p-8 lg:p-12 relative overflow-hidden">
        {/* Top Back Link */}
        <button
          onClick={onNavigateToLogin}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#52574F] hover:text-[#344D42] mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Sign In
        </button>

        {/* Title */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-xl bg-[#344D42] text-white flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#A5B8A8]" />
            </div>
            <span className="font-bold text-lg text-[#292D29]">StudentLens Account Registration</span>
          </div>
          <p className="text-xs text-[#777B74]">
            Register an institutional profile for AI-powered analytics and performance monitoring.
          </p>
        </div>

        {/* Role Selection */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-[#292D29] mb-2 uppercase tracking-wider">
            Select Your Role
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'student', label: 'Student', icon: GraduationCap },
              { id: 'faculty', label: 'Faculty', icon: Users },
              { id: 'administrator', label: 'Administrator', icon: ShieldCheck },
            ].map((item) => {
              const Icon = item.icon;
              const isSelected = role === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRole(item.id as UserRole)}
                  className={`p-3 rounded-xl border text-center flex flex-col items-center gap-1.5 transition-all ${
                    isSelected
                      ? 'bg-white border-[#344D42] shadow-sm ring-2 ring-[#344D42]/20 text-[#292D29]'
                      : 'bg-[#F3F1EB] border-[#E7E5DE] text-[#777B74] hover:bg-white'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isSelected ? 'text-[#344D42]' : 'text-[#777B74]'}`} />
                  <span className="text-xs font-bold">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Alerts */}
        {errorMessage && (
          <div className="mb-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-[#C66F68]">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-2.5 text-xs text-[#43866A]">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Full Legal Name *</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Diya Sharma"
                required
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Institutional Email *</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="diya.sharma@studentlens.edu"
                required
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Password *</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  required
                  className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#777B74]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Confirm Password *</label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-type password"
                required
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              >
                <option value="Computer Science">Computer Science</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Data Science">Data Science</option>
                <option value="Electronics & Comm">Electronics & Communication</option>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
              </select>
            </div>

            {/* Role specific ID field */}
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">
                {role === 'student' ? 'Student Roll/ID' : role === 'faculty' ? 'Faculty ID' : 'Administrator ID'}
              </label>
              <input
                type="text"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                placeholder={role === 'student' ? 'STU-2024-042' : 'FAC-CS-108'}
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>
          </div>

          {/* Student-specific academic fields */}
          {role === 'student' && (
            <div className="grid grid-cols-3 gap-3 p-3.5 bg-white rounded-2xl border border-[#E7E5DE]">
              <div>
                <label className="block font-semibold text-[#292D29] mb-1">Current Year</label>
                <select
                  value={currentYear}
                  onChange={(e) => setCurrentYear(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#F3F1EB] rounded-lg text-xs"
                >
                  <option value="1">1st Year</option>
                  <option value="2">2nd Year</option>
                  <option value="3">3rd Year</option>
                  <option value="4">4th Year</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[#292D29] mb-1">Semester</label>
                <select
                  value={currentSemester}
                  onChange={(e) => setCurrentSemester(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#F3F1EB] rounded-lg text-xs"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={s}>Semester {s}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[#292D29] mb-1">Section</label>
                <select
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#F3F1EB] rounded-lg text-xs"
                >
                  <option value="A">Section A</option>
                  <option value="B">Section B</option>
                  <option value="C">Section C</option>
                </select>
              </div>
            </div>
          )}

          {/* Faculty/Admin Designation */}
          {role !== 'student' && (
            <div>
              <label className="block font-semibold text-[#292D29] mb-1">Designation / Role Title</label>
              <input
                type="text"
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                placeholder={role === 'faculty' ? 'e.g. Associate Professor & Mentor' : 'e.g. Provost / Academic Dean'}
                className="w-full px-3.5 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-4 py-3 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all duration-200 disabled:opacity-50"
          >
            {isLoading ? 'Creating Account...' : 'Complete Registration'}
          </button>
        </form>

        <div className="mt-5 text-center text-xs text-[#777B74]">
          Already have an account?{' '}
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="font-bold text-[#344D42] hover:underline"
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  );
};
