import React, { useState } from 'react';
import {
  Sparkles,
  GraduationCap,
  Users,
  ShieldCheck,
  Eye,
  EyeOff,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  BrainCircuit
} from 'lucide-react';
import { useAuth, UserRole } from '../../context/AuthContext';

interface LoginPageProps {
  onNavigateToRegister: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigateToRegister }) => {
  const { login } = useAuth();
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [email, setEmail] = useState('student@studentlens.edu');
  const [password, setPassword] = useState('Password123!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Quick 1-click test credentials helper
  const handleSelectDemoAccount = (role: UserRole) => {
    setSelectedRole(role);
    if (role === 'student') {
      setEmail('student@studentlens.edu');
      setPassword('Password123!');
    } else if (role === 'faculty') {
      setEmail('faculty@studentlens.edu');
      setPassword('Password123!');
    } else {
      setEmail('admin@studentlens.edu');
      setPassword('Password123!');
    }
    setErrorMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      await login(email, password, selectedRole);
    } catch (err: any) {
      setErrorMessage(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#4F6257] flex items-center justify-center p-4 lg:p-8">
      {/* Outer Ivory & Emerald Container mirroring FlowGrid.ai aesthetics */}
      <div className="w-full max-w-6xl bg-[#F3F1EB] rounded-[28px] shadow-2xl border border-[#DCE5DC]/40 overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[720px]">
        {/* Left Section (Branding & Analytics Preview) - 5 Cols */}
        <div className="lg:col-span-5 bg-[#344D42] p-8 lg:p-12 text-white flex flex-col justify-between relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#668575]/20 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#4F6257]/40 rounded-full blur-2xl pointer-events-none -ml-20 -mb-20"></div>

          <div className="relative z-10">
            {/* Logo */}
            <div className="flex items-center gap-3 mb-10">
              <div className="w-11 h-11 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-[#DCE5DC]">
                <Sparkles className="w-6 h-6 text-[#A5B8A8]" />
              </div>
              <div>
                <span className="font-extrabold text-xl tracking-tight text-white">StudentLens</span>
                <span className="ml-2 text-[10px] font-bold bg-[#A5B8A8]/20 border border-[#A5B8A8]/30 px-2 py-0.5 rounded-full text-[#DCE5DC] uppercase tracking-wider">
                  Analytics
                </span>
              </div>
            </div>

            {/* Headline */}
            <h1 className="text-3xl lg:text-4xl font-extrabold leading-tight text-white mb-4 tracking-tight">
              Turn Student Data Into Student Success.
            </h1>
            <p className="text-sm text-[#DCE5DC]/80 leading-relaxed mb-8">
              Predict, optimize, and improve student retention with explainable AI scoring, dual-track academic and placement risk detection, and closed-loop faculty interventions.
            </p>

            {/* Decorative Mini Dashboard Preview Card mirroring FlowGrid.ai style */}
            <div className="p-5 bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl space-y-4 shadow-lg">
              <div className="flex items-center justify-between text-xs text-[#DCE5DC]">
                <span className="font-semibold flex items-center gap-1.5">
                  <BrainCircuit className="w-4 h-4 text-[#A5B8A8]" /> Explainable Success Engine
                </span>
                <span className="bg-[#43866A] text-white text-[10px] px-2 py-0.5 rounded-full font-bold">
                  Active
                </span>
              </div>

              <div className="bg-white/10 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-[11px] text-white/70">Institutional Success Average</p>
                  <p className="text-2xl font-bold text-white mt-0.5">82.4 <span className="text-xs font-normal text-white/70">/ 100</span></p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold text-emerald-300 flex items-center gap-0.5 justify-end">
                    <TrendingUp className="w-3.5 h-3.5" /> +4.2%
                  </span>
                  <p className="text-[10px] text-white/60 mt-0.5">AY 2026-27 Cohort</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="p-2.5 bg-white/5 rounded-lg border border-white/10">
                  <span className="text-white/60 block">Academic Weight</span>
                  <span className="font-bold text-white">30% · CGPA & Backlogs</span>
                </div>
                <div className="p-2.5 bg-white/5 rounded-lg border border-white/10">
                  <span className="text-white/60 block">Placement Weight</span>
                  <span className="font-bold text-white">20% · Coding & Aptitude</span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="relative z-10 pt-8 border-t border-white/10 flex items-center justify-between text-xs text-[#A5B8A8]">
            <span>Ivory & Emerald Theme</span>
            <span>Deterministic Local Analytics</span>
          </div>
        </div>

        {/* Right Section (Login Card with Role Selector) - 7 Cols */}
        <div className="lg:col-span-7 p-8 lg:p-14 flex flex-col justify-center">
          <div className="max-w-md mx-auto w-full">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-[#292D29] tracking-tight">Sign In to StudentLens</h2>
              <p className="text-xs text-[#777B74] mt-1">
                Choose your role category and enter your institutional credentials.
              </p>
            </div>

            {/* Three Login Categories / Role Selectors (Section 5) */}
            <div className="mb-6">
              <label className="block text-xs font-bold text-[#292D29] mb-2 uppercase tracking-wider">
                Select Your Role Category
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {/* 1. Student */}
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('student')}
                  className={`p-3 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between ${
                    selectedRole === 'student'
                      ? 'bg-white border-[#344D42] shadow-md ring-2 ring-[#344D42]/20'
                      : 'bg-[#F3F1EB] border-[#E7E5DE] hover:bg-white text-[#777B74]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <GraduationCap
                      className={`w-5 h-5 ${
                        selectedRole === 'student' ? 'text-[#344D42]' : 'text-[#777B74]'
                      }`}
                    />
                    {selectedRole === 'student' && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#43866A]" />
                    )}
                  </div>
                  <div>
                    <p className={`text-xs font-bold ${selectedRole === 'student' ? 'text-[#292D29]' : 'text-[#52574F]'}`}>
                      Student
                    </p>
                    <p className="text-[10px] text-[#777B74] leading-tight mt-0.5 line-clamp-2">
                      Track journey & readiness
                    </p>
                  </div>
                </button>

                {/* 2. Faculty */}
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('faculty')}
                  className={`p-3 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between ${
                    selectedRole === 'faculty'
                      ? 'bg-white border-[#344D42] shadow-md ring-2 ring-[#344D42]/20'
                      : 'bg-[#F3F1EB] border-[#E7E5DE] hover:bg-white text-[#777B74]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Users
                      className={`w-5 h-5 ${
                        selectedRole === 'faculty' ? 'text-[#344D42]' : 'text-[#777B74]'
                      }`}
                    />
                    {selectedRole === 'faculty' && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#43866A]" />
                    )}
                  </div>
                  <div>
                    <p className={`text-xs font-bold ${selectedRole === 'faculty' ? 'text-[#292D29]' : 'text-[#52574F]'}`}>
                      Faculty
                    </p>
                    <p className="text-[10px] text-[#777B74] leading-tight mt-0.5 line-clamp-2">
                      Monitor & intervene
                    </p>
                  </div>
                </button>

                {/* 3. Administrator */}
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('administrator')}
                  className={`p-3 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between ${
                    selectedRole === 'administrator'
                      ? 'bg-white border-[#344D42] shadow-md ring-2 ring-[#344D42]/20'
                      : 'bg-[#F3F1EB] border-[#E7E5DE] hover:bg-white text-[#777B74]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <ShieldCheck
                      className={`w-5 h-5 ${
                        selectedRole === 'administrator' ? 'text-[#344D42]' : 'text-[#777B74]'
                      }`}
                    />
                    {selectedRole === 'administrator' && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#43866A]" />
                    )}
                  </div>
                  <div>
                    <p className={`text-xs font-bold ${selectedRole === 'administrator' ? 'text-[#292D29]' : 'text-[#52574F]'}`}>
                      Admin
                    </p>
                    <p className="text-[10px] text-[#777B74] leading-tight mt-0.5 line-clamp-2">
                      Institutional trends
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Error banner */}
            {errorMessage && (
              <div className="mb-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-[#C66F68] animate-fade-in">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#292D29] mb-1">
                  College Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@studentlens.edu"
                  required
                  className="w-full px-4 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] placeholder:text-[#777B74] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20 focus:border-[#344D42] transition-all shadow-sm"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-[#292D29]">
                    Password
                  </label>
                  <span className="text-[11px] text-[#777B74] hover:text-[#344D42] cursor-pointer">
                    Forgot password?
                  </span>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    required
                    className="w-full px-4 py-2.5 bg-white border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] placeholder:text-[#777B74] focus:outline-none focus:ring-2 focus:ring-[#344D42]/20 focus:border-[#344D42] transition-all shadow-sm pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#777B74] hover:text-[#292D29]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-[#52574F]">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-[#344D42] focus:ring-[#344D42]"
                  />
                  Remember my session
                </label>
                <span className="text-[11px] text-[#777B74]">Demo mode enabled</span>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isLoading ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <span>Enter {selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1)} Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Accounts Pill Switcher */}
            <div className="mt-6 pt-5 border-t border-[#E7E5DE] text-center">
              <p className="text-[11px] font-semibold text-[#777B74] mb-2">
                Pre-configured Demo Accounts (1-Click Fill):
              </p>
              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('student')}
                  className="px-2.5 py-1 bg-white border border-[#E7E5DE] rounded-lg text-[11px] font-medium text-[#344D42] hover:bg-[#DCE5DC]/50 transition-colors"
                >
                  Student (Aarav)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('faculty')}
                  className="px-2.5 py-1 bg-white border border-[#E7E5DE] rounded-lg text-[11px] font-medium text-[#344D42] hover:bg-[#DCE5DC]/50 transition-colors"
                >
                  Faculty (Dr. Jenkins)
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectDemoAccount('administrator')}
                  className="px-2.5 py-1 bg-white border border-[#E7E5DE] rounded-lg text-[11px] font-medium text-[#344D42] hover:bg-[#DCE5DC]/50 transition-colors"
                >
                  Admin (Dean Vance)
                </button>
              </div>
            </div>

            {/* Register Link */}
            <div className="mt-5 text-center text-xs text-[#777B74]">
              Don't have an institutional account?{' '}
              <button
                type="button"
                onClick={onNavigateToRegister}
                className="font-bold text-[#344D42] hover:underline"
              >
                Create Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
