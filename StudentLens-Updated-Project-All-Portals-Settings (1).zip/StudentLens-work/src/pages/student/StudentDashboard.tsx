import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  CalendarCheck,
  BookOpen,
  Briefcase,
  Sparkles,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
  ExternalLink,
  Code2,
  Brain,
  MessageSquare,
  Award,
  Bell,
  ShieldCheck,
  Palette,
  Eye,
  Clock3,
  Globe,
  RotateCcw,
  CheckCircle
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { apiFetch } from '../../api/client';
import { MetricCard } from '../../components/common/MetricCard';
import { ExplainableInsightCard } from '../../components/common/ExplainableInsightCard';

interface StudentDashboardProps {
  currentTab: string;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ currentTab }) => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [practiceResults, setPracticeResults] = useState<{ coding?: number; aptitude?: number; interview?: number }>({});
  const defaultPreferences = {
    weeklyProgress: true,
    attendanceAlerts: true,
    placementAlerts: true,
    assignmentReminders: true,
    shareProgressWithFaculty: true,
    profileVisibleToPeers: false,
    studyReminders: true,
    reminderTime: '18:00',
    weeklyStudyGoal: '12',
    language: 'English',
    compactView: false,
    reduceMotion: false,
    emailNotifications: true,
    securityAlerts: true,
  };
  const [preferences, setPreferences] = useState<typeof defaultPreferences>(() => {
    try {
      const saved = localStorage.getItem('studentlens-student-preferences');
      return saved ? { ...defaultPreferences, ...JSON.parse(saved) } : defaultPreferences;
    } catch { return defaultPreferences; }
  });
  const [settingsSaved, setSettingsSaved] = useState(false);
  const updatePreference = (key: keyof typeof defaultPreferences, value: boolean | string) => {
    setPreferences(prev => ({ ...prev, [key]: value }));
    setSettingsSaved(false);
  };
  const savePreferences = () => {
    localStorage.setItem('studentlens-student-preferences', JSON.stringify(preferences));
    setSettingsSaved(true);
  };
  const resetPreferences = () => {
    setPreferences(defaultPreferences);
    localStorage.setItem('studentlens-student-preferences', JSON.stringify(defaultPreferences));
    setSettingsSaved(true);
  };

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const stuId = user?.college_id || 'STU-2024-001';
        const res = await apiFetch<any>(`/api/students/${stuId}`);
        setProfile(res);

        const recRes = await apiFetch<any>(`/api/students/${stuId}/recommendations`);
        setRecommendations(recRes.recommendations || []);
      } catch (err) {
        console.error('Failed to load student data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px] text-[#777B74] text-sm">
        <Clock className="w-5 h-5 animate-spin mr-2" />
        Loading your academic analytics...
      </div>
    );
  }

  const student = profile?.student;
  const scoreBreakdown = profile?.scoreBreakdown;

  // Chart data
  const semesterTrendData = [
    { sem: 'Sem 1', cgpa: 8.0, attendance: 86 },
    { sem: 'Sem 2', cgpa: 8.2, attendance: 88 },
    { sem: 'Sem 3', cgpa: 8.3, attendance: 87 },
    { sem: 'Sem 4', cgpa: 8.4, attendance: 90 },
    { sem: `Sem ${student?.current_semester || 5}`, cgpa: student?.cgpa || 8.45, attendance: student?.attendance_percentage || 89 },
  ];

  const radarSkillData = [
    { subject: 'Data Structures', score: student?.coding_score || 64, fullMark: 100 },
    { subject: 'Aptitude', score: student?.aptitude_score || 78, fullMark: 100 },
    { subject: 'Communication', score: student?.communication_score || 82, fullMark: 100 },
    { subject: 'Mock Interview', score: student?.mock_interview_score || 75, fullMark: 100 },
    { subject: 'LMS Progress', score: student?.lms_completion_rate || 91, fullMark: 100 },
    { subject: 'Attendance', score: student?.attendance_percentage || 89, fullMark: 100 },
  ];

  return (
    <div className="space-y-6">
      {(currentTab === 'overview' || !currentTab) && (
      <>
      {/* Welcome Banner */}
      <div className="bg-[#344D42] text-white p-6 lg:p-8 rounded-[24px] shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#A5B8A8]">
                Student Success Portal
              </span>
              <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full text-white/80">
                {student?.id}
              </span>
            </div>
            <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight">
              Welcome back, {student?.full_name}!
            </h2>
            <p className="text-xs text-[#DCE5DC]/80 mt-1">
              {student?.department} · Year {student?.current_year} (Sem {student?.current_semester}) · Section {student?.section}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 text-center">
              <span className="text-[10px] text-[#DCE5DC] uppercase tracking-wider block">CGPA</span>
              <span className="text-xl font-bold">{student?.cgpa.toFixed(2)}</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/15 text-center">
              <span className="text-[10px] text-[#DCE5DC] uppercase tracking-wider block">Attendance</span>
              <span className="text-xl font-bold">{student?.attendance_percentage}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid (FlowGrid.ai style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Student Success Score"
          value={`${scoreBreakdown?.totalScore || 0}`}
          subtitle="Explainable weighted composite"
          change="+3.4%"
          changeType="positive"
          badge={scoreBreakdown?.status}
          icon={Award}
          variant="white"
        />
        <MetricCard
          title="Placement Readiness"
          value={`${student?.placement_readiness_score}/100`}
          subtitle="Aptitude & Coding benchmark"
          change="+5.0%"
          changeType="positive"
          icon={Briefcase}
          variant="white"
        />
        <MetricCard
          title="Overall Attendance"
          value={`${student?.attendance_percentage}%`}
          subtitle="Above 75% examination threshold"
          change="Consistent"
          changeType="positive"
          icon={CalendarCheck}
          variant="white"
        />
        <MetricCard
          title="LMS Completion"
          value={`${student?.lms_completion_rate}%`}
          subtitle="Assignments & virtual lab modules"
          change="+8.2%"
          changeType="positive"
          icon={BookOpen}
          variant="white"
        />
      </div>
      </>
      )}

      {/* TAB 1: OVERVIEW */}
      {(currentTab === 'overview' || !currentTab) && (
        <div className="space-y-6">
          {/* Main Visual Row: Performance Dynamics Area Chart + Score Radar */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Academic Growth Area Chart (7 Cols) */}
            <div className="lg:col-span-7 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-[#292D29]">Academic Trajectory</h3>
                  <p className="text-xs text-[#777B74]">Semester-wise CGPA and attendance evolution</p>
                </div>
                <span className="text-xs font-semibold bg-[#F3F1EB] text-[#344D42] px-3 py-1 rounded-full">
                  Sem 1 – {student?.current_semester}
                </span>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={semesterTrendData}>
                    <defs>
                      <linearGradient id="colorCgpa" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#344D42" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#344D42" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorAtt" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#668575" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#668575" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F1EB" />
                    <XAxis dataKey="sem" tick={{ fontSize: 11, fill: '#777B74' }} />
                    <YAxis domain={[5, 10]} tick={{ fontSize: 11, fill: '#777B74' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        borderRadius: '12px',
                        border: '1px solid #E7E5DE',
                        fontSize: '12px',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="cgpa"
                      stroke="#344D42"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#colorCgpa)"
                      name="CGPA"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Radar Readiness Profile (5 Cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-[#292D29]">Competency Radar</h3>
                <p className="text-xs text-[#777B74]">Holistic balance across all success indicators</p>
              </div>

              <div className="h-56 w-full my-auto">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarSkillData}>
                    <PolarGrid stroke="#E7E5DE" />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: '#52574F' }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 9 }} />
                    <Radar
                      name="Competency"
                      dataKey="score"
                      stroke="#43866A"
                      fill="#668575"
                      fillOpacity={0.4}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              <div className="pt-3 border-t border-[#F3F1EB] flex items-center justify-between text-xs text-[#777B74]">
                <span>Strongest: Communication</span>
                <span className="text-[#D7A45A] font-semibold">Priority: Coding (64)</span>
              </div>
            </div>
          </div>

          {/* Explainable Insights Preview */}
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-[#292D29] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#344D42]" /> Explainable Success Signals
                </h3>
                <p className="text-xs text-[#777B74]">Transparent explanations for your calculated score</p>
              </div>
              <span className="text-xs font-semibold text-[#344D42]">
                {profile?.insights?.length || 0} Factors Identified
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {profile?.insights?.map((ins: any, idx: number) => (
                <ExplainableInsightCard
                  key={idx}
                  type={ins.type}
                  title={ins.title}
                  metric={ins.metric}
                  explanation={ins.explanation}
                  recommendation={ins.recommendation}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ACADEMIC JOURNEY */}
      {currentTab === 'journey' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-1">Previous Semester Results (1-1 to 2-2)</h3>
            <p className="text-xs text-[#777B74] mb-4">Five subjects per semester where records are available. Failed subjects are highlighted.</p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB] text-[#777B74] uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5 rounded-l-xl">Semester</th>
                    <th className="p-3.5">Code</th>
                    <th className="p-3.5">Subject</th>
                    <th className="p-3.5">Marks Obtained</th>
                    <th className="p-3.5">Max</th>
                    <th className="p-3.5">Grade</th>
                    <th className="p-3.5 rounded-r-xl">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {(profile?.academicRecords || []).filter((sub: any) => Number(sub.semester) <= 4).map((sub: any) => (
                    <tr key={sub.id} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-semibold">{({1:'1-1',2:'1-2',3:'2-1',4:'2-2'} as Record<number,string>)[Number(sub.semester)] || `Sem ${sub.semester}`}</td>
                      <td className="p-3.5 font-mono font-bold text-[#344D42]">{sub.subject_code}</td>
                      <td className="p-3.5 font-medium text-[#292D29]">{sub.subject_name}</td>
                      <td className="p-3.5 font-bold">{sub.marks_obtained}</td>
                      <td className="p-3.5 text-[#777B74]">{sub.max_marks}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded font-bold ${sub.grade === 'F' ? 'bg-rose-100 text-[#C66F68]' : 'bg-emerald-50 text-[#43866A]'}`}>
                          {sub.grade}
                        </span>
                      </td>
                      <td className={`p-3.5 font-semibold ${String(sub.grade).toUpperCase() === 'F' || Number(sub.marks_obtained) < 40 ? 'text-[#C66F68]' : 'text-[#43866A]'}`}>{String(sub.grade).toUpperCase() === 'F' || Number(sub.marks_obtained) < 40 ? 'Failed' : 'Passed'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ATTENDANCE */}
      {currentTab === 'attendance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm text-center">
              <span className="text-xs text-[#777B74] uppercase font-semibold">Cumulative Attendance</span>
              <p className="text-4xl font-extrabold text-[#344D42] my-2">{student?.attendance_percentage}%</p>
              <p className="text-xs text-[#43866A] font-medium">Eligible for end-semester finals</p>
            </div>
            <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm text-center">
              <span className="text-xs text-[#777B74] uppercase font-semibold">Classes Attended</span>
              <p className="text-4xl font-extrabold text-[#292D29] my-2">107 / 120</p>
              <p className="text-xs text-[#777B74]">Across all lecture & lab tracks</p>
            </div>
            <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm text-center">
              <span className="text-xs text-[#777B74] uppercase font-semibold">Condonation Margin</span>
              <p className="text-4xl font-extrabold text-[#43866A] my-2">+14.2%</p>
              <p className="text-xs text-[#777B74]">Buffer above statutory 75% limit</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Monthly Attendance History</h3>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={profile?.attendanceRecords || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F3F1EB" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="percentage" fill="#4F6257" radius={[6, 6, 0, 0]} name="Attendance %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: LMS */}
      {currentTab === 'lms' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Digital Course Activity & Lab Progress</h3>
            <div className="space-y-4">
              {profile?.lmsRecords?.map((lms: any) => (
                <div key={lms.id} className="p-4 bg-[#F3F1EB]/50 rounded-2xl border border-[#E7E5DE]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-xs text-[#292D29]">{lms.course_name}</span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-white text-[#344D42] border border-[#E7E5DE]">
                      {lms.assignment_status}
                    </span>
                  </div>
                  <div className="w-full bg-[#E7E5DE] h-2 rounded-full overflow-hidden my-2">
                    <div className="bg-[#344D42] h-full" style={{ width: `${lms.completion_percentage}%` }}></div>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#777B74]">
                    <span>Modules: {lms.modules_completed}/{lms.total_modules} completed</span>
                    <span>Quiz Average: {lms.quiz_score}/100</span>
                    <span>Time Spent: {lms.time_spent_hours} hrs</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SKILLS */}
      {currentTab === 'skills' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Skills & Mastery Matrix</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {profile?.skillRecords?.map((sk: any) => (
                <div key={sk.id} className="p-4 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE]">
                  <div className="flex justify-between font-bold text-xs mb-1">
                    <span className="text-[#292D29]">{sk.skill_name}</span>
                    <span className="text-[#344D42]">{sk.score}/100</span>
                  </div>
                  <span className="text-[10px] text-[#777B74] uppercase tracking-wider block mb-2">{sk.category}</span>
                  <div className="w-full bg-[#E7E5DE] h-2 rounded-full overflow-hidden">
                    <div className="bg-[#43866A] h-full" style={{ width: `${sk.score}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PLACEMENT READINESS */}
      {currentTab === 'placement' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <MetricCard title="Coding Score" value={`${student?.coding_score}/100`} variant="white" icon={Code2} />
            <MetricCard title="Aptitude Score" value={`${student?.aptitude_score}/100`} variant="white" icon={Brain} />
            <MetricCard title="Mock Interview" value={`${student?.mock_interview_score}/100`} variant="white" icon={MessageSquare} />
            <MetricCard title="Eligible Companies" value={`${profile?.placementRecord?.eligible_companies_count || 18}`} variant="emerald" icon={Award} />
          </div>

          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-2">Practice & Assessment Center</h3>
            <p className="text-xs text-[#777B74] mb-4">Launch a practice activity and record a practice score. These local practice actions are a UI prototype; connect a question bank and scoring API for formal assessments.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 bg-[#F3F1EB] rounded-2xl"><Code2 className="w-5 h-5 text-[#344D42] mb-2"/><p className="text-xs font-bold">Coding Challenge</p><p className="text-[11px] text-[#777B74] my-2">Arrays, strings, sorting and problem solving</p><button type="button" onClick={() => setPracticeResults(prev => ({...prev, coding: Math.min(100, Number(student?.coding_score || 0) + 5)}))} className="px-3 py-2 rounded-lg bg-[#344D42] text-white text-[11px] font-bold">Submit practice</button>{practiceResults.coding !== undefined && <p className="text-xs font-bold text-[#43866A] mt-2">Practice score: {practiceResults.coding}/100</p>}</div>
              <div className="p-4 bg-[#F3F1EB] rounded-2xl"><Brain className="w-5 h-5 text-[#344D42] mb-2"/><p className="text-xs font-bold">Aptitude Test</p><p className="text-[11px] text-[#777B74] my-2">Quantitative, logical reasoning and verbal ability</p><button type="button" onClick={() => setPracticeResults(prev => ({...prev, aptitude: Math.min(100, Number(student?.aptitude_score || 0) + 3)}))} className="px-3 py-2 rounded-lg bg-[#344D42] text-white text-[11px] font-bold">Submit practice</button>{practiceResults.aptitude !== undefined && <p className="text-xs font-bold text-[#43866A] mt-2">Practice score: {practiceResults.aptitude}/100</p>}</div>
              <div className="p-4 bg-[#F3F1EB] rounded-2xl"><MessageSquare className="w-5 h-5 text-[#344D42] mb-2"/><p className="text-xs font-bold">Mock Interview</p><p className="text-[11px] text-[#777B74] my-2">Communication, project explanation and HR readiness</p><button type="button" onClick={() => setPracticeResults(prev => ({...prev, interview: Math.min(100, Number(student?.mock_interview_score || 0) + 4)}))} className="px-3 py-2 rounded-lg bg-[#344D42] text-white text-[11px] font-bold">Complete mock</button>{practiceResults.interview !== undefined && <p className="text-xs font-bold text-[#43866A] mt-2">Practice score: {practiceResults.interview}/100</p>}</div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-2">Campus Recruitment Readiness Status</h3>
            <p className="text-xs text-[#777B74] mb-4">
              Based on your current technical scores and academic zero-backlog record, you meet the eligibility criteria for 18 upcoming campus placement drives.
            </p>
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-[#344D42]">
              <span className="font-bold">Recruiter Advice: </span>
              Dedicate focus to algorithmic graph problems and time-boxed aptitude mocks to convert shortlisted tests into final offers.
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: RECOMMENDATIONS */}
      {currentTab === 'recommendations' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-2">Personalized Success Plan</h3>
            <p className="text-xs text-[#777B74] mb-6">
              AI-generated learning actions and campus resources tailored to your specific score drivers.
            </p>
            <div className="space-y-3">
              {recommendations.map((rec) => (
                <div key={rec.id} className="p-4 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE] flex items-start justify-between gap-4">
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#292D29]">{rec.title}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        rec.priority === 'High' ? 'bg-rose-100 text-[#C66F68]' : 'bg-emerald-100 text-[#43866A]'
                      }`}>
                        {rec.priority} Priority
                      </span>
                    </div>
                    <p className="text-[#52574F]">{rec.description}</p>
                    <p className="text-[11px] text-[#777B74]">
                      Resource: <span className="font-medium text-[#344D42]">{rec.resource}</span> ({rec.estimatedHours})
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: PROFILE */}
      {currentTab === 'profile' && (
        <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-4 text-xs">
          <h3 className="text-base font-bold text-[#292D29]">Institutional Student Profile</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-[#F3F1EB] rounded-xl">
              <span className="text-[#777B74]">Student Roll Number:</span>
              <p className="font-bold text-sm text-[#292D29]">{student?.id}</p>
            </div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl">
              <span className="text-[#777B74]">College Email:</span>
              <p className="font-bold text-sm text-[#292D29]">{student?.email}</p>
            </div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl">
              <span className="text-[#777B74]">Department:</span>
              <p className="font-bold text-sm text-[#292D29]">{student?.department}</p>
            </div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl">
              <span className="text-[#777B74]">Academic Year & Semester:</span>
              <p className="font-bold text-sm text-[#292D29]">Year {student?.current_year} · Semester {student?.current_semester}</p>
            </div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl"><span className="text-[#777B74]">Contact Number:</span><p className="font-bold text-sm text-[#292D29]">Not provided in student record</p></div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl"><span className="text-[#777B74]">Address:</span><p className="font-bold text-sm text-[#292D29]">Not provided in student record</p></div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl"><span className="text-[#777B74]">College:</span><p className="font-bold text-sm text-[#292D29]">StudentLens Campus</p></div>
            <div className="p-3 bg-[#F3F1EB] rounded-xl"><span className="text-[#777B74]">Professional Goal:</span><p className="font-bold text-sm text-[#292D29]">Placement readiness and skill development</p></div>
          </div>
        </div>
      )}

      {/* TAB 9: SETTINGS */}
      {currentTab === 'settings' && (
        <div className="space-y-5 text-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-bold text-[#292D29]">Settings & Preferences</h2>
              <p className="text-sm text-[#777B74] mt-1">Personalise your StudentLens experience, notifications, privacy and study routine.</p>
            </div>
            <div className="flex items-center gap-2">
              <button type="button" onClick={resetPreferences} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#E7E5DE] bg-white text-[#344D42] font-semibold hover:bg-[#F3F1EB]"><RotateCcw className="w-4 h-4"/> Restore defaults</button>
              <button type="button" onClick={savePreferences} className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#344D42] text-white font-semibold hover:bg-[#263B32]"><CheckCircle className="w-4 h-4"/> Save settings</button>
            </div>
          </div>
          {settingsSaved && <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-100"><CheckCircle className="w-4 h-4"/> Your preferences have been saved on this device.</div>}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            <section className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-4">
              <div className="flex items-center gap-3"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><Bell className="w-5 h-5"/></div><div><h3 className="text-base font-bold text-[#292D29]">Notifications</h3><p className="text-[#777B74] mt-1">Choose what StudentLens should remind you about.</p></div></div>
              {([['weeklyProgress','Weekly progress summary','Get a weekly Student Success Score and CGPA progress recap.'],['attendanceAlerts','Attendance alerts','Receive a reminder if attendance drops below 80%.'],['placementAlerts','Placement and mock-test alerts','Know when a placement practice test or mock interview is available.'],['assignmentReminders','Assignment due dates','Reminders for upcoming assignments and lab submissions.'],['emailNotifications','Email notifications','Allow account and academic notifications by email.']] as const).map(([key,label,desc])=><label key={key} className="flex items-start justify-between gap-4 py-2 border-b last:border-0 border-[#F0EEE8] cursor-pointer"><span><span className="block font-semibold text-[#292D29]">{label}</span><span className="block text-[#777B74] mt-1">{desc}</span></span><input type="checkbox" checked={preferences[key]} onChange={e=>updatePreference(key,e.target.checked)} className="mt-1 w-4 h-4 accent-[#344D42] shrink-0"/></label>)}
            </section>
            <section className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-4">
              <div className="flex items-center gap-3"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><ShieldCheck className="w-5 h-5"/></div><div><h3 className="text-base font-bold text-[#292D29]">Privacy & Security</h3><p className="text-[#777B74] mt-1">Control how your learning information is shared.</p></div></div>
              {([['shareProgressWithFaculty','Share progress with faculty','Allow your assigned faculty to view your academic progress.'],['profileVisibleToPeers','Show profile to classmates','Allow other students to see your basic profile.'],['securityAlerts','Security alerts','Notify me about important account and sign-in activity.']] as const).map(([key,label,desc])=><label key={key} className="flex items-start justify-between gap-4 py-2 border-b last:border-0 border-[#F0EEE8] cursor-pointer"><span><span className="block font-semibold text-[#292D29]">{label}</span><span className="block text-[#777B74] mt-1">{desc}</span></span><input type="checkbox" checked={preferences[key]} onChange={e=>updatePreference(key,e.target.checked)} className="mt-1 w-4 h-4 accent-[#344D42] shrink-0"/></label>)}
              <p className="p-3 rounded-xl bg-[#F3F1EB] text-[#777B74]">Password changes and multi-factor authentication must be configured through your institution's account service.</p>
            </section>
            <section className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-4">
              <div className="flex items-center gap-3"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><Clock3 className="w-5 h-5"/></div><div><h3 className="text-base font-bold text-[#292D29]">Study Routine</h3><p className="text-[#777B74] mt-1">Set a realistic weekly learning target.</p></div></div>
              <label className="block"><span className="block font-semibold text-[#292D29] mb-2">Weekly study goal</span><select value={preferences.weeklyStudyGoal} onChange={e=>updatePreference('weeklyStudyGoal',e.target.value)} className="w-full p-3 rounded-xl border border-[#E7E5DE] bg-white"><option value="5">5 hours per week</option><option value="8">8 hours per week</option><option value="12">12 hours per week</option><option value="15">15 hours per week</option><option value="20">20 hours per week</option></select></label>
              <label className="block"><span className="block font-semibold text-[#292D29] mb-2">Daily reminder time</span><select value={preferences.reminderTime} onChange={e=>updatePreference('reminderTime',e.target.value)} className="w-full p-3 rounded-xl border border-[#E7E5DE] bg-white"><option value="07:00">7:00 AM</option><option value="12:00">12:00 PM</option><option value="18:00">6:00 PM</option><option value="20:00">8:00 PM</option><option value="21:00">9:00 PM</option></select></label>
              <label className="flex items-center justify-between gap-4 py-2 cursor-pointer"><span><span className="block font-semibold text-[#292D29]">Study reminders</span><span className="block text-[#777B74] mt-1">Enable your preferred study routine reminder.</span></span><input type="checkbox" checked={preferences.studyReminders} onChange={e=>updatePreference('studyReminders',e.target.checked)} className="w-4 h-4 accent-[#344D42]"/></label>
            </section>
            <section className="bg-white p-5 sm:p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-4">
              <div className="flex items-center gap-3"><div className="p-2.5 rounded-xl bg-[#EEF2ED] text-[#344D42]"><Palette className="w-5 h-5"/></div><div><h3 className="text-base font-bold text-[#292D29]">Appearance & Accessibility</h3><p className="text-[#777B74] mt-1">Adjust the interface to suit your preferences.</p></div></div>
              <label className="block"><span className="block font-semibold text-[#292D29] mb-2"><Globe className="w-4 h-4 inline mr-2"/>Language</span><select value={preferences.language} onChange={e=>updatePreference('language',e.target.value)} className="w-full p-3 rounded-xl border border-[#E7E5DE] bg-white"><option>English</option><option>తెలుగు</option><option>हिन्दी</option></select><span className="block text-[#777B74] mt-2">Language preference is saved; full translation depends on platform language support.</span></label>
              {([['compactView','Compact layout','Use a denser layout where supported.'],['reduceMotion','Reduce animations','Prefer fewer animated transitions where supported.']] as const).map(([key,label,desc])=><label key={key} className="flex items-start justify-between gap-4 py-2 border-b last:border-0 border-[#F0EEE8] cursor-pointer"><span><span className="block font-semibold text-[#292D29]">{label}</span><span className="block text-[#777B74] mt-1">{desc}</span></span><input type="checkbox" checked={preferences[key]} onChange={e=>updatePreference(key,e.target.checked)} className="mt-1 w-4 h-4 accent-[#344D42] shrink-0"/></label>)}
            </section>
          </div>
          <div className="bg-[#F3F1EB] rounded-2xl p-4 flex items-start gap-3"><Eye className="w-5 h-5 text-[#344D42] mt-0.5 shrink-0"/><div><p className="font-semibold text-[#292D29]">Your settings stay yours</p><p className="text-[#777B74] mt-1">Preferences are saved in this browser on this device. They are not synced to your account or other devices in this demo version.</p></div></div>
        </div>
      )}
    </div>
  );
};
