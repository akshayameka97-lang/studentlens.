import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  CalendarCheck,
  Activity,
  Briefcase,
  Sparkles,
  Brain,
  ShieldAlert,
  Layers,
  FolderKanban,
  FileSpreadsheet,
  FileText,
  Sliders,
  Upload,
  Download,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  Eye,
  Plus,
  Clock,
  ArrowRight
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { apiFetch } from '../../api/client';
import { MetricCard } from '../../components/common/MetricCard';
import { StudentDetailModal } from '../../components/common/StudentDetailModal';
import { PortalSettings } from '../../components/common/PortalSettings';

interface AdminDashboardProps {
  currentTab: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentTab }) => {
  const { user } = useAuth();
  const [overview, setOverview] = useState<any>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [segments, setSegments] = useState<any[]>([]);
  const [interventions, setInterventions] = useState<any[]>([]);
  const [importHistory, setImportHistory] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [newUser, setNewUser] = useState({ full_name: '', email: '', password: '', role: 'student', college_id: '', department: 'Computer Science' });
  const [userCreateNotice, setUserCreateNotice] = useState<string | null>(null);
  const [creatingUser, setCreatingUser] = useState(false);
  const [loading, setLoading] = useState(true);

  // CSV Import state
  const [importCategory, setImportCategory] = useState<'academic' | 'attendance' | 'placement' | 'skills' | 'lms'>('academic');
  const [csvContent, setCsvContent] = useState('');
  const [importFileName, setImportFileName] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);

  // Selected Student Drill-Down
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');

  // Reset demo dataset notice
  const [resetNotice, setResetNotice] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [ovRes, stRes, segRes, invRes, histRes, uRes] = await Promise.all([
        apiFetch<any>('/api/analytics/overview'),
        apiFetch<any>('/api/students?limit=100'),
        apiFetch<any>('/api/analytics/segments'),
        apiFetch<any>('/api/interventions'),
        apiFetch<any>('/api/import/history'),
        apiFetch<any>('/api/users'),
      ]);
      setOverview(ovRes);
      setStudents(stRes.data || []);
      setSegments(segRes.segments || []);
      setInterventions(invRes.interventions || []);
      setImportHistory(histRes.history || []);
      setUsersList(uRes.users || []);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCsvFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      setCsvContent(event.target?.result as string);
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = async () => {
    if (!csvContent) {
      alert('Please select or paste CSV content first.');
      return;
    }

    try {
      setIsImporting(true);
      setImportResult(null);
      const res = await apiFetch<any>('/api/import/csv', {
        method: 'POST',
        body: JSON.stringify({
          category: importCategory,
          csvContent,
          fileName: importFileName || `${importCategory}_upload.csv`,
        }),
      });
      setImportResult(res);
      // Reload overview and students
      loadData();
    } catch (err: any) {
      setImportResult({ error: err.message || 'Import failed.' });
    } finally {
      setIsImporting(false);
    }
  };

  const handleLoadSampleCsv = (category: 'academic' | 'attendance' | 'placement' | 'skills') => {
    setImportCategory(category);
    if (category === 'academic') {
      setCsvContent(`student_id,semester,subject_code,subject_name,marks_obtained,max_marks,grade,exam_type
STU-2024-001,5,CS501,Distributed Systems,88,100,A+,MidTerm
STU-2024-002,5,CS501,Distributed Systems,76,100,A,MidTerm
STU-2024-003,5,CS501,Distributed Systems,62,100,B+,MidTerm`);
      setImportFileName('sample_academic_data.csv');
    } else if (category === 'attendance') {
      setCsvContent(`student_id,month,subject_name,attended_classes,total_classes,percentage
STU-2024-001,October,Composite Attendance,28,30,93.3
STU-2024-002,October,Composite Attendance,24,30,80.0
STU-2024-003,October,Composite Attendance,19,30,63.3`);
      setImportFileName('sample_attendance_data.csv');
    } else if (category === 'placement') {
      setCsvContent(`student_id,aptitude_score,coding_score,mock_interview_score,communication_score
STU-2024-001,82,78,80,85
STU-2024-002,74,68,70,72
STU-2024-003,52,48,50,56`);
      setImportFileName('sample_placement_data.csv');
    } else {
      setCsvContent(`student_id,skill_name,category,score
STU-2024-001,System Architecture,Technical,86
STU-2024-002,Docker & Containers,Technical,74
STU-2024-003,Problem Solving,Technical,58`);
      setImportFileName('sample_skills_data.csv');
    }
  };

  const handleResetDemoData = async () => {
    if (!confirm('Reset local database to initial 110 demo students?')) return;
    try {
      setResetNotice('Resetting and seeding demo database...');
      await apiFetch('/api/admin/reset-demo-data', { method: 'POST' });
      setResetNotice('Database reset successfully with 110 student records.');
      loadData();
      setTimeout(() => setResetNotice(null), 4000);
    } catch (err: any) {
      setResetNotice('Reset failed: ' + err.message);
    }
  };

  const handleExportCsv = async () => {
    try {
      const blob = await apiFetch<Blob>('/api/import/export');
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `StudentLens_Institutional_Analytics_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      console.error('Export failed:', err);
    }
  };



  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      !searchTerm ||
      s.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === 'All' || s.department === selectedDept;
    return matchesSearch && matchesDept;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px] text-[#777B74] text-sm">
        <Clock className="w-5 h-5 animate-spin mr-2" />
        Loading institutional intelligence...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {(currentTab === 'overview' || !currentTab) && (
      <>
      {/* Top Banner */}
      <div className="bg-[#344D42] text-white p-6 lg:p-8 rounded-[24px] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#A5B8A8]">
            Provost & Dean Institutional Governance
          </span>
          <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight mt-1">
            Institutional Success Intelligence
          </h2>
          <p className="text-xs text-[#DCE5DC]/80 mt-1">
            Cross-department student performance, explainable risk detection, and intervention efficacy
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-full border border-white/20 transition-all"
          >
            <Download className="w-4 h-4 text-[#A5B8A8]" />
            Export Data (CSV)
          </button>

        </div>
      </div>
      </>
      )}

      {resetNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-[#344D42] text-xs font-semibold rounded-xl">
          {resetNotice}
        </div>
      )}

      {(currentTab === 'overview' || !currentTab) && (
      <>
      {/* Primary KPI Grid (FlowGrid.ai style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Registered Students"
          value={overview?.totalStudents || 110}
          subtitle="Across 5 undergraduate faculties"
          change="+12.0%"
          changeType="positive"
          variant="white"
          icon={Users}
        />
        <MetricCard
          title="Campus Success Average"
          value={`${overview?.averageSuccessScore || 81.2}`}
          subtitle="Explainable weighted benchmark"
          change="+3.4%"
          changeType="positive"
          variant="white"
          icon={Sparkles}
        />
        <MetricCard
          title="On-Track Cohort"
          value={`${overview?.statusDistribution?.onTrack || 68}`}
          subtitle="Success Score ≥ 80.0"
          change="62% of campus"
          changeType="positive"
          variant="white"
          icon={CheckCircle2}
        />
        <MetricCard
          title="Intervention Required"
          value={`${(overview?.statusDistribution?.needsAttention || 28) + (overview?.statusDistribution?.atRisk || 14)}`}
          subtitle="Needs Attention or At-Risk"
          change="Prioritized"
          changeType="negative"
          variant="emerald"
          icon={ShieldAlert}
        />
      </div>
      </>
      )}

      {/* TAB 1: INSTITUTIONAL OVERVIEW */}
      {(currentTab === 'overview' || !currentTab) && (
        <div className="space-y-6">
          {/* Main Visual Dynamics Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Department Comparison Bar Chart (7 Cols) */}
            <div className="lg:col-span-7 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-[#292D29]">Department Performance Matrix</h3>
                  <p className="text-xs text-[#777B74]">Average Success Score & CGPA across departments</p>
                </div>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={overview?.departmentBreakdown || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F1EB" />
                    <XAxis dataKey="department" tick={{ fontSize: 10, fill: '#777B74' }} />
                    <YAxis domain={[50, 100]} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="avgSuccessScore" fill="#344D42" radius={[6, 6, 0, 0]} name="Avg Success Score" />
                    <Bar dataKey="avgPlacement" fill="#668575" radius={[6, 6, 0, 0]} name="Avg Placement Readiness" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Score Tier Distribution (5 Cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-[#292D29]">Institutional Score Distribution</h3>
                <p className="text-xs text-[#777B74]">Proportion of student cohort across score tiers</p>
              </div>

              <div className="h-56 w-full my-auto">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={overview?.scoreDistribution || []}
                      dataKey="count"
                      nameKey="range"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={4}
                    >
                      {overview?.scoreDistribution?.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="pt-3 border-t border-[#F3F1EB] grid grid-cols-2 gap-2 text-xs text-[#777B74]">
                <span>Excellence (90+): {overview?.scoreDistribution?.[0]?.count}</span>
                <span>On Track (80-89): {overview?.scoreDistribution?.[1]?.count}</span>
                <span>Moderate: {overview?.scoreDistribution?.[2]?.count}</span>
                <span className="text-[#C66F68] font-semibold">At Risk: {overview?.scoreDistribution?.[4]?.count}</span>
              </div>
            </div>
          </div>

          {/* Department Breakdown Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {overview?.departmentBreakdown?.map((dept: any) => (
              <div key={dept.department} className="p-4 bg-white rounded-2xl border border-[#E7E5DE] shadow-sm text-xs space-y-1.5">
                <span className="font-bold text-[#292D29] block truncate">{dept.department}</span>
                <div className="flex justify-between text-[#777B74]">
                  <span>Students:</span>
                  <span className="font-bold text-[#292D29]">{dept.studentCount}</span>
                </div>
                <div className="flex justify-between text-[#777B74]">
                  <span>Success Avg:</span>
                  <span className="font-bold text-[#344D42]">{dept.avgSuccessScore}/100</span>
                </div>
                <div className="flex justify-between text-[#777B74]">
                  <span>Placement Avg:</span>
                  <span className="font-bold text-[#668575]">{dept.avgPlacement}/100</span>
                </div>
                <div className="flex justify-between text-[#777B74]">
                  <span>At-Risk Cohort:</span>
                  <span className="font-bold text-[#C66F68]">{dept.atRiskCount}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: STUDENT DIRECTORY */}
      {currentTab === 'students' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-[22px] border border-[#E7E5DE] shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#777B74]" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by student name or roll ID..."
                className="w-full pl-10 pr-4 py-2 bg-[#F3F1EB]/50 border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs"
            >
              <option value="All">All Departments</option>
              <option value="Computer Science">Computer Science</option>
              <option value="Information Technology">Information Technology</option>
              <option value="Data Science">Data Science</option>
              <option value="Electronics & Comm">Electronics & Comm</option>
              <option value="Mechanical Engineering">Mechanical</option>
            </select>
          </div>

          <div className="bg-white rounded-[22px] border border-[#E7E5DE] overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB]/50 text-[#777B74] uppercase tracking-wider font-semibold border-b border-[#E7E5DE]">
                  <tr>
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Department</th>
                    <th className="p-3.5">Year</th>
                    <th className="p-3.5">CGPA</th>
                    <th className="p-3.5">Attendance</th>
                    <th className="p-3.5">Success Score</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Profile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {filteredStudents.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-mono font-bold text-[#344D42]">{s.id}</td>
                      <td className="p-3.5 font-semibold text-[#292D29]">{s.full_name}</td>
                      <td className="p-3.5">{s.department}</td>
                      <td className="p-3.5">Year {s.current_year} (S{s.current_semester})</td>
                      <td className="p-3.5 font-bold">{s.cgpa}</td>
                      <td className="p-3.5 font-medium">{s.attendance_percentage}%</td>
                      <td className="p-3.5 font-extrabold text-[#344D42]">{s.success_score}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.status === 'On Track' ? 'bg-emerald-50 text-[#43866A]' :
                          s.status === 'Needs Attention' ? 'bg-amber-50 text-[#D7A45A]' : 'bg-rose-50 text-[#C66F68]'
                        }`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <button
                          onClick={() => setSelectedStudentId(s.id)}
                          className="px-2.5 py-1 bg-[#F3F1EB] hover:bg-[#E7E5DE] text-[#344D42] rounded-lg text-[11px] font-semibold flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" /> View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: SUCCESS INTELLIGENCE & CORRELATIONS (Section 7.C) */}
      {(currentTab === 'intelligence' || currentTab === 'academics') && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-1">
              Attendance vs CGPA Correlation Plot
            </h3>
            <p className="text-xs text-[#777B74] mb-4">
              Empirical correlation: Students maintaining ≥ 85% attendance exhibit an average +1.2 CGPA premium.
            </p>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F3F1EB" />
                  <XAxis type="number" dataKey="attendance" name="Attendance %" unit="%" domain={[50, 100]} tick={{ fontSize: 11 }} />
                  <YAxis type="number" dataKey="cgpa" name="CGPA" domain={[4, 10]} tick={{ fontSize: 11 }} />
                  <ZAxis range={[60, 60]} />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                  <Scatter name="Students" data={overview?.correlationSample || []} fill="#344D42" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 10: SEGMENTATION */}
      {currentTab === 'segments' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-1">Campus-wide Student Segmentation</h3>
            <p className="text-xs text-[#777B74] mb-6">Transparent heuristic cohorts for targeted academic and placement interventions.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {segments.map((seg) => (
                <div key={seg.id} className="p-5 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE] space-y-3 text-xs">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-bold text-sm text-[#292D29]">{seg.name}</span>
                      <p className="text-[11px] font-mono text-[#777B74] mt-0.5">{seg.criteria}</p>
                    </div>
                    <span
                      className="px-2.5 py-1 rounded-full text-xs font-bold text-white shrink-0"
                      style={{ backgroundColor: seg.color }}
                    >
                      {seg.studentCount} Students ({seg.percentage}%)
                    </span>
                  </div>

                  <p className="text-[#52574F]">{seg.description}</p>
                  <div className="p-3 bg-white rounded-xl border border-[#E7E5DE]">
                    <span className="font-bold text-[#344D42] block mb-0.5">Policy Action:</span>
                    <span className="text-[#52574F] text-[11px]">{seg.recommendedIntervention}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 12: DATA INTEGRATION (CSV UPLOAD & IMPORT) */}
      {currentTab === 'integration' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-[#292D29] flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-[#344D42]" /> Institutional CSV Data Integration Portal
                </h3>
                <p className="text-xs text-[#777B74]">
                  Upload and map student records from legacy LMS, ERP, or placement systems. Validates duplicate rows and recalculates success scores automatically.
                </p>
              </div>
            </div>

            {/* Quick Sample Data Buttons */}
            <div className="mb-6 p-4 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE]">
              <span className="text-xs font-bold text-[#292D29] block mb-2">
                1-Click Sample Datasets for Testing:
              </span>
              <div className="flex flex-wrap gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => handleLoadSampleCsv('academic')}
                  className="px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-xl hover:bg-[#DCE5DC] text-[#344D42] font-semibold transition-colors"
                >
                  Load Academic CSV
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadSampleCsv('attendance')}
                  className="px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-xl hover:bg-[#DCE5DC] text-[#344D42] font-semibold transition-colors"
                >
                  Load Attendance CSV
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadSampleCsv('placement')}
                  className="px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-xl hover:bg-[#DCE5DC] text-[#344D42] font-semibold transition-colors"
                >
                  Load Placement CSV
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadSampleCsv('skills')}
                  className="px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-xl hover:bg-[#DCE5DC] text-[#344D42] font-semibold transition-colors"
                >
                  Load Skills CSV
                </button>
              </div>
            </div>

            {/* Upload form */}
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#292D29] mb-1">Target Category *</label>
                  <select
                    value={importCategory}
                    onChange={(e) => setImportCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl text-xs"
                  >
                    <option value="academic">Academic Records (Subject Marks)</option>
                    <option value="attendance">Attendance Records (Monthly %)</option>
                    <option value="placement">Placement Scores (Aptitude/Coding)</option>
                    <option value="skills">Skill Assessments</option>
                    <option value="lms">LMS Course Progress</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#292D29] mb-1">Select File from Computer</label>
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleCsvFileUpload}
                    className="w-full px-3 py-1.5 bg-white border border-[#E7E5DE] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#292D29] mb-1">CSV Content (Directly Editable or Preview)</label>
                <textarea
                  value={csvContent}
                  onChange={(e) => setCsvContent(e.target.value)}
                  placeholder="Paste CSV rows here or load sample above..."
                  rows={6}
                  className="w-full font-mono text-xs p-3.5 bg-[#F3F1EB]/50 border border-[#E7E5DE] rounded-xl focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-[#777B74]">
                  {csvContent ? `${csvContent.split('\n').filter(Boolean).length - 1} rows detected` : 'No data entered'}
                </span>
                <button
                  type="button"
                  onClick={handleExecuteImport}
                  disabled={isImporting || !csvContent}
                  className="px-6 py-2.5 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-xl font-bold shadow-md disabled:opacity-50 transition-all flex items-center gap-2"
                >
                  {isImporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                  Validate & Ingest CSV Records
                </button>
              </div>

              {/* Import Feedback */}
              {importResult && (
                <div className={`p-4 rounded-xl border mt-4 ${
                  importResult.error ? 'bg-rose-50 border-rose-200 text-[#C66F68]' : 'bg-emerald-50 border-emerald-200 text-[#344D42]'
                }`}>
                  <p className="font-bold text-xs">{importResult.message || importResult.error}</p>
                  {importResult.summary && (
                    <p className="text-[11px] mt-1">
                      Successful rows: {importResult.summary.successful} · Failed rows: {importResult.summary.failed}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Import History */}
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h4 className="text-xs font-bold uppercase text-[#777B74] mb-3">Previous Import Jobs</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB] text-[#777B74]">
                  <tr>
                    <th className="p-3">Job ID</th>
                    <th className="p-3">File Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Records</th>
                    <th className="p-3">Success</th>
                    <th className="p-3">Imported By</th>
                    <th className="p-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {importHistory.map((job) => (
                    <tr key={job.id}>
                      <td className="p-3 font-mono font-bold text-[#344D42]">{job.id}</td>
                      <td className="p-3">{job.file_name}</td>
                      <td className="p-3 capitalize">{job.category}</td>
                      <td className="p-3">{job.total_records}</td>
                      <td className="p-3 font-bold text-[#43866A]">{job.successful_records}</td>
                      <td className="p-3">{job.imported_by}</td>
                      <td className="p-3 text-[#777B74]">{job.created_at}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 14: USER MANAGEMENT */}
      {currentTab === 'users' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-1">Create Student / Faculty Access</h3>
            <p className="text-xs text-[#777B74] mb-4">Create a login and assign a college ID. Share the ID, email, and temporary password securely with the user.</p>
            <form className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3" onSubmit={async (e) => { e.preventDefault(); setCreatingUser(true); setUserCreateNotice(null); try { const payload: any = { ...newUser, confirm_password: newUser.password, designation: newUser.role === 'student' ? 'Student' : 'Faculty' }; if (newUser.role === 'student') payload.student_id = newUser.college_id; else if (newUser.role === 'faculty') payload.faculty_id = newUser.college_id; else payload.admin_id = newUser.college_id; delete payload.college_id; await apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) }); setUserCreateNotice('Account created successfully. The new user can now sign in.'); setNewUser({ full_name: '', email: '', password: '', role: 'student', college_id: '', department: 'Computer Science' }); await loadData(); } catch (err: any) { setUserCreateNotice(err.message || 'Could not create account.'); } finally { setCreatingUser(false); } }}>
              <input required value={newUser.full_name} onChange={e=>setNewUser({...newUser,full_name:e.target.value})} placeholder="Full name" className="p-3 rounded-xl border border-[#E7E5DE] text-xs" />
              <input required type="email" value={newUser.email} onChange={e=>setNewUser({...newUser,email:e.target.value})} placeholder="Email address" className="p-3 rounded-xl border border-[#E7E5DE] text-xs" />
              <input required minLength={6} type="password" value={newUser.password} onChange={e=>setNewUser({...newUser,password:e.target.value})} placeholder="Temporary password (6+ chars)" className="p-3 rounded-xl border border-[#E7E5DE] text-xs" />
              <select value={newUser.role} onChange={e=>setNewUser({...newUser,role:e.target.value})} className="p-3 rounded-xl border border-[#E7E5DE] text-xs"><option value="student">Student</option><option value="faculty">Faculty</option></select>
              <input required value={newUser.college_id} onChange={e=>setNewUser({...newUser,college_id:e.target.value})} placeholder={newUser.role === 'student' ? 'Student roll / college ID' : 'Faculty ID'} className="p-3 rounded-xl border border-[#E7E5DE] text-xs" />
              <input required value={newUser.department} onChange={e=>setNewUser({...newUser,department:e.target.value})} placeholder="Department" className="p-3 rounded-xl border border-[#E7E5DE] text-xs" />
              <button disabled={creatingUser} type="submit" className="px-4 py-3 rounded-xl bg-[#344D42] text-white text-xs font-bold disabled:opacity-50">{creatingUser ? 'Creating account…' : 'Create account'}</button>
            </form>
            {userCreateNotice && <p className="mt-3 text-xs font-semibold text-[#344D42]">{userCreateNotice}</p>}
          </div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Registered Institutional Accounts</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB] text-[#777B74]">
                  <tr>
                    <th className="p-3">Name</th>
                    <th className="p-3">Email</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Department</th>
                    <th className="p-3">Designation</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Created</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {usersList.map((u) => (
                    <tr key={u.id}>
                      <td className="p-3 font-bold text-[#292D29]">{u.full_name}</td>
                      <td className="p-3 text-[#777B74]">{u.email}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full uppercase text-[10px] font-bold bg-[#DCE5DC] text-[#344D42]">
                          {u.role}
                        </span>
                      </td>
                      <td className="p-3">{u.department || 'Main'}</td>
                      <td className="p-3 text-[#777B74]">{u.designation || 'Faculty/Student'}</td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-[#43866A]">
                          {u.status}
                        </span>
                      </td>
                      <td className="p-3 text-[#777B74]">{u.created_at}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 15: SETTINGS */}
      {currentTab === 'settings' && (
        <div className="space-y-6">
          <PortalSettings role="administrator" />
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm space-y-6 text-xs">
            <div>
              <h3 className="text-base font-bold text-[#292D29]">Institutional Success Formula Configuration</h3>
              <p className="text-[#777B74]">Transparent weights used in the deterministic Student Success Score calculation.</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 p-4 bg-[#F3F1EB] rounded-2xl">
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">Academic Performance:</span>
                <p className="text-lg font-bold text-[#344D42]">30% (0.30)</p>
              </div>
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">Attendance:</span>
                <p className="text-lg font-bold text-[#344D42]">20% (0.20)</p>
              </div>
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">Placement Readiness:</span>
                <p className="text-lg font-bold text-[#344D42]">20% (0.20)</p>
              </div>
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">LMS & Assignments:</span>
                <p className="text-lg font-bold text-[#344D42]">15% (0.15)</p>
              </div>
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">Skills Assessments:</span>
                <p className="text-lg font-bold text-[#344D42]">10% (0.10)</p>
              </div>
              <div className="p-3 bg-white rounded-xl">
                <span className="font-semibold text-[#292D29]">Engagement & Feedback:</span>
                <p className="text-lg font-bold text-[#344D42]">5% (0.05)</p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E7E5DE] flex items-center justify-between">
              <div>
                <span className="font-bold text-[#292D29]">Database Reset & Re-seed:</span>
                <p className="text-[#777B74]">Re-initializes SQLite database with fresh 110 diverse student records and 3 demo accounts.</p>
              </div>
              <button
                type="button"
                onClick={handleResetDemoData}
                className="px-4 py-2 bg-rose-50 border border-rose-200 text-[#C66F68] font-bold rounded-xl hover:bg-rose-100 transition-colors"
              >
                Reset Demo Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB: ATTENDANCE ANALYTICS */}
      {currentTab === 'attendance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard title="Campus Attendance Average" value={`${students.length ? (students.reduce((n, s) => n + Number(s.attendance_percentage || 0), 0) / students.length).toFixed(1) : '0'}%`} subtitle="Across loaded student records" icon={CalendarCheck} variant="white" />
            <MetricCard title="Below 75% Threshold" value={students.filter(s => Number(s.attendance_percentage || 0) < 75).length} subtitle="Needs follow-up" icon={ShieldAlert} variant="white" />
            <MetricCard title="Attendance ≥ 90%" value={students.filter(s => Number(s.attendance_percentage || 0) >= 90).length} subtitle="Strong attendance cohort" icon={CheckCircle2} variant="white" />
          </div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Student Attendance Watchlist</h3>
            <div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Department</th><th className="p-3">Year</th><th className="p-3">Attendance</th><th className="p-3">Action Status</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{[...students].sort((a,b) => Number(a.attendance_percentage || 0)-Number(b.attendance_percentage || 0)).slice(0,15).map(s => <tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{s.department}</td><td className="p-3">{s.current_year}</td><td className={`p-3 font-bold ${Number(s.attendance_percentage || 0) < 75 ? 'text-[#C66F68]' : 'text-[#43866A]'}`}>{Number(s.attendance_percentage || 0).toFixed(1)}%</td><td className="p-3">{Number(s.attendance_percentage || 0) < 75 ? 'Intervention recommended' : 'On track'}</td></tr>)}</tbody></table></div>
          </div>
        </div>
      )}

      {/* TAB: PLACEMENT ANALYTICS */}
      {currentTab === 'placement' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <MetricCard title="Average Placement Readiness" value={`${students.length ? (students.reduce((n, s) => n + Number(s.placement_readiness_score || 0), 0) / students.length).toFixed(1) : '0'}/100`} subtitle="Campus readiness index" icon={Briefcase} variant="white" />
            <MetricCard title="Coding Support Needed" value={students.filter(s => Number(s.coding_score || 0) < 50).length} subtitle="Coding score below 50" icon={Sparkles} variant="white" />
            <MetricCard title="Aptitude Support Needed" value={students.filter(s => Number(s.aptitude_score || 0) < 50).length} subtitle="Aptitude score below 50" icon={Brain} variant="white" />
          </div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Placement Readiness Leaderboard</h3><div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Coding</th><th className="p-3">Aptitude</th><th className="p-3">Mock Interview</th><th className="p-3">Readiness</th><th className="p-3">Recommended Track</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{[...students].sort((a,b) => Number(b.placement_readiness_score || 0)-Number(a.placement_readiness_score || 0)).slice(0,20).map(s => <tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{s.coding_score ?? 0}</td><td className="p-3">{s.aptitude_score ?? 0}</td><td className="p-3">{s.mock_interview_score ?? 0}</td><td className="p-3 font-bold">{s.placement_readiness_score ?? 0}/100</td><td className="p-3">{Number(s.coding_score || 0) < Number(s.aptitude_score || 0) ? 'Coding practice' : 'Aptitude & interview'}</td></tr>)}</tbody></table></div></div>
        </div>
      )}

      {/* TAB: SKILLS & FEEDBACK */}
      {currentTab === 'skills' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-2">Skills & Feedback Pulse</h3><p className="text-xs text-[#777B74] mb-4">Use this page to review student skill indicators and prepare feedback questions.</p><div className="grid grid-cols-1 sm:grid-cols-3 gap-4">{['Technical skills','Communication','Course satisfaction'].map((label, i) => <div key={label} className="p-4 bg-[#F3F1EB] rounded-2xl"><p className="text-xs text-[#777B74]">{label}</p><p className="text-2xl font-extrabold text-[#344D42]">{[students.length ? Math.round(students.reduce((n,s)=>n+Number(s.coding_score||0),0)/students.length) : 0, students.length ? Math.round(students.reduce((n,s)=>n+Number(s.communication_score||0),0)/students.length) : 0, 82][i]}/100</p><div className="h-2 bg-[#E7E5DE] rounded-full mt-3"><div className="h-2 bg-[#43866A] rounded-full" style={{width:`${[students.length ? Math.round(students.reduce((n,s)=>n+Number(s.coding_score||0),0)/students.length) : 0, students.length ? Math.round(students.reduce((n,s)=>n+Number(s.communication_score||0),0)/students.length) : 0, 82][i]}%`}} /></div></div>)}</div></div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-3">Skill Development Actions</h3><div className="space-y-3">{students.slice(0,8).map(s=><div key={s.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-[#F3F1EB]/60 rounded-xl"><div><p className="text-xs font-bold text-[#292D29]">{s.full_name}</p><p className="text-[11px] text-[#777B74]">{s.department} · {s.id}</p></div><p className="text-xs">{Number(s.coding_score||0)<60 ? 'Recommend weekly coding practice' : Number(s.communication_score||0)<60 ? 'Recommend communication workshop' : 'Continue advanced skill development'}</p></div>)}</div></div>
        </div>
      )}

      {/* TAB: RISK ANALYSIS */}
      {currentTab === 'risk' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><MetricCard title="High Attendance Risk" value={students.filter(s=>Number(s.attendance_percentage||0)<65).length} subtitle="Attendance below 65%" icon={ShieldAlert} variant="white"/><MetricCard title="Academic Risk" value={students.filter(s=>Number(s.cgpa||0)<6.5).length} subtitle="CGPA below 6.5" icon={GraduationCap} variant="white"/><MetricCard title="Placement Risk" value={students.filter(s=>Number(s.placement_readiness_score||0)<50).length} subtitle="Readiness below 50" icon={Briefcase} variant="white"/></div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Explainable Risk Register</h3><div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Risk Factors</th><th className="p-3">Priority</th><th className="p-3">Suggested Intervention</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{students.filter(s=>Number(s.attendance_percentage||0)<75 || Number(s.cgpa||0)<6.5 || Number(s.placement_readiness_score||0)<50).slice(0,25).map(s=><tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{[Number(s.attendance_percentage||0)<75?'Low attendance':'',Number(s.cgpa||0)<6.5?'Low CGPA':'',Number(s.placement_readiness_score||0)<50?'Low placement readiness':''].filter(Boolean).join(' · ')}</td><td className="p-3 font-bold text-[#C66F68]">High attention</td><td className="p-3">Assign mentor and create a 2-week improvement plan</td></tr>)}</tbody></table></div></div>
        </div>
      )}

      {/* Student Detail Modal */}
      {selectedStudentId && (
        <StudentDetailModal
          studentId={selectedStudentId}
          onClose={() => setSelectedStudentId(null)}
        />
      )}
    </div>
  );
};
