import React, { useState, useEffect } from 'react';
import {
  Users,
  AlertTriangle,
  FolderKanban,
  FileSpreadsheet,
  Layers,
  GraduationCap,
  CalendarCheck,
  BookOpen,
  Briefcase,
  Search,
  Filter,
  Plus,
  Clock,
  CheckCircle2,
  Download,
  Eye,
  TrendingDown,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { apiFetch } from '../../api/client';
import { MetricCard } from '../../components/common/MetricCard';
import { StudentDetailModal } from '../../components/common/StudentDetailModal';
import { NewInterventionModal } from '../../components/common/NewInterventionModal';
import { PortalSettings } from '../../components/common/PortalSettings';

interface FacultyDashboardProps {
  currentTab: string;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({ currentTab }) => {
  const { user } = useAuth();
  const [overview, setOverview] = useState<any>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [segments, setSegments] = useState<any[]>([]);
  const [interventions, setInterventions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');

  // Modals
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [interventionStudentId, setInterventionStudentId] = useState<string | null>(null);
  const [showInterventionModal, setShowInterventionModal] = useState(false);
  const [assignmentTitle, setAssignmentTitle] = useState('');
  const [assignmentDue, setAssignmentDue] = useState('');
  const [assignmentType, setAssignmentType] = useState<'Assignment' | 'Lab'>('Assignment');
  const [createdAssignments, setCreatedAssignments] = useState<Array<{id:number; title:string; due:string; type:'Assignment'|'Lab'}>>([]);

  // Risk Tab toggle: 'academic' vs 'placement'
  const [riskSubTab, setRiskSubTab] = useState<'academic' | 'placement'>('academic');

  const loadData = async () => {
    try {
      setLoading(true);
      const [ovRes, stRes, segRes, invRes] = await Promise.all([
        apiFetch<any>('/api/analytics/overview'),
        apiFetch<any>('/api/students?limit=100'),
        apiFetch<any>('/api/analytics/segments'),
        apiFetch<any>('/api/interventions'),
      ]);
      setOverview(ovRes);
      setStudents(stRes.data || []);
      setSegments(segRes.segments || []);
      setInterventions(invRes.interventions || []);
    } catch (err) {
      console.error('Failed to load faculty data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleUpdateInterventionStatus = async (id: string, newStatus: string) => {
    try {
      await apiFetch(`/api/interventions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: newStatus,
          outcome_notes: newStatus === 'Completed' ? 'Remedial milestone achieved; metrics cleared.' : 'Session in progress.',
          after_metric: 78.0,
        }),
      });
      loadData();
    } catch (err) {
      console.error('Error updating intervention:', err);
    }
  };

  const handleExportCsv = async () => {
    try {
      const blob = await apiFetch<Blob>('/api/import/export');
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `StudentLens_Faculty_Export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      console.error('Export failed:', err);
    }
  };

  // Filtered Students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      !searchTerm ||
      s.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = selectedDept === 'All' || s.department === selectedDept;
    const matchesYear = selectedYear === 'All' || String(s.current_year) === selectedYear;
    const matchesStatus = selectedStatus === 'All' || s.status === selectedStatus;
    return matchesSearch && matchesDept && matchesYear && matchesStatus;
  });

  const academicRiskStudents = students.filter(s => s.academic_risk_level === 'High' || s.academic_risk_level === 'Medium');
  const placementRiskStudents = students.filter(s => s.placement_risk_level === 'High' || s.placement_risk_level === 'Medium');

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px] text-[#777B74] text-sm">
        <Clock className="w-5 h-5 animate-spin mr-2" />
        Loading faculty mentoring analytics...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {(currentTab === 'overview' || !currentTab) && (
      <>
      {/* Top Scope Banner */}
      <div className="bg-[#344D42] text-white p-6 lg:p-8 rounded-[24px] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#A5B8A8]">
            Authorized Faculty Advisor Portal
          </span>
          <h2 className="text-2xl lg:text-3xl font-extrabold tracking-tight mt-1">
            Faculty Mentorship & Analytics
          </h2>
          <p className="text-xs text-[#DCE5DC]/80 mt-1">
            Monitoring {overview?.totalStudents || 110} students across assigned departments · Real-time intervention tracking
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setInterventionStudentId('');
              setShowInterventionModal(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#43866A] hover:bg-[#4F6257] text-white text-xs font-bold rounded-full shadow-md transition-all"
          >
            <Plus className="w-4 h-4" />
            Schedule Intervention
          </button>
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-full border border-white/20 transition-all"
          >
            <Download className="w-4 h-4 text-[#A5B8A8]" />
            Export CSV
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Cohort Success Average"
          value={`${overview?.averageSuccessScore || 81.2}`}
          subtitle="Out of 100 possible points"
          change="+2.8%"
          changeType="positive"
          variant="white"
          icon={GraduationCap}
        />
        <MetricCard
          title="Academic Interventions"
          value={`${overview?.riskCounts?.academicHigh || 14}`}
          subtitle="Students needing remedial help"
          change="Urgent"
          changeType="negative"
          variant="white"
          icon={AlertTriangle}
          badge="High Alert"
        />
        <MetricCard
          title="Placement Support Gap"
          value={`${overview?.riskCounts?.placementHigh || 18}`}
          subtitle="Coding or aptitude benchmark < 50"
          change="Needs Action"
          changeType="negative"
          variant="white"
          icon={Briefcase}
        />
        <MetricCard
          title="Active Interventions"
          value={`${interventions.filter(i => i.status !== 'Completed').length}`}
          subtitle="Sessions currently in progress"
          change="Tracked"
          changeType="positive"
          variant="emerald"
          icon={FolderKanban}
        />
      </div>
      </>
      )}

      {/* TAB 1: OVERVIEW */}
      {(currentTab === 'overview' || !currentTab) && (
        <div className="space-y-6">
          {/* Visual Dynamics Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Status & Risk Distribution (7 Cols) */}
            <div className="lg:col-span-7 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-bold text-[#292D29]">Department Cohort Health</h3>
                  <p className="text-xs text-[#777B74]">Average success score by department</p>
                </div>
                <span className="text-xs font-semibold bg-[#F3F1EB] text-[#344D42] px-3 py-1 rounded-full">
                  All Departments
                </span>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={overview?.departmentBreakdown || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F3F1EB" />
                    <XAxis dataKey="department" tick={{ fontSize: 10, fill: '#777B74' }} />
                    <YAxis domain={[50, 100]} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="avgSuccessScore" fill="#344D42" radius={[6, 6, 0, 0]} name="Avg Success Score" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Success Status Donut (5 Cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-[#292D29]">Success Tier Distribution</h3>
                <p className="text-xs text-[#777B74]">Proportion of students by score thresholds</p>
              </div>

              <div className="h-56 w-full my-auto">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={overview?.scoreDistribution || []}
                      dataKey="count"
                      nameKey="range"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={4}
                    >
                      {overview?.scoreDistribution?.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="pt-3 border-t border-[#F3F1EB] flex items-center justify-between text-xs text-[#777B74]">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#43866A]"></span> On Track: {overview?.statusDistribution?.onTrack}
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#C66F68]"></span> At Risk: {overview?.statusDistribution?.atRisk}
                </span>
              </div>
            </div>
          </div>

          {/* At-Risk Quick Action Table */}
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-[#292D29] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#C66F68]" /> Priority At-Risk Students Requiring Mentoring
                </h3>
                <p className="text-xs text-[#777B74]">Students with immediate academic or placement risk indicators</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB] text-[#777B74] uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5 rounded-l-xl">Student</th>
                    <th className="p-3.5">Department</th>
                    <th className="p-3.5">CGPA</th>
                    <th className="p-3.5">Attendance</th>
                    <th className="p-3.5">Coding</th>
                    <th className="p-3.5">Academic Risk</th>
                    <th className="p-3.5">Placement Risk</th>
                    <th className="p-3.5 rounded-r-xl">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {academicRiskStudents.slice(0, 6).map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-medium text-[#292D29]">
                        <div className="font-bold text-xs">{s.full_name}</div>
                        <span className="text-[11px] font-mono text-[#777B74]">{s.id}</span>
                      </td>
                      <td className="p-3.5">{s.department} · Y{s.current_year}</td>
                      <td className="p-3.5 font-bold">{s.cgpa}</td>
                      <td className="p-3.5 font-medium">{s.attendance_percentage}%</td>
                      <td className="p-3.5 font-medium">{s.coding_score}/100</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.academic_risk_level === 'High' ? 'bg-rose-100 text-[#C66F68]' : 'bg-amber-100 text-[#D7A45A]'
                        }`}>
                          {s.academic_risk_level}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.placement_risk_level === 'High' ? 'bg-rose-100 text-[#C66F68]' : 'bg-amber-100 text-[#D7A45A]'
                        }`}>
                          {s.placement_risk_level}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedStudentId(s.id)}
                            className="p-1.5 bg-[#F3F1EB] hover:bg-[#E7E5DE] rounded-lg text-[#344D42]"
                            title="View Full Profile"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              setInterventionStudentId(s.id);
                              setShowInterventionModal(true);
                            }}
                            className="px-2.5 py-1 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-lg text-[11px] font-semibold"
                          >
                            Intervene
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: STUDENT DIRECTORY */}
      {currentTab === 'students' && (
        <div className="space-y-6">
          {/* Search & Filter Bar */}
          <div className="bg-white p-5 rounded-[22px] border border-[#E7E5DE] shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#777B74]" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by student name, ID, email..."
                className="w-full pl-10 pr-4 py-2 bg-[#F3F1EB]/50 border border-[#E7E5DE] rounded-xl text-xs text-[#292D29] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2.5 w-full md:w-auto overflow-x-auto text-xs">
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl"
              >
                <option value="All">All Departments</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Data Science">Data Science</option>
                <option value="Electronics & Comm">Electronics & Comm</option>
                <option value="Mechanical Engineering">Mechanical</option>
              </select>

              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl"
              >
                <option value="All">All Years</option>
                <option value="1">Year 1</option>
                <option value="2">Year 2</option>
                <option value="3">Year 3</option>
                <option value="4">Year 4</option>
              </select>

              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-2 bg-white border border-[#E7E5DE] rounded-xl"
              >
                <option value="All">All Statuses</option>
                <option value="On Track">On Track</option>
                <option value="Needs Attention">Needs Attention</option>
                <option value="At Risk">At Risk</option>
              </select>
            </div>
          </div>

          {/* Directory Table */}
          <div className="bg-white rounded-[22px] border border-[#E7E5DE] overflow-hidden shadow-sm">
            <div className="p-4 bg-[#F3F1EB]/60 border-b border-[#E7E5DE] flex justify-between items-center text-xs">
              <span className="font-bold text-[#292D29]">Showing {filteredStudents.length} Students</span>
              <span className="text-[#777B74]">Click on any row or Eye icon to view full profile</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#F3F1EB]/40 text-[#777B74] uppercase tracking-wider font-semibold border-b border-[#E7E5DE]">
                  <tr>
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Department</th>
                    <th className="p-3.5">Year/Sem</th>
                    <th className="p-3.5">CGPA</th>
                    <th className="p-3.5">Attendance</th>
                    <th className="p-3.5">Success Score</th>
                    <th className="p-3.5">Academic Risk</th>
                    <th className="p-3.5">Placement Risk</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7E5DE]">
                  {filteredStudents.map((s) => (
                    <tr
                      key={s.id}
                      onClick={() => setSelectedStudentId(s.id)}
                      className="hover:bg-[#F3F1EB]/50 cursor-pointer transition-colors"
                    >
                      <td className="p-3.5 font-mono font-bold text-[#344D42]">{s.id}</td>
                      <td className="p-3.5 font-semibold text-[#292D29]">{s.full_name}</td>
                      <td className="p-3.5 text-[#52574F]">{s.department}</td>
                      <td className="p-3.5 text-[#52574F]">Y{s.current_year} (S{s.current_semester}) · {s.section}</td>
                      <td className="p-3.5 font-bold">{s.cgpa}</td>
                      <td className="p-3.5 font-medium">{s.attendance_percentage}%</td>
                      <td className="p-3.5 font-extrabold text-[#344D42]">{s.success_score}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.academic_risk_level === 'High' ? 'bg-rose-100 text-[#C66F68]' :
                          s.academic_risk_level === 'Medium' ? 'bg-amber-100 text-[#D7A45A]' : 'bg-emerald-50 text-[#43866A]'
                        }`}>
                          {s.academic_risk_level}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          s.placement_risk_level === 'High' ? 'bg-rose-100 text-[#C66F68]' :
                          s.placement_risk_level === 'Medium' ? 'bg-amber-100 text-[#D7A45A]' : 'bg-emerald-50 text-[#43866A]'
                        }`}>
                          {s.placement_risk_level}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          s.status === 'On Track' ? 'bg-emerald-50 text-[#43866A]' :
                          s.status === 'Needs Attention' ? 'bg-amber-50 text-[#D7A45A]' : 'bg-rose-50 text-[#C66F68]'
                        }`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="p-3.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            setInterventionStudentId(s.id);
                            setShowInterventionModal(true);
                          }}
                          className="px-2.5 py-1 bg-[#344D42] hover:bg-[#4F6257] text-white rounded-lg text-[10px] font-semibold"
                        >
                          Mentor
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: AT-RISK STUDENTS (Section 9) */}
      {currentTab === 'at-risk' && (
        <div className="space-y-6">
          {/* Sub-tab toggle */}
          <div className="flex items-center gap-2 border-b border-[#E7E5DE] pb-2">
            <button
              onClick={() => setRiskSubTab('academic')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                riskSubTab === 'academic'
                  ? 'bg-[#344D42] text-white shadow-sm'
                  : 'bg-white text-[#777B74] hover:bg-[#E7E5DE]'
              }`}
            >
              Academic Risk Cohort ({academicRiskStudents.length})
            </button>
            <button
              onClick={() => setRiskSubTab('placement')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                riskSubTab === 'placement'
                  ? 'bg-[#344D42] text-white shadow-sm'
                  : 'bg-white text-[#777B74] hover:bg-[#E7E5DE]'
              }`}
            >
              Placement Readiness Gap Cohort ({placementRiskStudents.length})
            </button>
          </div>

          <div className="bg-white rounded-[22px] border border-[#E7E5DE] p-6 shadow-sm">
            <div className="mb-4">
              <h3 className="text-base font-bold text-[#292D29]">
                {riskSubTab === 'academic' ? 'Academic Risk Diagnostic Factors' : 'Placement Risk Diagnostic Factors'}
              </h3>
              <p className="text-xs text-[#777B74]">
                {riskSubTab === 'academic'
                  ? 'Triggered by CGPA < 6.0, un-cleared backlogs, or attendance below 75% threshold.'
                  : 'Triggered by coding scores < 50, aptitude screening failures, or low mock interview performance.'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(riskSubTab === 'academic' ? academicRiskStudents : placementRiskStudents).map((s) => (
                <div key={s.id} className="p-4 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE] space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-sm text-[#292D29]">{s.full_name}</span>
                      <span className="text-[11px] font-mono text-[#777B74] ml-2">({s.id})</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      (riskSubTab === 'academic' ? s.academic_risk_level : s.placement_risk_level) === 'High'
                        ? 'bg-rose-100 text-[#C66F68]'
                        : 'bg-amber-100 text-[#D7A45A]'
                    }`}>
                      {riskSubTab === 'academic' ? s.academic_risk_level : s.placement_risk_level} Risk
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 bg-white p-2.5 rounded-xl text-center">
                    <div>
                      <span className="text-[10px] text-[#777B74] block">CGPA</span>
                      <span className="font-bold text-[#292D29]">{s.cgpa}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#777B74] block">Attendance</span>
                      <span className="font-bold text-[#292D29]">{s.attendance_percentage}%</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#777B74] block">Coding</span>
                      <span className="font-bold text-[#292D29]">{s.coding_score}/100</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => setSelectedStudentId(s.id)}
                      className="text-[#344D42] font-semibold hover:underline flex items-center gap-1"
                    >
                      Explainable Drill-down <ArrowRight className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => {
                        setInterventionStudentId(s.id);
                        setShowInterventionModal(true);
                      }}
                      className="px-3 py-1 bg-[#344D42] text-white rounded-lg font-bold hover:bg-[#4F6257]"
                    >
                      Assign Support
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: STUDENT SEGMENTS (Section 11) */}
      {currentTab === 'segments' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-1">Explainable Student Segmentation</h3>
            <p className="text-xs text-[#777B74] mb-6">
              Actionable cohort grouping derived dynamically from multiple performance indicators.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {segments.map((seg) => (
                <div key={seg.id} className="p-5 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE] space-y-3 text-xs">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="font-bold text-sm text-[#292D29] block">{seg.name}</span>
                      <span className="text-[11px] text-[#777B74] font-mono mt-0.5 block">{seg.criteria}</span>
                    </div>
                    <span
                      className="px-2.5 py-1 rounded-full text-xs font-bold text-white shrink-0"
                      style={{ backgroundColor: seg.color }}
                    >
                      {seg.studentCount} Students ({seg.percentage}%)
                    </span>
                  </div>

                  <p className="text-[#52574F]">{seg.description}</p>

                  <div className="p-3 bg-white rounded-xl border border-[#E7E5DE]">
                    <span className="font-bold text-[#344D42] block mb-0.5">Recommended Policy:</span>
                    <span className="text-[#52574F] text-[11px]">{seg.recommendedIntervention}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: INTERVENTION TRACKER (Section 7.B) */}
      {currentTab === 'interventions' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-[#292D29]">Intervention Tracker & Outcome Monitoring</h3>
                <p className="text-xs text-[#777B74]">Record sessions, assign actions, and measure before vs after outcomes</p>
              </div>
              <button
                onClick={() => {
                  setInterventionStudentId('');
                  setShowInterventionModal(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-[#344D42] hover:bg-[#4F6257] text-white text-xs font-bold rounded-xl shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> New Mentoring Session
              </button>
            </div>

            <div className="space-y-3">
              {interventions.map((inv) => (
                <div key={inv.id} className="p-4 bg-[#F3F1EB] rounded-2xl border border-[#E7E5DE] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-[#292D29]">{inv.intervention_type}</span>
                      <span className="font-mono bg-white px-2 py-0.5 rounded text-[11px] font-semibold text-[#344D42]">
                        {inv.student_id}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        value={inv.status}
                        onChange={(e) => handleUpdateInterventionStatus(inv.id, e.target.value)}
                        className="px-2.5 py-1 bg-white border border-[#E7E5DE] rounded-lg text-xs font-semibold"
                      >
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                      </select>
                    </div>
                  </div>

                  <p className="text-[#52574F]">{inv.description}</p>
                  <div className="p-2.5 bg-white rounded-xl">
                    <span className="font-bold text-[#344D42]">Suggested Action: </span>
                    <span className="text-[#52574F]">{inv.suggested_action}</span>
                  </div>

                  {inv.outcome_notes && (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-[#344D42]">
                      <span className="font-bold">Outcome: </span> {inv.outcome_notes}
                      {inv.before_metric && inv.after_metric && (
                        <span className="ml-2 font-mono font-bold">
                          (Metric Before: {inv.before_metric} → After: {inv.after_metric})
                        </span>
                      )}
                    </div>
                  )}

                  <div className="flex justify-between items-center text-[11px] text-[#777B74] pt-1">
                    <span>Mentor: {inv.faculty_name}</span>
                    <span>Scheduled: {inv.scheduled_date} · Follow-up: {inv.follow_up_date || 'Pending'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: REPORTS & EXPORT */}
      {/* TAB: ACADEMIC ANALYTICS */}
      {currentTab === 'academics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><MetricCard title="Average CGPA" value={`${students.length ? (students.reduce((n,s)=>n+Number(s.cgpa||0),0)/students.length).toFixed(2) : '0.00'}/10`} subtitle="Across loaded cohort" icon={GraduationCap} variant="white"/><MetricCard title="Academic Support Queue" value={students.filter(s=>Number(s.cgpa||0)<6.5).length} subtitle="CGPA below 6.5" icon={AlertTriangle} variant="white"/><MetricCard title="Strong Performers" value={students.filter(s=>Number(s.cgpa||0)>=8).length} subtitle="CGPA 8.0 and above" icon={CheckCircle2} variant="white"/></div>
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Department & Student Academic Performance</h3><div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Department</th><th className="p-3">Year</th><th className="p-3">CGPA</th><th className="p-3">Success Score</th><th className="p-3">Suggested Action</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{[...students].sort((a,b)=>Number(a.cgpa||0)-Number(b.cgpa||0)).slice(0,25).map(s=><tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{s.department}</td><td className="p-3">{s.current_year}</td><td className="p-3 font-bold">{Number(s.cgpa||0).toFixed(2)}</td><td className="p-3">{s.success_score ?? s.student_success_score ?? '—'}</td><td className="p-3">{Number(s.cgpa||0)<6.5?'Schedule remedial mentoring':'Continue progress review'}</td></tr>)}</tbody></table></div></div>
        </div>
      )}

      {/* TAB: ATTENDANCE ANALYTICS */}
      {currentTab === 'attendance' && (
        <div className="space-y-6"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><MetricCard title="Cohort Attendance Average" value={`${students.length?(students.reduce((n,s)=>n+Number(s.attendance_percentage||0),0)/students.length).toFixed(1):'0'}%`} subtitle="Current loaded cohort" icon={CalendarCheck} variant="white"/><MetricCard title="Below 75%" value={students.filter(s=>Number(s.attendance_percentage||0)<75).length} subtitle="Attendance intervention" icon={AlertTriangle} variant="white"/><MetricCard title="Above 90%" value={students.filter(s=>Number(s.attendance_percentage||0)>=90).length} subtitle="Consistent attendance" icon={CheckCircle2} variant="white"/></div><div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Attendance Follow-up List</h3><div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Department</th><th className="p-3">Attendance</th><th className="p-3">Mentor Action</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{[...students].sort((a,b)=>Number(a.attendance_percentage||0)-Number(b.attendance_percentage||0)).slice(0,20).map(s=><tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{s.department}</td><td className={`p-3 font-bold ${Number(s.attendance_percentage||0)<75?'text-[#C66F68]':'text-[#43866A]'}`}>{Number(s.attendance_percentage||0).toFixed(1)}%</td><td className="p-3">{Number(s.attendance_percentage||0)<75?'Contact student and schedule check-in':'Routine monitoring'}</td></tr>)}</tbody></table></div></div></div>
      )}

      {/* TAB: LMS & ASSIGNMENTS */}
      {currentTab === 'lms' && (
        <div className="space-y-6"><div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-1">Create Assignment or Practical Lab</h3><p className="text-xs text-[#777B74] mb-4">New items are shown in this working session. Persistent publishing requires a connected assignment API.</p><form className="grid grid-cols-1 md:grid-cols-4 gap-3" onSubmit={e=>{e.preventDefault();if(!assignmentTitle.trim())return;setCreatedAssignments(prev=>[{id:Date.now(),title:assignmentTitle.trim(),due:assignmentDue,type:assignmentType},...prev]);setAssignmentTitle('');setAssignmentDue('');}}><select value={assignmentType} onChange={e=>setAssignmentType(e.target.value as 'Assignment'|'Lab')} className="p-3 rounded-xl border border-[#E7E5DE] text-xs"><option>Assignment</option><option>Lab</option></select><input value={assignmentTitle} onChange={e=>setAssignmentTitle(e.target.value)} required placeholder="Title / subject" className="p-3 rounded-xl border border-[#E7E5DE] text-xs"/><input type="date" value={assignmentDue} onChange={e=>setAssignmentDue(e.target.value)} className="p-3 rounded-xl border border-[#E7E5DE] text-xs"/><button type="submit" className="px-4 py-3 rounded-xl bg-[#344D42] text-white text-xs font-bold">Create item</button></form></div><div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Assignments, Labs & AI-assisted Marking Queue</h3><div className="space-y-3">{createdAssignments.map(a=><div key={a.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-4 bg-[#F3F1EB]/60 rounded-xl"><div><p className="text-xs font-bold">{a.title}</p><p className="text-[11px] text-[#777B74]">{a.type} · Due {a.due||'Not set'}</p></div><span className="text-xs px-3 py-1 rounded-full bg-emerald-50 text-[#43866A] font-bold">Created</span></div>)}{(createdAssignments.length===0 ? students.slice(0,8).map(s=>({id:s.id,title:`${s.full_name} · ${s.department}`,due:'Existing student coursework',type:'Assignment'})) : []).map(a=><div key={a.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-4 bg-[#F3F1EB]/60 rounded-xl"><div><p className="text-xs font-bold">{a.title}</p><p className="text-[11px] text-[#777B74]">{a.due}</p></div><span className="text-xs px-3 py-1 rounded-full bg-amber-50 text-amber-700 font-bold">Review submissions</span></div>)}</div><p className="text-[11px] text-[#777B74] mt-4">AI marking workflow: review rubric → compare submitted work → suggest marks and feedback → faculty confirms final grade.</p></div></div>
      )}

      {/* TAB: PLACEMENT READINESS */}
      {currentTab === 'placement' && (
        <div className="space-y-6"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><MetricCard title="Average Coding" value={`${students.length?(students.reduce((n,s)=>n+Number(s.coding_score||0),0)/students.length).toFixed(1):'0'}/100`} subtitle="Technical practice" icon={Briefcase} variant="white"/><MetricCard title="Average Aptitude" value={`${students.length?(students.reduce((n,s)=>n+Number(s.aptitude_score||0),0)/students.length).toFixed(1):'0'}/100`} subtitle="Quantitative and logical" icon={GraduationCap} variant="white"/><MetricCard title="Interview Practice Needed" value={students.filter(s=>Number(s.mock_interview_score||0)<60).length} subtitle="Mock score below 60" icon={AlertTriangle} variant="white"/></div><div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm"><h3 className="text-base font-bold text-[#292D29] mb-4">Placement Coaching Priorities</h3><div className="overflow-x-auto"><table className="w-full text-xs text-left"><thead className="bg-[#F3F1EB] text-[#777B74]"><tr><th className="p-3">Student</th><th className="p-3">Coding</th><th className="p-3">Aptitude</th><th className="p-3">Mock Interview</th><th className="p-3">Priority</th></tr></thead><tbody className="divide-y divide-[#E7E5DE]">{[...students].sort((a,b)=>Number(a.placement_readiness_score||0)-Number(b.placement_readiness_score||0)).slice(0,20).map(s=><tr key={s.id}><td className="p-3 font-semibold">{s.full_name}<div className="text-[10px] text-[#777B74]">{s.id}</div></td><td className="p-3">{s.coding_score??0}</td><td className="p-3">{s.aptitude_score??0}</td><td className="p-3">{s.mock_interview_score??0}</td><td className="p-3 font-bold text-[#C66F68]">{Number(s.placement_readiness_score||0)<50?'Urgent':Number(s.placement_readiness_score||0)<70?'Coaching':'Maintain'}</td></tr>)}</tbody></table></div></div></div>
      )}

      {/* TAB: FACULTY PROFILE & SETTINGS */}
      {currentTab === 'settings' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-4">Faculty Professional Profile</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">{[['Name',user?.full_name||'Faculty Member'],['Email',user?.email||''],['Department',user?.department||'Computer Science'],['Role',user?.role||'Faculty'],['Portal access','Faculty analytics and mentoring'],['Academic year','2026–27']].map(([k,v])=><div key={k} className="p-4 bg-[#F3F1EB] rounded-xl"><p className="text-[#777B74]">{k}</p><p className="font-bold text-[#292D29] mt-1 break-words">{v}</p></div>)}</div>
          </div>
          <PortalSettings role="faculty" />
        </div>
      )}

      {currentTab === 'reports' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[22px] border border-[#E7E5DE] shadow-sm">
            <h3 className="text-base font-bold text-[#292D29] mb-2">Institutional Mentorship Reports</h3>
            <p className="text-xs text-[#777B74] mb-4">Export full student analytics and intervention tracking data to CSV format.</p>
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-2 px-5 py-3 bg-[#344D42] text-white rounded-xl text-xs font-bold hover:bg-[#4F6257] shadow-sm"
            >
              <Download className="w-4 h-4 text-[#A5B8A8]" />
              Export Filtered Student Cohort (CSV)
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      {selectedStudentId && (
        <StudentDetailModal
          studentId={selectedStudentId}
          onClose={() => setSelectedStudentId(null)}
          onOpenIntervention={(id) => {
            setInterventionStudentId(id);
            setShowInterventionModal(true);
          }}
        />
      )}

      {showInterventionModal && (
        <NewInterventionModal
          initialStudentId={interventionStudentId}
          onClose={() => setShowInterventionModal(false)}
          onCreated={() => {
            loadData();
          }}
        />
      )}
    </div>
  );
};
