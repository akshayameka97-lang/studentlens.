# StudentLens — AI-Powered Student Analytics and Success Platform

> **Hackathon Problem Statement:** “Smart Campus Analytics: Predict, Optimize & Improve Student Success.”

StudentLens is a full-stack, enterprise-grade student analytics and success platform designed to integrate academic, attendance, LMS, placement readiness, skills, and mentoring data into a unified, explainable student profile.

Inspired by the **Ivory & Emerald** design system (modeled after the FlowGrid.ai analytics dashboard), StudentLens provides three dedicated portals for **Students**, **Faculty**, and **Administrators**, powered by a transparent, deterministic scoring engine and closed-loop intervention tracking.

---

## 🎨 Design System: Ivory & Emerald

- **Main Sage Canvas Background:** `#4F6257`
- **Deep Emerald Accents:** `#344D42`
- **Muted Green Highlights:** `#668575`
- **Soft Sage Secondary:** `#A5B8A8`
- **Pale Sage Badges:** `#DCE5DC`
- **Warm Ivory Dashboard Surface:** `#F3F1EB`
- **Pure White Cards:** `#FFFFFF` (18–24px rounded corners, subtle elevation)
- **Status Indicators:** Success (`#43866A`), Warning (`#D7A45A`), Risk (`#C66F68`)

---

## 🚀 Quick Start Guide (VS Code Ready)

StudentLens can be extracted and launched with one root-level command:

```bash
# 1. Open the project root in terminal
cd studentlens

# 2. Install all dependencies (both frontend and backend)
npm install

# 3. Start the full-stack application (runs both Express API & Vite UI on port 3000)
npm run dev

# 4. Open in browser:
# http://localhost:3000
```

### Additional Available Scripts
- `npm run seed`: Resets and generates 110 realistic diverse student records with academic, attendance, and placement profiles.
- `npm test`: Runs automated unit tests for scoring, risk detection, and segmentation.
- `npm run build`: Compiles the production React application with Vite.
- `npm start`: Runs the production server.

---

## 🔑 Pre-Configured Demo Accounts

The login page opens by default and includes 1-click credential selector buttons for testing:

| Role | Email | Password | Pre-loaded Name & Scope |
| :--- | :--- | :--- | :--- |
| **Student** | `student@studentlens.edu` | `Password123!` | **Aarav Patel** (Roll: `STU-2024-001`), Year 3, Sem 5, CS |
| **Faculty** | `faculty@studentlens.edu` | `Password123!` | **Dr. Sarah Jenkins**, Associate Professor & Academic Mentor |
| **Administrator** | `admin@studentlens.edu` | `Password123!` | **Dean Arthur Vance**, Dean of Academic Analytics |

*Note: Roles are strictly enforced on the server. Selecting the wrong role category for an account prevents access.*

---

## 📊 Student Success Score Engine

The Student Success Score is calculated deterministically on a 0–100 scale:

$$\text{Success Score} = 0.30 \times \text{Academic} + 0.20 \times \text{Attendance} + 0.15 \times \text{LMS} + 0.20 \times \text{Placement} + 0.10 \times \text{Skills} + 0.05 \times \text{Engagement}$$

### Component Breakdown
1. **Academic Score (30%)**: Normalized CGPA scale with penalty for un-cleared backlogs.
2. **Attendance Score (20%)**: Percentage attendance across statutory class minimums.
3. **LMS Coursework (15%)**: Lab module completion rate and continuous quiz averages.
4. **Placement Readiness (20%)**: Composite of coding benchmarks, aptitude speed, and mock interviews.
5. **Skills Assessment (10%)**: Technical coding stacks, software frameworks, and soft-skill articulation.
6. **Engagement (5%)**: Class participation and platform interaction frequency.

### Status Thresholds
- **80.0 – 100.0**: **On Track** (Green)
- **60.0 – 79.9**: **Needs Attention** (Amber)
- **Below 60.0**: **At Risk** (Rose/Red)

---

## ⚠️ Dual-Track Risk Assessment

StudentLens does not conflate academic GPA with campus placement readiness:

1. **Academic Risk**:
   - High if CGPA < 6.00, active backlogs $\ge 2$, or attendance < 65%.
   - Medium if CGPA < 7.00, active backlogs $= 1$, or attendance < 75%.
2. **Placement Readiness Risk**:
   - High if coding assessment < 48/100, aptitude score < 48/100, or readiness index < 50/100.
   - Medium if coding score < 65/100 or aptitude score < 65/100.

*A student with a 9.0 CGPA who lacks practical coding skills is immediately flagged for placement support while remaining academically exemplary.*

---

## 🧩 Dynamic Student Segments

1. **High Academics, Low Placement Readiness**: CGPA $\ge 7.5$ and Placement Score $< 60$.
2. **Academic At Risk**: Academic score $< 60$, backlogs $> 0$, or attendance $< 65\%$.
3. **High Effort, Low Assessment Yield**: Attendance $\ge 80\%$, LMS $\ge 75\%$, but exam marks $< 65\%$.
4. **Star Performers**: Success score $\ge 80$, CGPA $\ge 8.2$, Placement $\ge 75$.
5. **Placement Ready Specialists**: Coding $\ge 80$, Aptitude $\ge 75$.
6. **Attendance Watch**: Attendance $< 75\%$ with sound academic CGPA $\ge 7.0$.

---

## 📁 Project Structure

```text
studentlens/
├── package.json              # Root dependencies & unified scripts
├── server.ts                 # Full-stack entrypoint: Express + SQLite + Vite dev middleware
├── .env.example              # Environment variables template
├── tsconfig.json             # TypeScript compiler settings
├── vite.config.ts            # Vite build configuration with Tailwind CSS v4
├── data/
│   └── studentlens.sqlite    # Persistent local SQLite database (sql.js binary export)
├── sample-data/              # Sample CSV datasets for testing imports
│   ├── academic.csv
│   ├── attendance.csv
│   ├── placement.csv
│   └── skills.csv
├── server/
│   ├── database/
│   │   ├── db.ts             # SQLite initialization & persistence layer
│   │   └── schema.ts         # Table DDL & relational indexes
│   ├── middleware/
│   │   └── auth.ts           # JWT authentication & role-based access control
│   ├── routes/
│   │   ├── authRoutes.ts     # Login, registration, /me
│   │   ├── studentRoutes.ts  # Student profile, journey, recommendations
│   │   ├── analyticsRoutes.ts# Cohort metrics, segments, risk distributions
│   │   ├── interventionRoutes.ts # Record mentoring & track outcome delta
│   │   └── importRoutes.ts   # CSV parser, validation, CSV export & project ZIP bundle
│   ├── services/
│   │   ├── scoringService.ts # Weighted Success Score calculation engine
│   │   ├── riskService.ts    # Dual-track Academic & Placement risk diagnostics
│   │   └── segmentationService.ts # Dynamic student cohort segmentation
│   ├── scripts/
│   │   └── seed.ts           # 110 diverse student records generator
│   └── tests/
│       └── scoring.test.ts   # Automated unit tests
└── src/
    ├── main.tsx              # React entry point
    ├── App.tsx               # Main routing & application layout
    ├── index.css             # Ivory & Emerald CSS design tokens
    ├── api/
    │   └── client.ts         # Typed fetch client with Bearer token
    ├── context/
    │   └── AuthContext.tsx   # User authentication state
    ├── components/common/
    │   ├── Header.tsx        # Top navigation & in-app VS Code Project ZIP downloader
    │   ├── Sidebar.tsx       # Role-specific navigation with active states
    │   ├── MetricCard.tsx    # FlowGrid.ai style KPI card
    │   ├── ExplainableInsightCard.tsx # Rationale & recommended actions
    │   ├── StudentDetailModal.tsx # Full drill-down student profile
    │   └── NewInterventionModal.tsx # Mentoring session scheduling
    └── pages/
        ├── auth/
        │   ├── LoginPage.tsx # Split-screen login with 3 role selectors
        │   └── RegisterPage.tsx # Account registration
        ├── student/
        │   └── StudentDashboard.tsx # 10 student views (journey, attendance, placement, etc.)
        ├── faculty/
        │   └── FacultyDashboard.tsx # Mentoring roster, at-risk cohort, intervention outcomes
        └── administrator/
            └── AdminDashboard.tsx   # Institutional overview, CSV integration, user management
```

---

## 🏆 Acceptance Criteria Checklist

- [x] First page is the split-screen login page with 3 role selectors (Student, Faculty, Admin).
- [x] Visual design follows the FlowGrid.ai Ivory & Emerald reference image.
- [x] 3 genuinely distinct dashboards with dedicated role-based navigation.
- [x] Pure local SQLite database (`data/studentlens.sqlite`) without requiring cloud database setup.
- [x] Pre-seeded with 110 realistic synthetic students across 5 departments.
- [x] Weighted Student Success Score with transparent formula.
- [x] Separate Academic and Placement risk assessments with explainable indicators.
- [x] Explainable AI insights cards with actionable next steps.
- [x] Student segmentation with dynamic counts and policy guidance.
- [x] Interactive Recharts (Area, Bar, Radar, Pie, Scatter).
- [x] Intervention Tracker with before vs after outcome monitoring.
- [x] CSV Import portal with live preview, category mapping, and error reporting.
- [x] In-app button to download the complete VS Code Project ZIP.
- [x] Automated unit test suite with 100% pass rate.
