# StudentLens Settings Enhancement

## Student portal
- Notification preferences, privacy and security preferences, study routine, appearance and accessibility controls.
- Save settings and restore defaults; preferences are stored in browser localStorage.

## Faculty portal
- Faculty profile summary.
- Notifications for attendance, pending grading, risk summaries, placements and interventions.
- Privacy/security preferences, default student view, language, compact layout and reduced-motion preferences.
- Save settings and restore defaults; preferences are stored in browser localStorage.

## Administrator portal
- System notifications for account creation, high-risk cohorts, data imports and institutional summaries.
- Security/governance preferences, default landing page, risk threshold, data-retention preference, language, compact layout and reduced-motion preferences.
- Existing institutional success formula and demo-data reset controls are retained.
- Save settings and restore defaults; preferences are stored in browser localStorage.

Note: settings such as password enforcement, data retention and email delivery are saved as preferences only; real system-wide enforcement requires backend support.
