# StudentLens change log

- Added a reusable role-specific PortalSettings component for faculty and administrator portals.
- Faculty settings now include a profile summary, notification controls, privacy/security preferences, workspace defaults, appearance preferences, Save Settings and Restore Defaults.
- Administrator settings now include platform notifications, security/governance preferences, default landing page, risk threshold and data-retention preferences, appearance controls, Save Settings and Restore Defaults.
- Kept the administrator's existing institutional score formula configuration and demo-data reset action.
- Faculty and administrator settings persist in browser localStorage, independently by role.
- Student settings remain available as previously implemented.
