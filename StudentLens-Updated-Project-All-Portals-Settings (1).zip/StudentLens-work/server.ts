import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { getDb, query, run } from './server/database/db.js';
import { initializeSchema } from './server/database/schema.js';
import { seedDatabase } from './server/scripts/seed.js';
import { authRouter } from './server/routes/authRoutes.js';
import { studentRouter } from './server/routes/studentRoutes.js';
import { analyticsRouter } from './server/routes/analyticsRoutes.js';
import { interventionRouter } from './server/routes/interventionRoutes.js';
import { importRouter } from './server/routes/importRoutes.js';
import { requireAuth, requireRole, AuthenticatedRequest } from './server/middleware/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Initialize SQLite database
  await getDb();
  initializeSchema();

  // If no users exist, auto-seed with rich demo dataset
  try {
    const userCount = query<{ count: number }>('SELECT count(*) as count FROM users');
    if (!userCount[0] || userCount[0].count === 0) {
      console.log('⚡ No users found in database. Automatically seeding demo dataset...');
      await seedDatabase();
    }
  } catch (err) {
    console.warn('Auto-seed check note:', err);
  }

  // Mount API Endpoints
  app.use('/api/auth', authRouter);
  app.use('/api/students', studentRouter);
  app.use('/api/analytics', analyticsRouter);
  app.use('/api/interventions', interventionRouter);
  app.use('/api/import', importRouter);

  // User Management (Admin only)
  app.get('/api/users', requireAuth, requireRole(['administrator']), (req: AuthenticatedRequest, res) => {
    try {
      const users = query(`
        SELECT id, email, full_name, role, department, college_id, designation, status, created_at, last_login
        FROM users
        ORDER BY created_at DESC
      `);
      return res.json({ users });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to retrieve users.' });
    }
  });

  app.patch('/api/users/:id/status', requireAuth, requireRole(['administrator']), (req: AuthenticatedRequest, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      if (!['active', 'deactivated'].includes(status)) {
        return res.status(400).json({ error: 'Status must be active or deactivated.' });
      }
      run('UPDATE users SET status = ? WHERE id = ?', [status, id]);
      return res.json({ message: `User status updated to ${status}.` });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to update user status.' });
    }
  });

  // Re-seed demo dataset endpoint for quick reset
  app.post('/api/admin/reset-demo-data', requireAuth, requireRole(['administrator']), async (req, res) => {
    try {
      await seedDatabase();
      return res.json({ message: 'Demo database reset and seeded successfully with 110 records.' });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to reset demo dataset.' });
    }
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'StudentLens', timestamp: new Date().toISOString() });
  });

  // Development vs Production static serving
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Vite middleware for development
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve built static files from dist
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 StudentLens full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
