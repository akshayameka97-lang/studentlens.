import { exec } from './db.js';

export function initializeSchema(): void {
  const schemaSql = `
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('student', 'faculty', 'administrator')),
      department TEXT,
      college_id TEXT,
      designation TEXT,
      current_year INTEGER,
      current_semester INTEGER,
      section TEXT,
      status TEXT DEFAULT 'active',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      last_login TEXT
    );

    CREATE TABLE IF NOT EXISTS students (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      department TEXT NOT NULL,
      current_year INTEGER NOT NULL,
      current_semester INTEGER NOT NULL,
      section TEXT NOT NULL,
      cgpa REAL NOT NULL,
      backlogs INTEGER DEFAULT 0,
      attendance_percentage REAL NOT NULL,
      lms_completion_rate REAL NOT NULL,
      coding_score REAL NOT NULL,
      aptitude_score REAL NOT NULL,
      mock_interview_score REAL NOT NULL,
      communication_score REAL NOT NULL,
      placement_readiness_score REAL NOT NULL,
      success_score REAL NOT NULL,
      academic_score REAL NOT NULL,
      skills_score REAL NOT NULL,
      engagement_score REAL NOT NULL,
      academic_risk_level TEXT NOT NULL CHECK(academic_risk_level IN ('Low', 'Medium', 'High')),
      placement_risk_level TEXT NOT NULL CHECK(placement_risk_level IN ('Low', 'Medium', 'High')),
      status TEXT NOT NULL CHECK(status IN ('On Track', 'Needs Attention', 'At Risk')),
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS academic_records (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      semester INTEGER NOT NULL,
      subject_code TEXT NOT NULL,
      subject_name TEXT NOT NULL,
      marks_obtained REAL NOT NULL,
      max_marks REAL DEFAULT 100,
      grade TEXT NOT NULL,
      exam_type TEXT DEFAULT 'Internal',
      recorded_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS attendance_records (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      month TEXT NOT NULL,
      subject_name TEXT NOT NULL,
      attended_classes INTEGER NOT NULL,
      total_classes INTEGER NOT NULL,
      percentage REAL NOT NULL,
      recorded_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS lms_activity (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      course_name TEXT NOT NULL,
      modules_completed INTEGER NOT NULL,
      total_modules INTEGER NOT NULL,
      completion_percentage REAL NOT NULL,
      quiz_score REAL NOT NULL,
      assignment_status TEXT NOT NULL CHECK(assignment_status IN ('Completed', 'Pending', 'Overdue')),
      time_spent_hours REAL NOT NULL,
      last_active TEXT,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS placement_records (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      aptitude_score REAL NOT NULL,
      coding_score REAL NOT NULL,
      mock_interview_score REAL NOT NULL,
      communication_score REAL NOT NULL,
      readiness_index REAL NOT NULL,
      eligible_companies_count INTEGER DEFAULT 0,
      resume_score REAL DEFAULT 75,
      assessed_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS skill_assessments (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      skill_name TEXT NOT NULL,
      category TEXT NOT NULL CHECK(category IN ('Technical', 'Soft Skill', 'Domain')),
      score REAL NOT NULL,
      max_score REAL DEFAULT 100,
      assessed_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS interventions (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      faculty_id TEXT NOT NULL,
      faculty_name TEXT NOT NULL,
      intervention_type TEXT NOT NULL,
      description TEXT NOT NULL,
      suggested_action TEXT NOT NULL,
      priority TEXT NOT NULL CHECK(priority IN ('High', 'Medium', 'Low')),
      status TEXT NOT NULL CHECK(status IN ('Pending', 'In Progress', 'Completed')),
      scheduled_date TEXT NOT NULL,
      follow_up_date TEXT,
      outcome_notes TEXT,
      before_metric REAL,
      after_metric REAL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS student_feedback (
      id TEXT PRIMARY KEY,
      student_id TEXT NOT NULL,
      category TEXT NOT NULL,
      faculty_or_subject TEXT NOT NULL,
      rating REAL NOT NULL,
      feedback_text TEXT,
      semester INTEGER NOT NULL,
      submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS import_history (
      id TEXT PRIMARY KEY,
      file_name TEXT NOT NULL,
      category TEXT NOT NULL,
      total_records INTEGER NOT NULL,
      successful_records INTEGER NOT NULL,
      failed_records INTEGER NOT NULL,
      imported_by TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_students_dept ON students(department);
    CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
    CREATE INDEX IF NOT EXISTS idx_students_success_score ON students(success_score);
    CREATE INDEX IF NOT EXISTS idx_academic_student ON academic_records(student_id);
    CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance_records(student_id);
    CREATE INDEX IF NOT EXISTS idx_lms_student ON lms_activity(student_id);
    CREATE INDEX IF NOT EXISTS idx_interventions_student ON interventions(student_id);
  `;

  exec(schemaSql);
}
