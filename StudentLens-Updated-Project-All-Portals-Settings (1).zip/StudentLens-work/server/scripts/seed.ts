import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { getDb, run, exec, persistDb, query } from '../database/db.js';
import { initializeSchema } from '../database/schema.js';
import { calculateSuccessScore } from '../services/scoringService.js';
import { evaluateAcademicRisk, evaluatePlacementRisk } from '../services/riskService.js';

export async function seedDatabase() {
  console.log('🌱 Starting StudentLens database initialization and seeding...');
  await getDb();
  initializeSchema();

  const existingUsers = query('SELECT count(*) as count FROM users');
  if (existingUsers[0]?.count > 0) {
    console.log('Database already contains records. Verifying demo accounts...');
  }

  // Clear previous sample data cleanly to allow repeatable seeds
  exec(`
    DELETE FROM audit_logs;
    DELETE FROM import_history;
    DELETE FROM student_feedback;
    DELETE FROM interventions;
    DELETE FROM skill_assessments;
    DELETE FROM placement_records;
    DELETE FROM lms_activity;
    DELETE FROM attendance_records;
    DELETE FROM academic_records;
    DELETE FROM students;
    DELETE FROM users;
  `);

  const passwordHash = await bcrypt.hash('Password123!', 10);

  // 1. Create Demo Users
  const studentUserId = 'usr-demo-student';
  const facultyUserId = 'usr-demo-faculty';
  const adminUserId = 'usr-demo-admin';

  run(`
    INSERT INTO users (id, email, password_hash, full_name, role, department, college_id, designation, current_year, current_semester, section, status)
    VALUES 
    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active'),
    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active'),
    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
  `, [
    // Demo Student
    studentUserId, 'student@studentlens.edu', passwordHash, 'Aarav Patel', 'student', 'Computer Science', 'STU-2024-001', 'Undergraduate Student', 3, 5, 'A',
    // Demo Faculty
    facultyUserId, 'faculty@studentlens.edu', passwordHash, 'Dr. Sarah Jenkins', 'faculty', 'Computer Science', 'FAC-CS-104', 'Associate Professor & Academic Mentor', null, null, null,
    // Demo Administrator
    adminUserId, 'admin@studentlens.edu', passwordHash, 'Dean Arthur Vance', 'administrator', 'Dean Office', 'ADM-001', 'Dean of Academic Analytics & Student Success', null, null, null,
  ]);

  // 2. First Names & Last Names pool for generating 110 realistic students
  const firstNames = [
    'Aarav', 'Diya', 'Rohan', 'Ananya', 'Vivaan', 'Isha', 'Kabir', 'Sneha', 'Arjun', 'Meera',
    'Aditya', 'Pooja', 'Rahul', 'Tanvi', 'Sai', 'Kavya', 'Siddharth', 'Riya', 'Vikram', 'Neha',
    'Rishi', 'Shreya', 'Kunal', 'Priyanka', 'Dev', 'Tara', 'Aayush', 'Swati', 'Harsh', 'Nisha',
    'Manish', 'Sanjana', 'Gaurav', 'Alisha', 'Tarun', 'Deepika', 'Akash', 'Shruti', 'Nikhil', 'Simran'
  ];
  const lastNames = [
    'Patel', 'Sharma', 'Verma', 'Iyer', 'Reddy', 'Gupta', 'Mehta', 'Nair', 'Singh', 'Deshmukh',
    'Chopra', 'Rao', 'Bose', 'Kapoor', 'Chatterjee', 'Bhat', 'Joshi', 'Menon', 'Kulkarni', 'Sengupta'
  ];

  const departments = ['Computer Science', 'Information Technology', 'Data Science', 'Electronics & Comm', 'Mechanical Engineering'];
  const sections = ['A', 'B', 'C'];

  const studentRows: any[] = [];
  const TOTAL_STUDENTS = 110;

  for (let i = 0; i < TOTAL_STUDENTS; i++) {
    const isDemoStudent = i === 0;
    const stuId = `STU-2024-${String(i + 1).padStart(3, '0')}`;
    const fn = isDemoStudent ? 'Aarav' : firstNames[i % firstNames.length];
    const ln = isDemoStudent ? 'Patel' : lastNames[(i * 3 + 7) % lastNames.length];
    const fullName = `${fn} ${ln}`;
    const email = isDemoStudent ? 'student@studentlens.edu' : `${fn.toLowerCase()}.${ln.toLowerCase()}${i + 10}@studentlens.edu`;
    const department = isDemoStudent ? 'Computer Science' : departments[i % departments.length];
    const currentYear = isDemoStudent ? 3 : ((i % 4) + 1);
    const currentSemester = isDemoStudent ? 5 : ((currentYear * 2) - (i % 2));
    const section = sections[i % sections.length];
    const assignedUserId = isDemoStudent ? studentUserId : null;

    // Create diverse realistic profiles based on index archetype:
    // Archetype 0: High performer
    // Archetype 1: High academic, low placement (gap)
    // Archetype 2: Academic at risk (backlogs, low CGPA)
    // Archetype 3: High engagement, low test conversion
    // Archetype 4: Solid average performer
    const archetype = i % 5;
    let cgpa = 7.5;
    let backlogs = 0;
    let attendance = 82;
    let lms = 80;
    let coding = 70;
    let aptitude = 72;
    let mockInterview = 70;
    let communication = 74;

    if (archetype === 0) {
      // High Performer
      cgpa = 8.6 + ((i * 13) % 120) / 100; // 8.6 - 9.8
      backlogs = 0;
      attendance = 88 + (i % 11); // 88 - 98
      lms = 86 + (i % 12); // 86 - 98
      coding = 82 + (i % 16); // 82 - 97
      aptitude = 80 + (i % 18);
      mockInterview = 82 + (i % 15);
      communication = 84 + (i % 14);
    } else if (archetype === 1) {
      // High Academics, Low Placement
      cgpa = 8.1 + ((i * 7) % 90) / 100; // 8.1 - 8.9
      backlogs = 0;
      attendance = 82 + (i % 12);
      lms = 78 + (i % 15);
      coding = 38 + (i % 16); // 38 - 53 (low!)
      aptitude = 46 + (i % 14); // 46 - 59
      mockInterview = 48 + (i % 14);
      communication = 58 + (i % 12);
    } else if (archetype === 2) {
      // Academic At Risk
      cgpa = 5.1 + ((i * 9) % 95) / 100; // 5.1 - 6.0
      backlogs = (i % 3) + 1; // 1 to 3 backlogs
      attendance = 58 + (i % 14); // 58 - 71 (low attendance!)
      lms = 44 + (i % 22); // 44 - 65
      coding = 45 + (i % 20);
      aptitude = 48 + (i % 18);
      mockInterview = 46 + (i % 16);
      communication = 52 + (i % 15);
    } else if (archetype === 3) {
      // High Engagement, Low Assessment
      cgpa = 6.2 + ((i * 5) % 55) / 100; // 6.2 - 6.7
      backlogs = (i % 4 === 0) ? 1 : 0;
      attendance = 86 + (i % 10); // 86 - 95 (very high attendance!)
      lms = 85 + (i % 12); // 85 - 96 (high LMS!)
      coding = 52 + (i % 15);
      aptitude = 54 + (i % 14);
      mockInterview = 58 + (i % 15);
      communication = 64 + (i % 12);
    } else {
      // Solid steady student
      cgpa = 7.2 + ((i * 8) % 65) / 100; // 7.2 - 7.8
      backlogs = 0;
      attendance = 77 + (i % 12);
      lms = 74 + (i % 15);
      coding = 68 + (i % 15);
      aptitude = 70 + (i % 14);
      mockInterview = 69 + (i % 14);
      communication = 72 + (i % 14);
    }

    // Demo student tailored: Strong student with clear room for growth in placement coding
    if (isDemoStudent) {
      cgpa = 8.45;
      backlogs = 0;
      attendance = 89.2;
      lms = 91.0;
      coding = 64.0;
      aptitude = 78.5;
      mockInterview = 75.0;
      communication = 82.0;
    }

    const readinessIndex = Number((coding * 0.35 + aptitude * 0.25 + mockInterview * 0.20 + communication * 0.20).toFixed(1));

    const scoreResult = calculateSuccessScore({
      cgpa,
      backlogs,
      attendance_percentage: attendance,
      lms_completion_rate: lms,
      coding_score: coding,
      aptitude_score: aptitude,
      mock_interview_score: mockInterview,
      communication_score: communication,
    });

    const acadRisk = evaluateAcademicRisk({
      cgpa,
      backlogs,
      attendance_percentage: attendance,
      lms_completion_rate: lms,
    });

    const placeRisk = evaluatePlacementRisk({
      coding_score: coding,
      aptitude_score: aptitude,
      mock_interview_score: mockInterview,
      communication_score: communication,
      placement_readiness_score: readinessIndex,
    });

    studentRows.push({
      id: stuId,
      user_id: assignedUserId,
      full_name: fullName,
      email,
      department,
      current_year: currentYear,
      current_semester: currentSemester,
      section,
      cgpa: Number(cgpa.toFixed(2)),
      backlogs,
      attendance_percentage: Number(attendance.toFixed(1)),
      lms_completion_rate: Number(lms.toFixed(1)),
      coding_score: Number(coding.toFixed(1)),
      aptitude_score: Number(aptitude.toFixed(1)),
      mock_interview_score: Number(mockInterview.toFixed(1)),
      communication_score: Number(communication.toFixed(1)),
      placement_readiness_score: readinessIndex,
      success_score: scoreResult.totalScore,
      academic_score: scoreResult.academicScore,
      skills_score: scoreResult.skillsScore,
      engagement_score: scoreResult.engagementScore,
      academic_risk_level: acadRisk.level,
      placement_risk_level: placeRisk.level,
      status: scoreResult.status,
    });
  }

  // Insert students in batch
  for (const s of studentRows) {
    run(`
      INSERT INTO students (
        id, user_id, full_name, email, department, current_year, current_semester, section,
        cgpa, backlogs, attendance_percentage, lms_completion_rate, coding_score, aptitude_score,
        mock_interview_score, communication_score, placement_readiness_score, success_score,
        academic_score, skills_score, engagement_score, academic_risk_level, placement_risk_level, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      s.id, s.user_id, s.full_name, s.email, s.department, s.current_year, s.current_semester, s.section,
      s.cgpa, s.backlogs, s.attendance_percentage, s.lms_completion_rate, s.coding_score, s.aptitude_score,
      s.mock_interview_score, s.communication_score, s.placement_readiness_score, s.success_score,
      s.academic_score, s.skills_score, s.engagement_score, s.academic_risk_level, s.placement_risk_level, s.status
    ]);
  }

  // 3. Populate Subjects & Academic Records for each student
  const subjectPool = [
    { code: 'CS301', name: 'Data Structures & Algorithms' },
    { code: 'CS302', name: 'Database Management Systems' },
    { code: 'CS303', name: 'Operating Systems' },
    { code: 'CS304', name: 'Computer Networks' },
    { code: 'CS305', name: 'Software Engineering' },
    { code: 'AI306', name: 'Machine Learning Fundamentals' },
  ];

  let acadCount = 0;
  for (const s of studentRows) {
    for (let idx = 0; idx < subjectPool.length; idx++) {
      const sub = subjectPool[idx];
      // Generate marks correlated to CGPA
      const baseMark = (s.cgpa / 10) * 100;
      const variation = ((idx * 7 + parseInt(s.id.slice(-2))) % 15) - 7;
      let marks = Math.min(Math.max(Math.round(baseMark + variation), 38), 98);
      if (s.backlogs > 0 && idx === 1) {
        marks = 34; // backlog subject
      }
      const grade = marks >= 90 ? 'O' : marks >= 80 ? 'A+' : marks >= 70 ? 'A' : marks >= 60 ? 'B+' : marks >= 50 ? 'B' : 'F';

      run(`
        INSERT INTO academic_records (id, student_id, semester, subject_code, subject_name, marks_obtained, max_marks, grade, exam_type)
        VALUES (?, ?, ?, ?, ?, ?, 100, ?, 'Internal')
      `, [`ACAD-${s.id}-${idx}`, s.id, s.current_semester, sub.code, sub.name, marks, grade]);
      acadCount++;
    }

    // 4. Monthly Attendance Records
    const months = ['Jul', 'Aug', 'Sep', 'Oct'];
    for (let mIdx = 0; mIdx < months.length; mIdx++) {
      const month = months[mIdx];
      const totalClasses = 30;
      const attended = Math.min(Math.round((s.attendance_percentage / 100) * totalClasses + ((mIdx % 3) - 1)), totalClasses);
      const percentage = Number(((attended / totalClasses) * 100).toFixed(1));
      run(`
        INSERT INTO attendance_records (id, student_id, month, subject_name, attended_classes, total_classes, percentage)
        VALUES (?, ?, ?, 'All Subjects Composite', ?, ?, ?)
      `, [`ATT-${s.id}-${mIdx}`, s.id, month, attended, totalClasses, percentage]);
    }

    // 5. LMS Activity Records
    const lmsCourses = [
      'Advanced Data Structures Lab',
      'Database Design Sprint',
      'Operating Systems Virtual Labs'
    ];
    for (let cIdx = 0; cIdx < lmsCourses.length; cIdx++) {
      const cName = lmsCourses[cIdx];
      const totalMods = 10;
      const completedMods = Math.min(Math.round((s.lms_completion_rate / 100) * totalMods), totalMods);
      const quizScore = Math.min(Math.round(s.cgpa * 9.5 + ((cIdx * 5) % 10)), 98);
      const status = completedMods >= 8 ? 'Completed' : completedMods >= 5 ? 'Pending' : 'Overdue';
      run(`
        INSERT INTO lms_activity (id, student_id, course_name, modules_completed, total_modules, completion_percentage, quiz_score, assignment_status, time_spent_hours)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [`LMS-${s.id}-${cIdx}`, s.id, cName, completedMods, totalMods, (completedMods / totalMods) * 100, quizScore, status, 14 + (cIdx * 6)]);
    }

    // 6. Placement Records
    const eligibleCount = s.cgpa >= 7.5 && s.backlogs === 0 && s.placement_readiness_score >= 65 ? 18 : 6;
    run(`
      INSERT INTO placement_records (id, student_id, aptitude_score, coding_score, mock_interview_score, communication_score, readiness_index, eligible_companies_count, resume_score)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [`PLC-${s.id}`, s.id, s.aptitude_score, s.coding_score, s.mock_interview_score, s.communication_score, s.placement_readiness_score, eligibleCount, 78 + (parseInt(s.id.slice(-2)) % 18)]);

    // 7. Skill Assessments (Technical & Soft Skills)
    const skills = [
      { name: 'Data Structures & Algorithms', category: 'Technical', score: s.coding_score },
      { name: 'Full-Stack Web (React/Node)', category: 'Technical', score: Math.min(s.coding_score + 5, 96) },
      { name: 'Database & SQL Querying', category: 'Technical', score: Math.min(s.coding_score + 8, 98) },
      { name: 'Quantitative Problem Solving', category: 'Domain', score: s.aptitude_score },
      { name: 'Technical Articulation & Communication', category: 'Soft Skill', score: s.communication_score },
      { name: 'Team Collaboration & Leadership', category: 'Soft Skill', score: 82 },
    ];
    for (let skIdx = 0; skIdx < skills.length; skIdx++) {
      const sk = skills[skIdx];
      run(`
        INSERT INTO skill_assessments (id, student_id, skill_name, category, score, max_score)
        VALUES (?, ?, ?, ?, ?, 100)
      `, [`SK-${s.id}-${skIdx}`, s.id, sk.name, sk.category, sk.score]);
    }
  }

  // 8. Seed Interventions
  // Create 15 realistic faculty interventions with follow-up tracking
  const interventionSeed = [
    {
      stuId: 'STU-2024-001', // Demo student
      type: 'Placement Coaching',
      desc: 'Technical mock interview and LeetCode algorithmic prep session.',
      action: 'Assign 30 curated Dynamic Programming and Tree problems; pair with senior mentor.',
      priority: 'Medium',
      status: 'In Progress',
      schedDate: '2026-10-05',
      followDate: '2026-10-25',
      before: 64,
      after: 72,
      outcome: 'Student demonstrated marked improvement in two-pointer and binary search techniques.',
    },
    {
      stuId: 'STU-2024-003',
      type: 'Academic Mentoring',
      desc: 'Remedial tutoring for Database Management Systems backlog.',
      action: 'Provide guided normalization worksheets and weekly Tuesday check-ins.',
      priority: 'High',
      status: 'In Progress',
      schedDate: '2026-09-28',
      followDate: '2026-10-20',
      before: 48,
      after: 62,
      outcome: 'Completed SQL query labs with 85% accuracy in review test.',
    },
    {
      stuId: 'STU-2024-007',
      type: 'Attendance Counseling',
      desc: 'Condonation warning intervention due to 64% attendance in Operating Systems.',
      action: 'Set mandatory daily attendance log sign-off with faculty mentor.',
      priority: 'High',
      status: 'Completed',
      schedDate: '2026-09-15',
      followDate: '2026-10-01',
      before: 64,
      after: 76,
      outcome: 'Attendance improved by 12% over 3 weeks. Student cleared for mid-term exams.',
    },
    {
      stuId: 'STU-2024-012',
      type: 'Skill Workshop',
      desc: 'Fast-track Cloud & DevOps micro-credentialing for placement drive.',
      action: 'Enrolled in Docker & Kubernetes campus lab track with certification voucher.',
      priority: 'Medium',
      status: 'Completed',
      schedDate: '2026-09-10',
      followDate: '2026-09-29',
      before: 60,
      after: 85,
      outcome: 'Earned foundational cloud badge; qualified for campus drive shortlist.',
    },
    {
      stuId: 'STU-2024-018',
      type: 'Placement Coaching',
      desc: 'Aptitude speed enhancement and logical reasoning drills.',
      action: 'Assigned 20-minute daily speed mocks on campus portal.',
      priority: 'High',
      status: 'Pending',
      schedDate: '2026-10-18',
      followDate: '2026-11-02',
      before: 45,
      after: null,
      outcome: null,
    },
  ];

  for (let i = 0; i < interventionSeed.length; i++) {
    const inv = interventionSeed[i];
    run(`
      INSERT INTO interventions (
        id, student_id, faculty_id, faculty_name, intervention_type, description, suggested_action,
        priority, status, scheduled_date, follow_up_date, outcome_notes, before_metric, after_metric
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      `INV-2026-${String(i + 1).padStart(3, '0')}`,
      inv.stuId,
      facultyUserId,
      'Dr. Sarah Jenkins',
      inv.type,
      inv.desc,
      inv.action,
      inv.priority,
      inv.status,
      inv.schedDate,
      inv.followDate,
      inv.outcome,
      inv.before,
      inv.after
    ]);
  }

  // 9. Generate Sample CSV Files in sample-data/ for Data Integration and CSV Import
  const sampleDir = path.resolve(process.cwd(), 'sample-data');
  if (!fs.existsSync(sampleDir)) {
    fs.mkdirSync(sampleDir, { recursive: true });
  }

  // academic.csv
  const academicCsvHeader = 'student_id,semester,subject_code,subject_name,marks_obtained,max_marks,grade,exam_type\n';
  const academicCsvRows = studentRows.slice(0, 15).map(s => 
    `${s.id},${s.current_semester},CS301,Data Structures & Algorithms,${Math.round((s.cgpa / 10) * 100)},100,A,MidTerm`
  ).join('\n');
  fs.writeFileSync(path.join(sampleDir, 'academic.csv'), academicCsvHeader + academicCsvRows);

  // attendance.csv
  const attendanceCsvHeader = 'student_id,month,subject_name,attended_classes,total_classes,percentage\n';
  const attendanceCsvRows = studentRows.slice(0, 15).map(s =>
    `${s.id},October,Composite Attendance,${Math.round(s.attendance_percentage * 0.3)},30,${s.attendance_percentage}`
  ).join('\n');
  fs.writeFileSync(path.join(sampleDir, 'attendance.csv'), attendanceCsvHeader + attendanceCsvRows);

  // placement.csv
  const placementCsvHeader = 'student_id,aptitude_score,coding_score,mock_interview_score,communication_score\n';
  const placementCsvRows = studentRows.slice(0, 15).map(s =>
    `${s.id},${s.aptitude_score},${s.coding_score},${s.mock_interview_score},${s.communication_score}`
  ).join('\n');
  fs.writeFileSync(path.join(sampleDir, 'placement.csv'), placementCsvHeader + placementCsvRows);

  // skills.csv
  const skillsCsvHeader = 'student_id,skill_name,category,score\n';
  const skillsCsvRows = studentRows.slice(0, 15).map(s =>
    `${s.id},Data Structures,Technical,${s.coding_score}`
  ).join('\n');
  fs.writeFileSync(path.join(sampleDir, 'skills.csv'), skillsCsvHeader + skillsCsvRows);

  persistDb();
  console.log(`✅ Seed finished successfully! Inserted 3 users, ${studentRows.length} students, ${acadCount} academic records, sample CSVs generated.`);
}

// Allow direct execution
if (import.meta.url.endsWith(process.argv[1]) || process.argv[1]?.includes('seed')) {
  seedDatabase().catch((err) => {
    console.error('Seed script error:', err);
    process.exit(1);
  });
}
