import { Router } from 'express';
import { query, queryOne } from '../database/db.js';
import { requireAuth, checkStudentOwnership, AuthenticatedRequest } from '../middleware/auth.js';
import { calculateSuccessScore } from '../services/scoringService.js';
import { evaluateAcademicRisk, evaluatePlacementRisk } from '../services/riskService.js';
import { generateStudentInsights } from '../services/segmentationService.js';

export const studentRouter = Router();

// GET /api/students - List students with search, filters, pagination
studentRouter.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const {
      search,
      department,
      year,
      semester,
      section,
      status,
      academicRisk,
      placementRisk,
      page = '1',
      limit = '20',
      sortBy = 'success_score',
      sortOrder = 'DESC',
    } = req.query;

    let sql = 'SELECT * FROM students WHERE 1=1';
    const params: any[] = [];

    // Role-based scope filtering:
    // If student, can only see themselves
    if (req.user?.role === 'student') {
      sql += ' AND (id = ? OR email = ?)';
      params.push(req.user.college_id || '', req.user.email);
    } else if (req.user?.role === 'faculty') {
      // Faculty default authorized to their department if specified
      if (req.query.facultyScope === 'department' && req.user.department) {
        sql += ' AND department = ?';
        params.push(req.user.department);
      }
    }

    if (search) {
      sql += ' AND (full_name LIKE ? OR id LIKE ? OR email LIKE ?)';
      const term = `%${search}%`;
      params.push(term, term, term);
    }

    if (department && department !== 'All') {
      sql += ' AND department = ?';
      params.push(department);
    }

    if (year && year !== 'All') {
      sql += ' AND current_year = ?';
      params.push(parseInt(year as string));
    }

    if (semester && semester !== 'All') {
      sql += ' AND current_semester = ?';
      params.push(parseInt(semester as string));
    }

    if (section && section !== 'All') {
      sql += ' AND section = ?';
      params.push(section);
    }

    if (status && status !== 'All') {
      sql += ' AND status = ?';
      params.push(status);
    }

    if (academicRisk && academicRisk !== 'All') {
      sql += ' AND academic_risk_level = ?';
      params.push(academicRisk);
    }

    if (placementRisk && placementRisk !== 'All') {
      sql += ' AND placement_risk_level = ?';
      params.push(placementRisk);
    }

    // Allowed sort columns
    const allowedSortCols = ['success_score', 'cgpa', 'attendance_percentage', 'placement_readiness_score', 'full_name', 'current_year'];
    const safeSortCol = allowedSortCols.includes(sortBy as string) ? (sortBy as string) : 'success_score';
    const safeSortOrder = (sortOrder as string).toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    // Get total count
    const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
    const countResult = queryOne<{ total: number }>(countSql, params);
    const totalCount = countResult?.total || 0;

    const pageNum = Math.max(1, parseInt(page as string));
    const limitNum = Math.max(1, Math.min(100, parseInt(limit as string)));
    const offset = (pageNum - 1) * limitNum;

    sql += ` ORDER BY ${safeSortCol} ${safeSortOrder} LIMIT ${limitNum} OFFSET ${offset}`;
    const students = query(sql, params);

    return res.json({
      data: students,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limitNum),
      },
    });
  } catch (err: any) {
    console.error('Error fetching students:', err);
    return res.status(500).json({ error: 'Failed to retrieve students' });
  }
});

// GET /api/students/:id - Comprehensive profile
studentRouter.get('/:id', requireAuth, checkStudentOwnership, (req, res) => {
  try {
    const student = queryOne('SELECT * FROM students WHERE id = ?', [req.params.id]);
    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }

    // Dynamic Success Score recalculation and breakdown
    const scoreBreakdown = calculateSuccessScore({
      cgpa: student.cgpa,
      backlogs: student.backlogs,
      attendance_percentage: student.attendance_percentage,
      lms_completion_rate: student.lms_completion_rate,
      coding_score: student.coding_score,
      aptitude_score: student.aptitude_score,
      mock_interview_score: student.mock_interview_score,
      communication_score: student.communication_score,
      skills_score: student.skills_score,
      engagement_score: student.engagement_score,
    });

    const academicRisk = evaluateAcademicRisk({
      cgpa: student.cgpa,
      backlogs: student.backlogs,
      attendance_percentage: student.attendance_percentage,
      lms_completion_rate: student.lms_completion_rate,
    });

    const placementRisk = evaluatePlacementRisk({
      coding_score: student.coding_score,
      aptitude_score: student.aptitude_score,
      mock_interview_score: student.mock_interview_score,
      communication_score: student.communication_score,
      placement_readiness_score: student.placement_readiness_score,
    });

    const insights = generateStudentInsights(student);

    // Sub-records
    const academicRecords = query('SELECT * FROM academic_records WHERE student_id = ? ORDER BY semester DESC, subject_code ASC', [student.id]);
    const attendanceRecords = query('SELECT * FROM attendance_records WHERE student_id = ? ORDER BY id ASC', [student.id]);
    const lmsRecords = query('SELECT * FROM lms_activity WHERE student_id = ? ORDER BY completion_percentage DESC', [student.id]);
    const placementRecords = query('SELECT * FROM placement_records WHERE student_id = ?', [student.id]);
    const skillRecords = query('SELECT * FROM skill_assessments WHERE student_id = ? ORDER BY category, score DESC', [student.id]);
    const interventions = query('SELECT * FROM interventions WHERE student_id = ? ORDER BY scheduled_date DESC', [student.id]);
    const feedback = query('SELECT * FROM student_feedback WHERE student_id = ?', [student.id]);

    return res.json({
      student,
      scoreBreakdown,
      academicRisk,
      placementRisk,
      insights,
      academicRecords,
      attendanceRecords,
      lmsRecords,
      placementRecord: placementRecords[0] || null,
      skillRecords,
      interventions,
      feedback,
    });
  } catch (err: any) {
    console.error('Error fetching student profile:', err);
    return res.status(500).json({ error: 'Failed to retrieve student profile.' });
  }
});

// GET /api/students/:id/journey - Academic trajectory
studentRouter.get('/:id/journey', requireAuth, checkStudentOwnership, (req, res) => {
  const student = queryOne('SELECT * FROM students WHERE id = ?', [req.params.id]);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  const subjects = query('SELECT * FROM academic_records WHERE student_id = ? ORDER BY semester, subject_name', [student.id]);

  // Compute semester trends
  const semesterTrend = [
    { semester: 'Sem 1', cgpa: (student.cgpa * 0.94).toFixed(2), attendance: (student.attendance_percentage * 0.98).toFixed(1) },
    { semester: 'Sem 2', cgpa: (student.cgpa * 0.96).toFixed(2), attendance: (student.attendance_percentage * 0.99).toFixed(1) },
    { semester: 'Sem 3', cgpa: (student.cgpa * 0.98).toFixed(2), attendance: (student.attendance_percentage * 1.01).toFixed(1) },
    { semester: 'Sem 4', cgpa: (student.cgpa * 0.99).toFixed(2), attendance: (student.attendance_percentage * 0.97).toFixed(1) },
    { semester: `Sem ${student.current_semester}`, cgpa: student.cgpa.toFixed(2), attendance: student.attendance_percentage.toFixed(1) },
  ];

  return res.json({
    studentId: student.id,
    currentCgpa: student.cgpa,
    backlogs: student.backlogs,
    subjects,
    semesterTrend,
  });
});

// GET /api/students/:id/recommendations - Curated recommendations
studentRouter.get('/:id/recommendations', requireAuth, checkStudentOwnership, (req, res) => {
  const student = queryOne('SELECT * FROM students WHERE id = ?', [req.params.id]);
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  const recommendations = [];

  if (student.coding_score < 65) {
    recommendations.push({
      id: 'rec-coding',
      category: 'Coding & Algorithms',
      priority: 'High',
      title: 'Master Graph Algorithms & Dynamic Programming',
      description: 'Strengthen core coding interview patterns on trees, graphs, and dynamic programming.',
      resource: 'DSA Mastery Workshop (Lab 302) & LeetCode Blind 75',
      estimatedHours: '12 hrs',
      actionUrl: '#coding-prep',
    });
  }

  if (student.attendance_percentage < 75) {
    recommendations.push({
      id: 'rec-attendance',
      category: 'Attendance & Compliance',
      priority: 'High',
      title: 'Mandatory Attendance Recovery Plan',
      description: 'Current attendance is below the 75% examination threshold. Attend all laboratory sessions and make-up classes.',
      resource: 'Dean Academic Counseling Office (Room 105)',
      estimatedHours: 'Immediate',
      actionUrl: '#attendance',
    });
  }

  if (student.aptitude_score < 70) {
    recommendations.push({
      id: 'rec-aptitude',
      category: 'Campus Placement',
      priority: 'Medium',
      title: 'Speed Aptitude & Logical Reasoning Drills',
      description: 'Practice time-boxed quantitative modules focusing on time-work, probability, and data interpretation.',
      resource: 'Campus Placement Portal — Diagnostic Test Series #4',
      estimatedHours: '6 hrs',
      actionUrl: '#placement',
    });
  }

  if (student.mock_interview_score < 70) {
    recommendations.push({
      id: 'rec-interview',
      category: 'Professional Skills',
      priority: 'Medium',
      title: 'Technical Communication & Resume Project Walkthrough',
      description: 'Refine your STAR-method narrative for behavioral questions and explain system design trade-offs.',
      resource: 'Mock Interview Simulator with Dr. Sarah Jenkins',
      estimatedHours: '3 hrs',
      actionUrl: '#interviews',
    });
  }

  // Always at least two recommendations
  recommendations.push({
    id: 'rec-cloud',
    category: 'Industry Certifications',
    priority: 'Low',
    title: 'Cloud Architecture & Microservices Certification',
    description: 'Supplement academic coursework with an industry-recognized cloud credential.',
    resource: 'AWS/GCP Student Builder Cloud Sandbox',
    estimatedHours: '20 hrs',
    actionUrl: '#certifications',
  });

  return res.json({ recommendations });
});
