import { Router } from 'express';
import { query, queryOne, run } from '../database/db.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../middleware/auth.js';

export const interventionRouter = Router();

// GET /api/interventions
interventionRouter.get('/', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const { studentId, status, priority } = req.query;
    let sql = 'SELECT * FROM interventions WHERE 1=1';
    const params: any[] = [];

    // If student, can only see their own interventions
    if (req.user?.role === 'student') {
      sql += ' AND student_id = ?';
      params.push(req.user.college_id || '');
    } else if (studentId) {
      sql += ' AND student_id = ?';
      params.push(studentId);
    }

    if (status && status !== 'All') {
      sql += ' AND status = ?';
      params.push(status);
    }

    if (priority && priority !== 'All') {
      sql += ' AND priority = ?';
      params.push(priority);
    }

    sql += ' ORDER BY created_at DESC';
    const interventions = query(sql, params);
    return res.json({ interventions });
  } catch (err: any) {
    console.error('Error fetching interventions:', err);
    return res.status(500).json({ error: 'Failed to retrieve interventions.' });
  }
});

// POST /api/interventions - Create intervention (Faculty & Admin)
interventionRouter.post('/', requireAuth, requireRole(['faculty', 'administrator']), (req: AuthenticatedRequest, res) => {
  try {
    const {
      student_id,
      intervention_type,
      description,
      suggested_action,
      priority = 'Medium',
      scheduled_date,
      follow_up_date,
      before_metric,
    } = req.body;

    if (!student_id || !intervention_type || !description || !suggested_action) {
      return res.status(400).json({ error: 'Student ID, intervention type, description, and action are required.' });
    }

    // Verify student exists
    const student = queryOne('SELECT id, full_name, cgpa, attendance_percentage FROM students WHERE id = ?', [student_id]);
    if (!student) {
      return res.status(404).json({ error: `Student '${student_id}' does not exist.` });
    }

    const id = `INV-${Date.now()}`;
    const facultyName = req.user?.full_name || 'Academic Mentor';
    const facultyId = req.user?.id || 'FAC-001';
    const metricVal = before_metric !== undefined ? parseFloat(before_metric) : student.attendance_percentage;

    run(`
      INSERT INTO interventions (
        id, student_id, faculty_id, faculty_name, intervention_type, description, suggested_action,
        priority, status, scheduled_date, follow_up_date, before_metric
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?)
    `, [
      id,
      student_id,
      facultyId,
      facultyName,
      intervention_type,
      description,
      suggested_action,
      priority,
      scheduled_date || new Date().toISOString().split('T')[0],
      follow_up_date || null,
      metricVal,
    ]);

    const created = queryOne('SELECT * FROM interventions WHERE id = ?', [id]);
    return res.status(201).json({ message: 'Intervention scheduled successfully.', intervention: created });
  } catch (err: any) {
    console.error('Error creating intervention:', err);
    return res.status(500).json({ error: 'Failed to record intervention.' });
  }
});

// PATCH /api/interventions/:id - Update status and outcome notes
interventionRouter.patch('/:id', requireAuth, requireRole(['faculty', 'administrator']), (req, res) => {
  try {
    const { id } = req.params;
    const { status, outcome_notes, after_metric, follow_up_date } = req.body;

    const existing = queryOne('SELECT * FROM interventions WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ error: 'Intervention not found.' });
    }

    const updatedStatus = status || existing.status;
    const updatedOutcome = outcome_notes !== undefined ? outcome_notes : existing.outcome_notes;
    const updatedAfterMetric = after_metric !== undefined ? parseFloat(after_metric) : existing.after_metric;
    const updatedFollowDate = follow_up_date !== undefined ? follow_up_date : existing.follow_up_date;

    run(`
      UPDATE interventions
      SET status = ?, outcome_notes = ?, after_metric = ?, follow_up_date = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [updatedStatus, updatedOutcome, updatedAfterMetric, updatedFollowDate, id]);

    const updated = queryOne('SELECT * FROM interventions WHERE id = ?', [id]);
    return res.json({ message: 'Intervention updated successfully.', intervention: updated });
  } catch (err: any) {
    console.error('Error updating intervention:', err);
    return res.status(500).json({ error: 'Failed to update intervention.' });
  }
});
