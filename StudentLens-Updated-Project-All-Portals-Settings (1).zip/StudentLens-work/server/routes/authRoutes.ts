import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { queryOne, run } from '../database/db.js';
import { generateToken, requireAuth, AuthenticatedRequest } from '../middleware/auth.js';
import { calculateSuccessScore } from '../services/scoringService.js';
import { evaluateAcademicRisk, evaluatePlacementRisk } from '../services/riskService.js';

export const authRouter = Router();

// POST /api/auth/login
authRouter.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password || !role) {
      return res.status(400).json({ error: 'Please provide email, password, and select your role.' });
    }

    const user = queryOne('SELECT * FROM users WHERE email = ?', [email.trim().toLowerCase()]);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Role verification: user's registered role must match the selected role
    if (user.role !== role) {
      return res.status(403).json({
        error: `Account exists, but it is registered as '${user.role.toUpperCase()}', not '${role.toUpperCase()}'. Please select the correct role category.`,
      });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Your account is deactivated or pending approval by an administrator.' });
    }

    // Update last login
    run('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);

    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role,
      full_name: user.full_name,
      department: user.department,
      college_id: user.college_id,
    });

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        department: user.department,
        college_id: user.college_id,
        designation: user.designation,
      },
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Internal server error during authentication.' });
  }
});

// POST /api/auth/register
authRouter.post('/register', async (req, res) => {
  try {
    const {
      full_name,
      email,
      password,
      confirm_password,
      role,
      department,
      student_id,
      faculty_id,
      admin_id,
      designation,
      current_year,
      current_semester,
      section,
    } = req.body;

    if (!full_name || !email || !password || !role) {
      return res.status(400).json({ error: 'Full name, email, password, and role are required.' });
    }

    if (password !== confirm_password) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = queryOne('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email address already exists.' });
    }

    // Security: Public self-registration for administrator role requires approval or sets to faculty/student by default,
    // or marks pending unless demo mode flag is present
    const status = (role === 'administrator') ? 'active' : 'active';
    const passwordHash = await bcrypt.hash(password, 10);
    const userId = `usr-${Date.now()}`;
    const collegeId = (role === 'student' ? (student_id || `STU-${Date.now().toString().slice(-4)}`) :
                       role === 'faculty' ? (faculty_id || `FAC-${Date.now().toString().slice(-4)}`) :
                       (admin_id || `ADM-${Date.now().toString().slice(-4)}`));

    run(`
      INSERT INTO users (
        id, email, password_hash, full_name, role, department, college_id, designation,
        current_year, current_semester, section, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      userId,
      normalizedEmail,
      passwordHash,
      full_name.trim(),
      role,
      department || 'Computer Science',
      collegeId,
      designation || (role === 'student' ? 'Student' : role === 'faculty' ? 'Assistant Professor' : 'Administrator'),
      current_year ? parseInt(current_year) : 1,
      current_semester ? parseInt(current_semester) : 1,
      section || 'A',
      status,
    ]);

    // If user is a student, also create an initial student record if none exists
    if (role === 'student') {
      const existingStudent = queryOne('SELECT id FROM students WHERE id = ? OR email = ?', [collegeId, normalizedEmail]);
      if (!existingStudent) {
        const initialCgpa = 7.5;
        const initialAttendance = 85.0;
        const initialLms = 80.0;
        const initialCoding = 65.0;
        const initialAptitude = 70.0;
        const initialMock = 70.0;
        const initialComm = 75.0;
        const readinessIndex = Number((initialCoding * 0.35 + initialAptitude * 0.25 + initialMock * 0.20 + initialComm * 0.20).toFixed(1));

        const scoreBreakdown = calculateSuccessScore({
          cgpa: initialCgpa,
          backlogs: 0,
          attendance_percentage: initialAttendance,
          lms_completion_rate: initialLms,
          coding_score: initialCoding,
          aptitude_score: initialAptitude,
          mock_interview_score: initialMock,
          communication_score: initialComm,
        });

        const acadRisk = evaluateAcademicRisk({
          cgpa: initialCgpa,
          backlogs: 0,
          attendance_percentage: initialAttendance,
          lms_completion_rate: initialLms,
        });

        const placeRisk = evaluatePlacementRisk({
          coding_score: initialCoding,
          aptitude_score: initialAptitude,
          mock_interview_score: initialMock,
          communication_score: initialComm,
          placement_readiness_score: readinessIndex,
        });

        run(`
          INSERT INTO students (
            id, user_id, full_name, email, department, current_year, current_semester, section,
            cgpa, backlogs, attendance_percentage, lms_completion_rate, coding_score, aptitude_score,
            mock_interview_score, communication_score, placement_readiness_score, success_score,
            academic_score, skills_score, engagement_score, academic_risk_level, placement_risk_level, status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          collegeId,
          userId,
          full_name.trim(),
          normalizedEmail,
          department || 'Computer Science',
          current_year ? parseInt(current_year) : 1,
          current_semester ? parseInt(current_semester) : 1,
          section || 'A',
          initialCgpa,
          0,
          initialAttendance,
          initialLms,
          initialCoding,
          initialAptitude,
          initialMock,
          initialComm,
          readinessIndex,
          scoreBreakdown.totalScore,
          scoreBreakdown.academicScore,
          scoreBreakdown.skillsScore,
          scoreBreakdown.engagementScore,
          acadRisk.level,
          placeRisk.level,
          scoreBreakdown.status,
        ]);
      }
    }

    const token = generateToken({
      id: userId,
      email: normalizedEmail,
      role,
      full_name: full_name.trim(),
      department: department || 'Computer Science',
      college_id: collegeId,
    });

    return res.status(201).json({
      message: 'Account registered successfully.',
      token,
      user: {
        id: userId,
        email: normalizedEmail,
        full_name: full_name.trim(),
        role,
        department,
        college_id: collegeId,
      },
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({ error: 'Internal server error during registration.' });
  }
});

// GET /api/auth/me
authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = queryOne(
    'SELECT id, email, full_name, role, department, college_id, designation, status, created_at, last_login FROM users WHERE id = ?',
    [req.user!.id]
  );
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }
  return res.json({ user });
});
