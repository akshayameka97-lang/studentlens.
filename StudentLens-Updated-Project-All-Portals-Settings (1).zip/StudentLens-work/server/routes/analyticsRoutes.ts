import { Router } from 'express';
import { query, queryOne } from '../database/db.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../middleware/auth.js';
import { segmentStudents } from '../services/segmentationService.js';

export const analyticsRouter = Router();

// GET /api/analytics/overview - Institution & Department Analytics
analyticsRouter.get('/overview', requireAuth, requireRole(['faculty', 'administrator']), (req: AuthenticatedRequest, res) => {
  try {
    const { department, year, semester } = req.query;

    let filterSql = 'WHERE 1=1';
    const params: any[] = [];

    // Scope check: If faculty scoped to department
    if (req.user?.role === 'faculty' && req.query.facultyScope === 'department' && req.user.department) {
      filterSql += ' AND department = ?';
      params.push(req.user.department);
    } else if (department && department !== 'All') {
      filterSql += ' AND department = ?';
      params.push(department);
    }

    if (year && year !== 'All') {
      filterSql += ' AND current_year = ?';
      params.push(parseInt(year as string));
    }

    if (semester && semester !== 'All') {
      filterSql += ' AND current_semester = ?';
      params.push(parseInt(semester as string));
    }

    const students = query(`SELECT * FROM students ${filterSql}`, params);
    const totalStudents = students.length;

    if (totalStudents === 0) {
      return res.json({
        totalStudents: 0,
        averageSuccessScore: 0,
        averageCgpa: 0,
        averageAttendance: 0,
        averagePlacementScore: 0,
        statusDistribution: { onTrack: 0, needsAttention: 0, atRisk: 0 },
        riskCounts: { academicHigh: 0, academicMed: 0, placementHigh: 0, placementMed: 0 },
        departmentBreakdown: [],
        scoreDistribution: [],
        attendanceTrend: [],
      });
    }

    const avgSuccess = Number((students.reduce((acc, s) => acc + s.success_score, 0) / totalStudents).toFixed(1));
    const avgCgpa = Number((students.reduce((acc, s) => acc + s.cgpa, 0) / totalStudents).toFixed(2));
    const avgAttendance = Number((students.reduce((acc, s) => acc + s.attendance_percentage, 0) / totalStudents).toFixed(1));
    const avgPlacement = Number((students.reduce((acc, s) => acc + s.placement_readiness_score, 0) / totalStudents).toFixed(1));

    const onTrackCount = students.filter(s => s.status === 'On Track').length;
    const needsAttentionCount = students.filter(s => s.status === 'Needs Attention').length;
    const atRiskCount = students.filter(s => s.status === 'At Risk').length;

    const academicHighCount = students.filter(s => s.academic_risk_level === 'High').length;
    const academicMedCount = students.filter(s => s.academic_risk_level === 'Medium').length;
    const placementHighCount = students.filter(s => s.placement_risk_level === 'High').length;
    const placementMedCount = students.filter(s => s.placement_risk_level === 'Medium').length;

    // Department Breakdown
    const deptMap: Record<string, { count: number; totalScore: number; totalCgpa: number; totalPlacement: number; atRisk: number }> = {};
    for (const s of students) {
      if (!deptMap[s.department]) {
        deptMap[s.department] = { count: 0, totalScore: 0, totalCgpa: 0, totalPlacement: 0, atRisk: 0 };
      }
      deptMap[s.department].count++;
      deptMap[s.department].totalScore += s.success_score;
      deptMap[s.department].totalCgpa += s.cgpa;
      deptMap[s.department].totalPlacement += s.placement_readiness_score;
      if (s.status === 'At Risk') deptMap[s.department].atRisk++;
    }

    const departmentBreakdown = Object.keys(deptMap).map(dept => {
      const data = deptMap[dept];
      return {
        department: dept,
        studentCount: data.count,
        avgSuccessScore: Number((data.totalScore / data.count).toFixed(1)),
        avgCgpa: Number((data.totalCgpa / data.count).toFixed(2)),
        avgPlacement: Number((data.totalPlacement / data.count).toFixed(1)),
        atRiskCount: data.atRisk,
      };
    });

    // Score Range Distribution for Donut Chart
    const scoreDistribution = [
      { range: '90–100 (Excellence)', count: students.filter(s => s.success_score >= 90).length, color: '#344D42' },
      { range: '80–89.9 (On Track)', count: students.filter(s => s.success_score >= 80 && s.success_score < 90).length, color: '#43866A' },
      { range: '70–79.9 (Moderate)', count: students.filter(s => s.success_score >= 70 && s.success_score < 80).length, color: '#668575' },
      { range: '60–69.9 (Needs Attention)', count: students.filter(s => s.success_score >= 60 && s.success_score < 70).length, color: '#D7A45A' },
      { range: '< 60 (At Risk)', count: students.filter(s => s.success_score < 60).length, color: '#C66F68' },
    ];

    // Attendance vs Academic Performance correlation data
    const correlationSample = students.slice(0, 40).map(s => ({
      name: s.full_name,
      id: s.id,
      attendance: s.attendance_percentage,
      cgpa: s.cgpa,
      placement: s.placement_readiness_score,
      coding: s.coding_score,
      status: s.status,
    }));

    return res.json({
      totalStudents,
      averageSuccessScore: avgSuccess,
      averageCgpa: avgCgpa,
      averageAttendance: avgAttendance,
      averagePlacementScore: avgPlacement,
      statusDistribution: {
        onTrack: onTrackCount,
        needsAttention: needsAttentionCount,
        atRisk: atRiskCount,
      },
      riskCounts: {
        academicHigh: academicHighCount,
        academicMed: academicMedCount,
        placementHigh: placementHighCount,
        placementMed: placementMedCount,
      },
      departmentBreakdown,
      scoreDistribution,
      correlationSample,
    });
  } catch (err: any) {
    console.error('Analytics overview error:', err);
    return res.status(500).json({ error: 'Failed to generate analytics overview.' });
  }
});

// GET /api/analytics/segments - Student Segmentation
analyticsRouter.get('/segments', requireAuth, requireRole(['faculty', 'administrator']), (req, res) => {
  try {
    const students = query('SELECT * FROM students');
    const segments = segmentStudents(students);
    return res.json({ segments });
  } catch (err: any) {
    console.error('Segmentation error:', err);
    return res.status(500).json({ error: 'Failed to compute student segments.' });
  }
});

// GET /api/analytics/risk - Filtered At-Risk cohort analysis
analyticsRouter.get('/risk', requireAuth, requireRole(['faculty', 'administrator']), (req, res) => {
  try {
    const { category = 'all' } = req.query;

    let academicRiskList: any[] = [];
    let placementRiskList: any[] = [];

    if (category === 'all' || category === 'academic') {
      academicRiskList = query(`
        SELECT id, full_name, department, current_year, section, cgpa, backlogs, attendance_percentage, academic_risk_level, success_score
        FROM students
        WHERE academic_risk_level IN ('High', 'Medium')
        ORDER BY CASE academic_risk_level WHEN 'High' THEN 1 ELSE 2 END, cgpa ASC
      `);
    }

    if (category === 'all' || category === 'placement') {
      placementRiskList = query(`
        SELECT id, full_name, department, current_year, section, coding_score, aptitude_score, mock_interview_score, placement_readiness_score, placement_risk_level, success_score
        FROM students
        WHERE placement_risk_level IN ('High', 'Medium')
        ORDER BY CASE placement_risk_level WHEN 'High' THEN 1 ELSE 2 END, placement_readiness_score ASC
      `);
    }

    return res.json({
      academicRiskList,
      placementRiskList,
    });
  } catch (err: any) {
    console.error('Risk analytics error:', err);
    return res.status(500).json({ error: 'Failed to retrieve risk analysis.' });
  }
});
