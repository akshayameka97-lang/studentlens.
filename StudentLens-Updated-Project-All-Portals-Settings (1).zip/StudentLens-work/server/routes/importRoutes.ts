import { Router } from 'express';
import Papa from 'papaparse';
import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';
import { query, queryOne, run } from '../database/db.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../middleware/auth.js';
import { calculateSuccessScore } from '../services/scoringService.js';
import { evaluateAcademicRisk, evaluatePlacementRisk } from '../services/riskService.js';

export const importRouter = Router();

// POST /api/import/csv - Parse and ingest CSV records
importRouter.post('/csv', requireAuth, requireRole(['faculty', 'administrator']), (req: AuthenticatedRequest, res) => {
  try {
    const { category, csvContent, fileName = 'uploaded_data.csv' } = req.body;

    if (!csvContent || typeof csvContent !== 'string') {
      return res.status(400).json({ error: 'Please provide CSV content in the request body.' });
    }

    if (!['academic', 'attendance', 'placement', 'skills', 'lms'].includes(category)) {
      return res.status(400).json({ error: 'Invalid category. Must be one of: academic, attendance, placement, skills, lms.' });
    }

    const parsed = Papa.parse(csvContent.trim(), {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
    });

    if (parsed.errors && parsed.errors.length > 0) {
      console.warn('Papa parse warnings:', parsed.errors);
    }

    const rows = parsed.data as any[];
    if (rows.length === 0) {
      return res.status(400).json({ error: 'The uploaded CSV file contains no valid rows.' });
    }

    let successCount = 0;
    let failCount = 0;
    const errors: string[] = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const studentId = row.student_id ? String(row.student_id).trim() : null;

      if (!studentId) {
        failCount++;
        errors.push(`Row ${i + 1}: Missing student_id.`);
        continue;
      }

      // Check if student exists
      const existingStudent = queryOne('SELECT * FROM students WHERE id = ?', [studentId]);
      if (!existingStudent) {
        failCount++;
        errors.push(`Row ${i + 1}: Student with ID '${studentId}' does not exist.`);
        continue;
      }

      try {
        if (category === 'academic') {
          const semester = row.semester || existingStudent.current_semester;
          const code = row.subject_code || 'CS-GEN';
          const name = row.subject_name || 'Elective Course';
          const marks = parseFloat(row.marks_obtained) || 75;
          const maxMarks = parseFloat(row.max_marks) || 100;
          const grade = row.grade || (marks >= 80 ? 'A' : marks >= 60 ? 'B' : 'C');
          const examType = row.exam_type || 'Internal';

          run(`
            INSERT INTO academic_records (id, student_id, semester, subject_code, subject_name, marks_obtained, max_marks, grade, exam_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [`IMP-ACAD-${Date.now()}-${i}`, studentId, semester, code, name, marks, maxMarks, grade, examType]);

          // Recalculate CGPA approximation
          const avgMarks = queryOne<{ avg: number }>('SELECT AVG(marks_obtained) as avg FROM academic_records WHERE student_id = ?', [studentId]);
          if (avgMarks?.avg) {
            const newCgpa = Number(((avgMarks.avg / 10)).toFixed(2));
            run('UPDATE students SET cgpa = ? WHERE id = ?', [newCgpa, studentId]);
          }
        } else if (category === 'attendance') {
          const month = row.month || 'Recent';
          const percentage = parseFloat(row.percentage) || parseFloat(row.attendance_percentage) || 80.0;
          const attended = row.attended_classes || Math.round((percentage / 100) * 30);
          const total = row.total_classes || 30;

          run(`
            INSERT INTO attendance_records (id, student_id, month, subject_name, attended_classes, total_classes, percentage)
            VALUES (?, ?, ?, 'Imported Subject', ?, ?, ?)
          `, [`IMP-ATT-${Date.now()}-${i}`, studentId, month, attended, total, percentage]);

          // Update student current attendance
          run('UPDATE students SET attendance_percentage = ? WHERE id = ?', [percentage, studentId]);
        } else if (category === 'placement') {
          const aptitude = parseFloat(row.aptitude_score) || existingStudent.aptitude_score;
          const coding = parseFloat(row.coding_score) || existingStudent.coding_score;
          const mock = parseFloat(row.mock_interview_score) || existingStudent.mock_interview_score;
          const comm = parseFloat(row.communication_score) || existingStudent.communication_score;
          const readiness = Number((coding * 0.35 + aptitude * 0.25 + mock * 0.20 + comm * 0.20).toFixed(1));

          run(`
            UPDATE students
            SET aptitude_score = ?, coding_score = ?, mock_interview_score = ?, communication_score = ?, placement_readiness_score = ?
            WHERE id = ?
          `, [aptitude, coding, mock, comm, readiness, studentId]);
        } else if (category === 'skills') {
          const skillName = row.skill_name || 'Applied Skill';
          const cat = row.category || 'Technical';
          const score = parseFloat(row.score) || 75;

          run(`
            INSERT INTO skill_assessments (id, student_id, skill_name, category, score, max_score)
            VALUES (?, ?, ?, ?, ?, 100)
          `, [`IMP-SK-${Date.now()}-${i}`, studentId, skillName, cat, score]);
        } else if (category === 'lms') {
          const lmsRate = parseFloat(row.completion_percentage) || parseFloat(row.lms_completion_rate) || 80;
          run('UPDATE students SET lms_completion_rate = ? WHERE id = ?', [lmsRate, studentId]);
        }

        // Always recompute student success score and risk flags after any import update
        const updatedStu = queryOne('SELECT * FROM students WHERE id = ?', [studentId]);
        if (updatedStu) {
          const scoreResult = calculateSuccessScore(updatedStu);
          const acadRisk = evaluateAcademicRisk(updatedStu);
          const placeRisk = evaluatePlacementRisk(updatedStu);

          run(`
            UPDATE students
            SET success_score = ?, academic_score = ?, skills_score = ?, engagement_score = ?,
                academic_risk_level = ?, placement_risk_level = ?, status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `, [
            scoreResult.totalScore,
            scoreResult.academicScore,
            scoreResult.skillsScore,
            scoreResult.engagementScore,
            acadRisk.level,
            placeRisk.level,
            scoreResult.status,
            studentId,
          ]);
        }

        successCount++;
      } catch (err: any) {
        failCount++;
        errors.push(`Row ${i + 1}: ${err.message}`);
      }
    }

    // Log import history
    const importId = `JOB-${Date.now()}`;
    run(`
      INSERT INTO import_history (id, file_name, category, total_records, successful_records, failed_records, imported_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [
      importId,
      fileName,
      category,
      rows.length,
      successCount,
      failCount,
      req.user?.full_name || 'Administrator',
    ]);

    return res.json({
      message: `Processed ${rows.length} records: ${successCount} successful, ${failCount} failed.`,
      summary: {
        total: rows.length,
        successful: successCount,
        failed: failCount,
        errors: errors.slice(0, 5),
      },
    });
  } catch (err: any) {
    console.error('CSV import error:', err);
    return res.status(500).json({ error: 'Failed to process CSV import.' });
  }
});

// GET /api/import/history
importRouter.get('/history', requireAuth, requireRole(['faculty', 'administrator']), (req, res) => {
  const history = query('SELECT * FROM import_history ORDER BY created_at DESC LIMIT 20');
  return res.json({ history });
});

// GET /api/export/csv - Export filtered student data
importRouter.get('/export', requireAuth, requireRole(['faculty', 'administrator']), (req, res) => {
  try {
    const students = query(`
      SELECT id, full_name, email, department, current_year, current_semester, section,
             cgpa, backlogs, attendance_percentage, lms_completion_rate, coding_score,
             aptitude_score, placement_readiness_score, success_score, academic_risk_level,
             placement_risk_level, status
      FROM students
      ORDER BY success_score DESC
    `);

    const csv = Papa.unparse(students);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="studentlens_analytics_export.csv"');
    return res.send(csv);
  } catch (err: any) {
    console.error('Export error:', err);
    return res.status(500).json({ error: 'Failed to generate export file.' });
  }
});

// GET /api/export/project-zip - Bundle complete project into ZIP for VS Code
importRouter.get('/project-zip', async (req, res) => {
  try {
    const zip = new JSZip();
    const rootDir = process.cwd();

    function addDirToZip(folderPath: string, zipFolder: JSZip) {
      const items = fs.readdirSync(folderPath);
      for (const item of items) {
        if (
          item === 'node_modules' ||
          item === '.git' ||
          item === 'dist' ||
          item === '.DS_Store' ||
          item === '.aistudio'
        ) {
          continue;
        }

        const fullPath = path.join(folderPath, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
          const subFolder = zipFolder.folder(item);
          if (subFolder) addDirToZip(fullPath, subFolder);
        } else {
          // Add file buffer
          const content = fs.readFileSync(fullPath);
          zipFolder.file(item, content);
        }
      }
    }

    addDirToZip(rootDir, zip);

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="StudentLens-Complete-VSCode-Project.zip"');
    return res.send(zipBuffer);
  } catch (err: any) {
    console.error('Zip generation error:', err);
    return res.status(500).json({ error: 'Failed to generate project ZIP archive.' });
  }
});
