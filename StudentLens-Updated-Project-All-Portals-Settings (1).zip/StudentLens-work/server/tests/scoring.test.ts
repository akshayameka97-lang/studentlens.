import { calculateSuccessScore } from '../services/scoringService.js';
import { evaluateAcademicRisk, evaluatePlacementRisk } from '../services/riskService.js';
import { segmentStudents } from '../services/segmentationService.js';

console.log('🧪 Running StudentLens Unit Tests...');

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✅ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${testName}`);
    failed++;
  }
}

// Test 1: Student Success Score Calculation Engine
const scoreResult = calculateSuccessScore({
  cgpa: 8.5,
  backlogs: 0,
  attendance_percentage: 90.0,
  lms_completion_rate: 85.0,
  coding_score: 80.0,
  aptitude_score: 75.0,
  mock_interview_score: 70.0,
  communication_score: 80.0,
});

assert(scoreResult.totalScore > 75 && scoreResult.totalScore <= 100, 'Success score should be between 75 and 100 for high performer');
assert(scoreResult.status === 'On Track', 'High performer should have status "On Track"');
assert(scoreResult.completeness === 100, 'All fields populated should yield 100% data completeness');

// Test 2: Academic Risk Detection
const highRiskStudent = evaluateAcademicRisk({
  cgpa: 5.2,
  backlogs: 2,
  attendance_percentage: 62.0,
  lms_completion_rate: 45.0,
});
assert(highRiskStudent.level === 'High', 'Student with backlogs >= 2 and attendance < 65% must be flagged as High Academic Risk');
assert(highRiskStudent.factors.length >= 2, 'High risk student should have multiple identified explainable risk factors');

// Test 3: Placement Risk Detection
const placementRiskStudent = evaluatePlacementRisk({
  coding_score: 38.0,
  aptitude_score: 42.0,
  mock_interview_score: 45.0,
  communication_score: 55.0,
  placement_readiness_score: 44.0,
});
assert(placementRiskStudent.level === 'High', 'Low coding and aptitude must trigger High Placement Risk');

// Test 4: Student Segmentation Logic
const sampleCohort = [
  { id: '1', cgpa: 8.5, academic_score: 85, placement_readiness_score: 45, success_score: 72, attendance_percentage: 90, lms_completion_rate: 85, coding_score: 40, aptitude_score: 45, backlogs: 0, academic_risk_level: 'Low' },
  { id: '2', cgpa: 5.4, academic_score: 50, placement_readiness_score: 50, success_score: 52, attendance_percentage: 60, lms_completion_rate: 50, coding_score: 45, aptitude_score: 50, backlogs: 2, academic_risk_level: 'High' },
  { id: '3', cgpa: 9.2, academic_score: 92, placement_readiness_score: 88, success_score: 90, attendance_percentage: 95, lms_completion_rate: 94, coding_score: 90, aptitude_score: 85, backlogs: 0, academic_risk_level: 'Low' },
];

const segments = segmentStudents(sampleCohort);
const highAcadLowPlace = segments.find(s => s.id === 'high-acad-low-place');
const acadAtRisk = segments.find(s => s.id === 'academic-at-risk');
const highPerformers = segments.find(s => s.id === 'high-performers');

assert(highAcadLowPlace !== undefined && highAcadLowPlace.studentCount === 1, 'Should identify 1 High Academic + Low Placement student');
assert(acadAtRisk !== undefined && acadAtRisk.studentCount === 1, 'Should identify 1 Academic At Risk student');
assert(highPerformers !== undefined && highPerformers.studentCount === 1, 'Should identify 1 High Performer student');

console.log(`\n🎉 Test Suite Completed: ${passed} passed, ${failed} failed.`);

if (failed > 0) {
  process.exit(1);
}
