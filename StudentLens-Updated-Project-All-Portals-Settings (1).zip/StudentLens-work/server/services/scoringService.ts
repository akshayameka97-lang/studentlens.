export interface ScoreWeights {
  academic: number;
  attendance: number;
  lms: number;
  placement: number;
  skills: number;
  engagement: number;
}

export const DEFAULT_WEIGHTS: ScoreWeights = {
  academic: 0.30,
  attendance: 0.20,
  lms: 0.15,
  placement: 0.20,
  skills: 0.10,
  engagement: 0.05,
};

export interface SuccessScoreBreakdown {
  totalScore: number;
  academicScore: number;
  attendanceScore: number;
  lmsScore: number;
  placementScore: number;
  skillsScore: number;
  engagementScore: number;
  status: 'On Track' | 'Needs Attention' | 'At Risk';
  completeness: number; // 0-100%
  weights: ScoreWeights;
}

export function clamp(val: number, min = 0, max = 100): number {
  return Math.min(Math.max(val, min), max);
}

export function calculateSuccessScore(student: {
  cgpa: number;
  backlogs?: number;
  attendance_percentage: number;
  lms_completion_rate: number;
  coding_score: number;
  aptitude_score: number;
  mock_interview_score: number;
  communication_score: number;
  skills_score?: number;
  engagement_score?: number;
}, customWeights: Partial<ScoreWeights> = {}): SuccessScoreBreakdown {
  const weights: ScoreWeights = { ...DEFAULT_WEIGHTS, ...customWeights };

  // 1. Academic Score (CGPA normalized, with backlog deduction)
  const backlogs = student.backlogs || 0;
  const rawAcademic = (student.cgpa / 10) * 100 - backlogs * 6;
  const academicScore = clamp(Number(rawAcademic.toFixed(1)));

  // 2. Attendance Score
  const attendanceScore = clamp(Number(student.attendance_percentage.toFixed(1)));

  // 3. LMS Score
  const lmsScore = clamp(Number(student.lms_completion_rate.toFixed(1)));

  // 4. Placement Score (composite of coding, aptitude, mock, communication)
  const rawPlacement = (
    student.coding_score * 0.35 +
    student.aptitude_score * 0.25 +
    student.mock_interview_score * 0.20 +
    student.communication_score * 0.20
  );
  const placementScore = clamp(Number(rawPlacement.toFixed(1)));

  // 5. Skills Score
  const skillsScore = clamp(Number((student.skills_score ?? ((student.coding_score + student.communication_score) / 2)).toFixed(1)));

  // 6. Engagement Score
  const engagementScore = clamp(Number((student.engagement_score ?? ((student.attendance_percentage * 0.5) + (student.lms_completion_rate * 0.5))).toFixed(1)));

  // Weighted Total
  const totalScore = clamp(Number((
    academicScore * weights.academic +
    attendanceScore * weights.attendance +
    lmsScore * weights.lms +
    placementScore * weights.placement +
    skillsScore * weights.skills +
    engagementScore * weights.engagement
  ).toFixed(1)));

  let status: 'On Track' | 'Needs Attention' | 'At Risk' = 'On Track';
  if (totalScore >= 80) {
    status = 'On Track';
  } else if (totalScore >= 60) {
    status = 'Needs Attention';
  } else {
    status = 'At Risk';
  }

  // Data completeness check
  let completenessFields = 0;
  if (student.cgpa > 0) completenessFields++;
  if (student.attendance_percentage > 0) completenessFields++;
  if (student.lms_completion_rate > 0) completenessFields++;
  if (student.coding_score > 0) completenessFields++;
  if (student.aptitude_score > 0) completenessFields++;
  const completeness = Math.round((completenessFields / 5) * 100);

  return {
    totalScore,
    academicScore,
    attendanceScore,
    lmsScore,
    placementScore,
    skillsScore,
    engagementScore,
    status,
    completeness,
    weights,
  };
}
