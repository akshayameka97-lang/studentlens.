export interface StudentSegment {
  id: string;
  name: string;
  badge: string;
  color: string;
  description: string;
  criteria: string;
  recommendedIntervention: string;
  studentCount: number;
  percentage: number;
  studentIds: string[];
}

export function segmentStudents(students: Array<any>): StudentSegment[] {
  const total = students.length || 1;

  // Segment 1: High Academic + Low Placement Readiness
  const highAcadLowPlace = students.filter(
    (s) => (s.cgpa >= 7.5 || s.academic_score >= 75) && s.placement_readiness_score < 60
  );

  // Segment 2: Academic At Risk
  const academicRisk = students.filter(
    (s) => s.academic_risk_level === 'High' || s.cgpa < 6.0 || s.backlogs > 0 || s.attendance_percentage < 65
  );

  // Segment 3: High Engagement + Low Assessment
  const highEngageLowAssess = students.filter(
    (s) => (s.attendance_percentage >= 80 && s.lms_completion_rate >= 75) && (s.cgpa < 6.8 || s.academic_score < 65)
  );

  // Segment 4: High Performers
  const highPerformers = students.filter(
    (s) => s.success_score >= 80 && s.cgpa >= 8.2 && s.placement_readiness_score >= 75
  );

  // Segment 5: Placement Specialists / Industry Ready
  const placementReady = students.filter(
    (s) => s.coding_score >= 80 && s.aptitude_score >= 75 && s.placement_readiness_score >= 80
  );

  // Segment 6: Attendance Watch
  const attendanceWatch = students.filter(
    (s) => s.attendance_percentage < 75 && s.cgpa >= 7.0
  );

  const segments: StudentSegment[] = [
    {
      id: 'high-acad-low-place',
      name: 'High Academics, Low Placement Readiness',
      badge: 'Placement Gap',
      color: '#D7A45A', // warning amber
      description: 'Excelling academically (CGPA ≥ 7.5) but struggling in industry placement assessments (coding/aptitude < 60).',
      criteria: 'CGPA ≥ 7.5 AND Placement Score < 60',
      recommendedIntervention: 'Intensive 4-week Coding & Mock Interview bootcamp to convert academic theory into industry interview execution.',
      studentCount: highAcadLowPlace.length,
      percentage: Math.round((highAcadLowPlace.length / total) * 100),
      studentIds: highAcadLowPlace.map((s) => s.id),
    },
    {
      id: 'academic-at-risk',
      name: 'Academic Risk Cohort',
      badge: 'Academic Alert',
      color: '#C66F68', // risk red
      description: 'Students facing retention or graduation delays due to backlogs, low CGPA (< 6.0), or severe attendance deficit.',
      criteria: 'Academic Risk = High OR CGPA < 6.0 OR Backlogs > 0',
      recommendedIntervention: 'Immediate 1-on-1 faculty advisor conference, remedial study cohorts, and weekly subject tutoring.',
      studentCount: academicRisk.length,
      percentage: Math.round((academicRisk.length / total) * 100),
      studentIds: academicRisk.map((s) => s.id),
    },
    {
      id: 'high-engage-low-assess',
      name: 'High Effort, Low Assessment Yield',
      badge: 'Learning Gap',
      color: '#668575', // muted green
      description: 'Dedicated students with high attendance (≥80%) and LMS engagement, but suboptimal exam/test conversions (<65%).',
      criteria: 'Attendance ≥ 80% AND LMS ≥ 75% AND CGPA < 6.8',
      recommendedIntervention: 'Diagnostic exam review: transition from passive study habits to active recall, practice tests, and problem-solving.',
      studentCount: highEngageLowAssess.length,
      percentage: Math.round((highEngageLowAssess.length / total) * 100),
      studentIds: highEngageLowAssess.map((s) => s.id),
    },
    {
      id: 'high-performers',
      name: 'Star Performers (All-Rounders)',
      badge: 'Exemplary',
      color: '#43866A', // success emerald
      description: 'Top-tier cohort with outstanding academic consistency, high attendance, and superior placement readiness.',
      criteria: 'Success Score ≥ 80 AND CGPA ≥ 8.2 AND Placement ≥ 75',
      recommendedIntervention: 'Nominate for research fellowships, tier-1 marquee campus recruitments, and peer-mentorship leadership roles.',
      studentCount: highPerformers.length,
      percentage: Math.round((highPerformers.length / total) * 100),
      studentIds: highPerformers.map((s) => s.id),
    },
    {
      id: 'placement-ready',
      name: 'Placement Ready Specialists',
      badge: 'Ready to Hire',
      color: '#344D42', // deep emerald
      description: 'High technical aptitude (Coding ≥ 80, Aptitude ≥ 75) primed for campus hiring drives.',
      criteria: 'Coding ≥ 80 AND Aptitude ≥ 75 AND Placement ≥ 80',
      recommendedIntervention: 'Fast-track to early corporate drive screenings and hackathon delegations.',
      studentCount: placementReady.length,
      percentage: Math.round((placementReady.length / total) * 100),
      studentIds: placementReady.map((s) => s.id),
    },
    {
      id: 'attendance-watch',
      name: 'Attendance Watch (Potential Intact)',
      badge: 'Attendance Caution',
      color: '#D7A45A', // warning amber
      description: 'Sound academic potential (CGPA ≥ 7.0) at risk of exam debarment due to attendance slipping below statutory 75%.',
      criteria: 'Attendance < 75% AND CGPA ≥ 7.0',
      recommendedIntervention: 'Notify student and mentor to rectify class presence before semester condonation threshold.',
      studentCount: attendanceWatch.length,
      percentage: Math.round((attendanceWatch.length / total) * 100),
      studentIds: attendanceWatch.map((s) => s.id),
    },
  ];

  return segments;
}

export function generateStudentInsights(student: any): Array<{
  type: 'strength' | 'warning' | 'alert' | 'opportunity';
  title: string;
  metric: string;
  explanation: string;
  recommendation: string;
}> {
  const insights: Array<{
    type: 'strength' | 'warning' | 'alert' | 'opportunity';
    title: string;
    metric: string;
    explanation: string;
    recommendation: string;
  }> = [];

  // Attendance insight
  if (student.attendance_percentage >= 85) {
    insights.push({
      type: 'strength',
      title: 'Exemplary Attendance Consistency',
      metric: `${student.attendance_percentage.toFixed(1)}% Attended`,
      explanation: 'Consistently attends lectures and labs above institutional benchmark (85%+), strongly correlating with foundational concept mastery.',
      recommendation: 'Maintain continuous presence; eligible for academic honor rolls and peer leadership.',
    });
  } else if (student.attendance_percentage < 75) {
    insights.push({
      type: 'alert',
      title: 'Attendance Debarment Risk',
      metric: `${student.attendance_percentage.toFixed(1)}% Attended (Threshold: 75%)`,
      explanation: 'Attendance has dropped below statutory regulations. Immediate condonation or attendance recovery is required to sit for end-semester finals.',
      recommendation: 'Submit leave documentation if medical; commit to 100% attendance in upcoming 3 weeks.',
    });
  }

  // Academic vs Placement insight
  if (student.cgpa >= 7.8 && student.coding_score < 55) {
    insights.push({
      type: 'warning',
      title: 'Theory-to-Implementation Gap',
      metric: `CGPA ${student.cgpa.toFixed(2)} vs Coding ${student.coding_score.toFixed(0)}/100`,
      explanation: 'Strong performance on university theoretical exams, but practical programming problem solving lags behind hiring expectations.',
      recommendation: 'Dedicate 1.5 hours daily to LeetCode/HackerRank curated 75 questions; participate in upcoming coding sandbox.',
    });
  }

  // Placement Readiness
  if (student.placement_readiness_score >= 80) {
    insights.push({
      type: 'strength',
      title: 'Recruitment Ready Profile',
      metric: `${student.placement_readiness_score.toFixed(1)}/100 Readiness Index`,
      explanation: 'Balanced aptitude, coding benchmark, and communication performance position student in the top quartile of hiring drives.',
      recommendation: 'Begin targeting Tier-1 product companies and refine portfolio GitHub repositories.',
    });
  } else if (student.placement_readiness_score < 55) {
    insights.push({
      type: 'warning',
      title: 'Campus Placement Preparedness Needed',
      metric: `${student.placement_readiness_score.toFixed(1)}/100 Readiness Index`,
      explanation: 'Composite score in aptitude screening, technical rounds, and mock interviews falls below major campus recruiter cutoffs.',
      recommendation: 'Complete mandatory Aptitude Foundation modules and schedule a 1-on-1 mock interview with campus placement cell.',
    });
  }

  // LMS & Engagement
  if (student.lms_completion_rate < 60) {
    insights.push({
      type: 'opportunity',
      title: 'Digital Learning Engagement Lags',
      metric: `${student.lms_completion_rate.toFixed(0)}% Module Completion`,
      explanation: 'Course quizzes and digital assignments have accumulated pending tasks, reducing continuous internal assessment marks.',
      recommendation: 'Set weekend sprint to clear overdue LMS laboratory submissions and mini-quizzes.',
    });
  } else if (student.lms_completion_rate >= 90) {
    insights.push({
      type: 'strength',
      title: 'Proactive Coursework Completion',
      metric: `${student.lms_completion_rate.toFixed(0)}% Coursework Finished`,
      explanation: 'All assignments, readings, and discussion forum contributions are submitted well in advance of deadlines.',
      recommendation: 'Explore elective certification tracks or open-source campus initiatives.',
    });
  }

  // Backlogs
  if (student.backlogs > 0) {
    insights.push({
      type: 'alert',
      title: 'Active Backlog Clearance Required',
      metric: `${student.backlogs} Pending Subject(s)`,
      explanation: 'Pending backlogs restrict eligibility for 80% of campus placement drives with strict zero-backlog criteria.',
      recommendation: 'Prioritize remedial semester exams and attend dedicated faculty doubt-clearing sessions.',
    });
  }

  return insights;
}
