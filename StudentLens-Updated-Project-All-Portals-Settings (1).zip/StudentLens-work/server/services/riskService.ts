export interface RiskFactor {
  indicator: string;
  currentValue: string | number;
  threshold: string | number;
  severity: 'High' | 'Medium' | 'Low';
  trend: 'declining' | 'stable' | 'improving';
  explanation: string;
}

export interface RiskAssessment {
  category: 'Academic' | 'Placement';
  level: 'High' | 'Medium' | 'Low';
  score: number;
  factors: RiskFactor[];
  recommendedAction: string;
}

export function evaluateAcademicRisk(student: {
  cgpa: number;
  backlogs: number;
  attendance_percentage: number;
  lms_completion_rate: number;
}): RiskAssessment {
  const factors: RiskFactor[] = [];
  let riskScore = 0;

  // CGPA rule
  if (student.cgpa < 6.0) {
    riskScore += 40;
    factors.push({
      indicator: 'Cumulative GPA',
      currentValue: student.cgpa.toFixed(2),
      threshold: '6.00 (Minimum benchmark)',
      severity: 'High',
      trend: 'declining',
      explanation: `Current CGPA of ${student.cgpa.toFixed(2)} is critically below the 6.00 academic threshold.`,
    });
  } else if (student.cgpa < 7.0) {
    riskScore += 20;
    factors.push({
      indicator: 'Cumulative GPA',
      currentValue: student.cgpa.toFixed(2),
      threshold: '7.00 (Target standard)',
      severity: 'Medium',
      trend: 'stable',
      explanation: `CGPA of ${student.cgpa.toFixed(2)} requires academic attention to prevent falling below retention thresholds.`,
    });
  }

  // Backlogs rule
  if (student.backlogs >= 2) {
    riskScore += 35;
    factors.push({
      indicator: 'Active Backlogs',
      currentValue: student.backlogs,
      threshold: '0 backlogs',
      severity: 'High',
      trend: 'declining',
      explanation: `${student.backlogs} un-cleared backlogs pose significant graduation delay risk.`,
    });
  } else if (student.backlogs === 1) {
    riskScore += 15;
    factors.push({
      indicator: 'Active Backlogs',
      currentValue: 1,
      threshold: '0 backlogs',
      severity: 'Medium',
      trend: 'stable',
      explanation: '1 backlog pending clearance in supplementary/remedial exams.',
    });
  }

  // Attendance rule
  if (student.attendance_percentage < 65) {
    riskScore += 30;
    factors.push({
      indicator: 'Overall Attendance',
      currentValue: `${student.attendance_percentage.toFixed(1)}%`,
      threshold: '75.0% (Statutory requirement)',
      severity: 'High',
      trend: 'declining',
      explanation: `Attendance is critically below the mandatory 75% bar; student faces exam debarment.`,
    });
  } else if (student.attendance_percentage < 75) {
    riskScore += 15;
    factors.push({
      indicator: 'Overall Attendance',
      currentValue: `${student.attendance_percentage.toFixed(1)}%`,
      threshold: '75.0% (Statutory requirement)',
      severity: 'Medium',
      trend: 'declining',
      explanation: `Attendance is in the caution zone (65–75%), requiring attendance counseling.`,
    });
  }

  // LMS rule
  if (student.lms_completion_rate < 50) {
    riskScore += 15;
    factors.push({
      indicator: 'LMS Module Completion',
      currentValue: `${student.lms_completion_rate.toFixed(1)}%`,
      threshold: '70.0% completion',
      severity: 'Medium',
      trend: 'declining',
      explanation: 'Low digital course engagement and overdue coursework.',
    });
  }

  let level: 'High' | 'Medium' | 'Low' = 'Low';
  let recommendedAction = 'Continue current positive learning trajectory and routine faculty touchpoints.';

  if (riskScore >= 45 || student.backlogs >= 2 || student.attendance_percentage < 65) {
    level = 'High';
    recommendedAction = 'Immediate faculty advisor intervention, mandatory remedial sessions, and parent/guardian conference.';
  } else if (riskScore >= 20 || student.backlogs === 1 || student.attendance_percentage < 75) {
    level = 'Medium';
    recommendedAction = 'Assign peer tutor for weak subjects and schedule bi-weekly attendance check-ins.';
  }

  return {
    category: 'Academic',
    level,
    score: Math.min(riskScore, 100),
    factors,
    recommendedAction,
  };
}

export function evaluatePlacementRisk(student: {
  coding_score: number;
  aptitude_score: number;
  mock_interview_score: number;
  communication_score: number;
  placement_readiness_score: number;
}): RiskAssessment {
  const factors: RiskFactor[] = [];
  let riskScore = 0;

  // Coding score
  if (student.coding_score < 45) {
    riskScore += 35;
    factors.push({
      indicator: 'Technical & Coding Score',
      currentValue: `${student.coding_score.toFixed(1)}/100`,
      threshold: '60/100 (Campus recruitment benchmark)',
      severity: 'High',
      trend: 'declining',
      explanation: `Technical coding benchmark not met; failed automated unit tests on data structures.`,
    });
  } else if (student.coding_score < 60) {
    riskScore += 18;
    factors.push({
      indicator: 'Technical & Coding Score',
      currentValue: `${student.coding_score.toFixed(1)}/100`,
      threshold: '60/100',
      severity: 'Medium',
      trend: 'stable',
      explanation: 'Moderate coding ability; needs structured algorithmic practice on LeetCode/HackerRank.',
    });
  }

  // Aptitude score
  if (student.aptitude_score < 45) {
    riskScore += 30;
    factors.push({
      indicator: 'Quantitative Aptitude & Logical Reasoning',
      currentValue: `${student.aptitude_score.toFixed(1)}/100`,
      threshold: '60/100 (First-round screening)',
      severity: 'High',
      trend: 'declining',
      explanation: `Low aptitude score will prevent clearing initial screening rounds for tier-1 & tier-2 employers.`,
    });
  } else if (student.aptitude_score < 60) {
    riskScore += 15;
    factors.push({
      indicator: 'Quantitative Aptitude',
      currentValue: `${student.aptitude_score.toFixed(1)}/100`,
      threshold: '60/100',
      severity: 'Medium',
      trend: 'stable',
      explanation: 'Aptitude speed and accuracy need time-boxed drill practice.',
    });
  }

  // Mock interview & communication
  if (student.mock_interview_score < 50 || student.communication_score < 50) {
    riskScore += 25;
    factors.push({
      indicator: 'Mock Interview & Communication',
      currentValue: `${student.mock_interview_score.toFixed(1)}/100`,
      threshold: '65/100',
      severity: student.mock_interview_score < 40 ? 'High' : 'Medium',
      trend: 'stable',
      explanation: 'Behavioral responses, technical articulation, and resume project walkthrough need coaching.',
    });
  }

  let level: 'High' | 'Medium' | 'Low' = 'Low';
  let recommendedAction = 'Ready for active placement drive participation. Continue advanced mock rounds.';

  if (riskScore >= 45 || student.coding_score < 45 || student.placement_readiness_score < 50) {
    level = 'High';
    recommendedAction = 'Enroll in 4-week Placement Intensive Bootcamp focusing on DSA, aptitude mocks, and resume clinics.';
  } else if (riskScore >= 20 || student.placement_readiness_score < 68) {
    level = 'Medium';
    recommendedAction = 'Provide targeted mock interview simulation and assign 50 foundational aptitude questions.';
  }

  return {
    category: 'Placement',
    level,
    score: Math.min(riskScore, 100),
    factors,
    recommendedAction,
  };
}
