import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'studentlens-super-secure-dev-secret-key-2026';

export interface AuthUser {
  id: string;
  email: string;
  role: 'student' | 'faculty' | 'administrator';
  full_name: string;
  department?: string;
  college_id?: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export function generateToken(user: AuthUser): string {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      full_name: user.full_name,
      department: user.department,
      college_id: user.college_id,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session expired or invalid token. Please log in again.' });
  }
}

export function requireRole(allowedRoles: Array<'student' | 'faculty' | 'administrator'>) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized.' });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access denied. Requires one of: ${allowedRoles.join(', ')}`,
      });
    }

    next();
  };
}

export function checkStudentOwnership(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized.' });
  }

  // Administrators and Faculty can access authorized student profiles
  if (req.user.role === 'administrator' || req.user.role === 'faculty') {
    return next();
  }

  // Student can ONLY access their own profile
  const targetStudentId = req.params.id;
  if (req.user.role === 'student') {
    if (req.user.college_id !== targetStudentId) {
      return res.status(403).json({ error: 'Access forbidden: You cannot view other students’ records.' });
    }
  }

  next();
}
